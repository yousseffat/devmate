import { describe, it, expect } from 'vitest';

// 1. GitHub URL parsing
export function parseGitHubUrl(url) {
  const repoRegex = /^https:\/\/github\.com\/([a-zA-Z0-9_.-]+)\/([a-zA-Z0-9_.-]+)(?:\/tree\/([a-zA-Z0-9_.-]+)\/(.+))?$/;
  const match = url.trim().match(repoRegex);
  if (!match) return null;
  return {
    owner: match[1],
    repo: match[2].replace(/\.git$/, ''),
    branch: match[3] || 'main',
    path: match[4] || ''
  };
}

// 2. SKILL.md validation
export function validateSkillMd(content, folderName) {
  if (!content || !content.trim()) {
    return { valid: false, error: 'SKILL.md is empty' };
  }
  const match = content.match(/^---\r?\n([\s\S]*?)\r?\n---/);
  if (!match) {
    return { valid: false, error: 'Missing YAML frontmatter (---) in SKILL.md' };
  }
  const frontmatter = match[1];
  const nameMatch = frontmatter.match(/name:\s*["']?([a-z0-9-]+)["']?/);
  const descMatch = frontmatter.match(/description:\s*["']?([\s\S]+?)["']?(?=\n\w+:|$)/);

  if (!nameMatch) {
    return { valid: false, error: 'Invalid or missing name in frontmatter. Must be max 64 lowercase alphanumeric + hyphens.' };
  }
  const name = nameMatch[1];
  if (name.length > 64) {
    return { valid: false, error: 'Skill name exceeds 64 characters limit.' };
  }
  if (folderName && name !== folderName) {
    return { valid: true, renameSuggested: true, name, message: `Folder name "${folderName}" differs from skill name "${name}". Offer to rename.` };
  }

  const desc = descMatch ? descMatch[1].trim() : '';
  if (!desc) {
    return { valid: false, error: 'Missing description in frontmatter.' };
  }
  if (desc.length > 1024) {
    return { valid: false, error: 'Description exceeds 1024 characters limit.' };
  }

  return { valid: true, name, description: desc };
}

// 3. Zip-slip protection
export function isSafeZipEntryPath(targetDir, entryName) {
  if (entryName.includes('..') || entryName.startsWith('/') || entryName.startsWith('\\')) {
    return false;
  }
  const normalized = (targetDir + '/' + entryName).replace(/\\/g, '/');
  return normalized.startsWith(targetDir.replace(/\\/g, '/'));
}

// 4. Size & file count & binary rejection
export function validateSkillFiles(files) {
  const MAX_SIZE = 5 * 1024 * 1024; // 5 MB
  const MAX_FILES = 100;
  const BANNED_EXTENSIONS = ['.exe', '.dll', '.msi', '.bin', '.so', '.dylib'];

  if (files.length > MAX_FILES) {
    return { valid: false, error: `Exceeds max file count limit of ${MAX_FILES} (found ${files.length})` };
  }

  let totalSize = 0;
  let hasScripts = false;

  for (const f of files) {
    totalSize += f.size || 0;
    const lowerName = f.name.toLowerCase();
    for (const ext of BANNED_EXTENSIONS) {
      if (lowerName.endsWith(ext)) {
        return { valid: false, error: `Rejected binary file detected: ${f.name}` };
      }
    }
    if (lowerName.endsWith('.py') || lowerName.endsWith('.sh') || lowerName.endsWith('.js') || lowerName.endsWith('.ps1')) {
      hasScripts = true;
    }
  }

  if (totalSize > MAX_SIZE) {
    return { valid: false, error: `Total size exceeds 5MB limit (${(totalSize / (1024*1024)).toFixed(2)} MB)` };
  }

  return { valid: true, hasScripts, totalSize, fileCount: files.length };
}

// 5. Approval rule
export function checkInstallApproval(userApproved, installFn) {
  if (!userApproved) {
    return { installed: false, error: 'Installation cancelled: User approval dialog required before copying files.' };
  }
  return { installed: true, result: installFn() };
}

describe('Skills Studio Security & Installation Specs', () => {
  it('parses GitHub URLs correctly with branch and tree path', () => {
    const parsed = parseGitHubUrl('https://github.com/google/agent-skills/tree/main/skills/reverse-engineering');
    expect(parsed).toEqual({
      owner: 'google',
      repo: 'agent-skills',
      branch: 'main',
      path: 'skills/reverse-engineering'
    });

    const parsedRoot = parseGitHubUrl('https://github.com/example/dna-analyzer.git');
    expect(parsedRoot).toEqual({
      owner: 'example',
      repo: 'dna-analyzer',
      branch: 'main',
      path: ''
    });
  });

  it('validates SKILL.md YAML frontmatter format and limits', () => {
    const validContent = `---
name: dna-analyzer
description: High-throughput DNA sequence transcription and translation analyzer.
---
# DNA Analyzer
Instructions here...`;

    const res = validateSkillMd(validContent, 'dna-analyzer');
    expect(res.valid).toBe(true);
    expect(res.name).toBe('dna-analyzer');

    // Missing frontmatter
    const invalidRes = validateSkillMd('# Just markdown without frontmatter', 'test');
    expect(invalidRes.valid).toBe(false);
  });

  it('prevents zip-slip and path traversal attacks', () => {
    const safe = isSafeZipEntryPath('/data/skills/my-skill', 'scripts/run.py');
    expect(safe).toBe(true);

    const malicious1 = isSafeZipEntryPath('/data/skills/my-skill', '../../etc/passwd');
    expect(malicious1).toBe(false);

    const malicious2 = isSafeZipEntryPath('/data/skills/my-skill', '/root/.ssh/id_rsa');
    expect(malicious2).toBe(false);
  });

  it('enforces 5MB size limit, 100 file limit, and rejects binary executables', () => {
    const cleanFiles = [
      { name: 'SKILL.md', size: 2048 },
      { name: 'scripts/calc.py', size: 1024 }
    ];
    const cleanCheck = validateSkillFiles(cleanFiles);
    expect(cleanCheck.valid).toBe(true);
    expect(cleanCheck.hasScripts).toBe(true);

    const binaryFiles = [
      { name: 'SKILL.md', size: 2048 },
      { name: 'payload.exe', size: 50000 }
    ];
    const binaryCheck = validateSkillFiles(binaryFiles);
    expect(binaryCheck.valid).toBe(false);
    expect(binaryCheck.error).toContain('Rejected binary file');

    const oversized = [{ name: 'big.dat', size: 6 * 1024 * 1024 }];
    expect(validateSkillFiles(oversized).valid).toBe(false);
  });

  it('strictly ensures install_skill never copies files before user approval dialog', () => {
    let copied = false;
    const copyAction = () => { copied = true; return 'copied'; };

    const unapproved = checkInstallApproval(false, copyAction);
    expect(unapproved.installed).toBe(false);
    expect(copied).toBe(false);

    const approved = checkInstallApproval(true, copyAction);
    expect(approved.installed).toBe(true);
    expect(copied).toBe(true);
  });
});
