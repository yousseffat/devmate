import { describe, it, expect } from 'vitest'
import { SkillParser } from '../src/main/skills/parser'
import { GitHubSkillFetcher } from '../src/main/skills/github'
import { SecurityManager } from '../src/main/security'
import { FsTools } from '../src/main/tools/fs'
import { RadarScheduler } from '../src/main/radar/scheduler'
import fs from 'fs'
import path from 'path'

describe('DevMate Core Systems Tests', () => {
  it('SkillParser parses YAML frontmatter with exact constraints', () => {
    const validContent = `---
name: android-compose
description: Modern Android UI toolkit patterns with Jetpack Compose.
---
# Guide
Instructions here...`

    const parsed = SkillParser.parseSkillMd(validContent, 'android-compose')
    expect(parsed.isValid).toBe(true)
    expect(parsed.name).toBe('android-compose')
    expect(parsed.suggestRename).toBe(false)

    // Name mismatch triggers suggestRename
    const mismatch = SkillParser.parseSkillMd(validContent, 'different-folder')
    expect(mismatch.isValid).toBe(true)
    expect(mismatch.suggestRename).toBe(true)

    // Invalid: uppercase letters in name
    const invalidName = `---
name: BAD_NAME
description: some desc
---`
    const badParsed = SkillParser.parseSkillMd(invalidName)
    expect(badParsed.isValid).toBe(false)
  })

  it('GitHubSkillFetcher parses repository and tree paths', () => {
    const res = GitHubSkillFetcher.parseUrl(
      'https://github.com/agent-skills/android/tree/main/skills/compose-expert'
    )
    expect(res).toEqual({
      owner: 'agent-skills',
      repo: 'android',
      branch: 'main',
      path: 'skills/compose-expert'
    })

    const rootRes = GitHubSkillFetcher.parseUrl('https://github.com/example/my-repo.git')
    expect(rootRes?.owner).toBe('example')
    expect(rootRes?.repo).toBe('my-repo')
    expect(rootRes?.branch).toBe('main')
  })

  it('SkillParser guards against zip-slip path traversal attacks', () => {
    const targetDir = '/app/workspace/skills/my-skill'
    expect(SkillParser.isSafeZipEntry(targetDir, 'scripts/run.py')).toBe(true)
    expect(SkillParser.isSafeZipEntry(targetDir, '../../etc/shadow')).toBe(false)
    expect(SkillParser.isSafeZipEntry(targetDir, '/root/.bashrc')).toBe(false)
  })

  it('SecurityManager strictly enforces workspace sandbox', () => {
    const root = path.resolve('/tmp/test-workspace')
    expect(() => SecurityManager.validateWorkspacePath(root, '../../etc/passwd')).toThrow()
    expect(() => SecurityManager.validateWorkspacePath(root, '../other/file.txt')).toThrow()
  })

  it('FsTools.editFile validates single exact match uniqueness', () => {
    const tmpDir = path.join(process.cwd(), '.tmp-test')
    fs.mkdirSync(tmpDir, { recursive: true })
    const testFile = path.join(tmpDir, 'sample.txt')

    fs.writeFileSync(testFile, 'Hello World\nDuplicate\nDuplicate\nEnd', 'utf-8')

    // Unique match succeeds
    const res = FsTools.editFile(tmpDir, 'sample.txt', 'Hello World', 'Hello DevMate')
    expect(res).toContain('Successfully replaced')

    // Duplicate match fails
    expect(() => FsTools.editFile(tmpDir, 'sample.txt', 'Duplicate', 'Replacement')).toThrow(
      /multiple occurrences/
    )

    // Non-existent target fails
    expect(() => FsTools.editFile(tmpDir, 'sample.txt', 'MissingText', 'Replacement')).toThrow(
      /Target content not found/
    )

    fs.rmSync(tmpDir, { recursive: true, force: true })
  })

  it('RadarScheduler evaluates overdue state accurately', () => {
    const tmpDir = path.join(process.cwd(), '.tmp-radar')
    fs.mkdirSync(tmpDir, { recursive: true })

    const scheduler = new RadarScheduler(tmpDir)
    expect(scheduler.isCheckOverdue(10)).toBe(true)

    scheduler.recordCheckNow(10)
    expect(scheduler.isCheckOverdue(10)).toBe(false)

    fs.rmSync(tmpDir, { recursive: true, force: true })
  })

  it('Enforces that installation without user approval is strictly impossible', () => {
    let filesCopied = false
    const installAction = () => {
      filesCopied = true
    }

    const runInstall = (userApproved: boolean) => {
      if (!userApproved) {
        throw new Error('User approval required.')
      }
      installAction()
    }

    expect(() => runInstall(false)).toThrow()
    expect(filesCopied).toBe(false)

    runInstall(true)
    expect(filesCopied).toBe(true)
  })
})
