import { contextBridge, ipcRenderer } from 'electron'
import { IpcApi } from '../shared/ipc'
import { AppSettings, ChatSession, ApprovalRequest, PendingSkillInstall } from '../shared/types'

const api: IpcApi = {
  getSettings: () => ipcRenderer.invoke('getSettings'),
  saveSettings: (s: Partial<AppSettings>) => ipcRenderer.invoke('saveSettings', s),

  selectWorkspaceFolder: () => ipcRenderer.invoke('selectWorkspaceFolder'),
  selectFile: () => ipcRenderer.invoke('selectFile'),
  openInExplorer: (p: string) => ipcRenderer.invoke('openInExplorer', p),

  listChats: () => ipcRenderer.invoke('listChats'),
  loadChat: async (id: string) => {
    const chats: ChatSession[] = await ipcRenderer.invoke('listChats')
    return chats.find((c) => c.id === id) || null
  },
  saveChat: (c: ChatSession) => ipcRenderer.invoke('saveChat', c),
  deleteChat: (id: string) => ipcRenderer.invoke('deleteChat', id),
  sendMessage: (sessionId: string, text: string) => ipcRenderer.invoke('sendMessage', sessionId, text),
  stopAgent: (sessionId: string) => ipcRenderer.invoke('stopAgent', sessionId),
  respondApproval: (id: string, allowed: boolean) => ipcRenderer.invoke('respondApproval', id, allowed),

  listSkills: () => ipcRenderer.invoke('listSkills'),
  toggleSkill: (name: string, enabled: boolean) => ipcRenderer.invoke('toggleSkill', name, enabled),
  searchSkillsOnline: (q: string) => ipcRenderer.invoke('searchSkillsOnline', q),
  prepareSkillFromUrl: (url: string): Promise<PendingSkillInstall> => ipcRenderer.invoke('prepareSkillFromUrl', url),
  uninstallSkill: (name: string) => ipcRenderer.invoke('uninstallSkill', name),
  refreshSkills: () => ipcRenderer.invoke('refreshSkills'),

  checkToolchain: () => ipcRenderer.invoke('checkToolchain'),
  installToolchainItem: (id: string) => ipcRenderer.invoke('installToolchainItem', id),
  acceptAndroidLicenses: () => ipcRenderer.invoke('acceptAndroidLicenses'),
  listBuildProjects: () => ipcRenderer.invoke('listBuildProjects'),
  buildProject: (id: string) => ipcRenderer.invoke('buildProject', id),
  installArtifact: (p: string) => ipcRenderer.invoke('installArtifact', p),

  checkUpdatesNow: () => ipcRenderer.invoke('checkUpdatesNow'),
  getUpdates: () => ipcRenderer.invoke('getUpdates'),
  learnUpdate: (id: string) => ipcRenderer.invoke('learnUpdate', id),

  onAgentStream: (callback) => {
    const handler = (_: unknown, data: { sessionId: string; token?: string; done?: boolean }) => callback(data)
    ipcRenderer.on('agentStream', handler)
    return () => ipcRenderer.removeListener('agentStream', handler)
  },
  onApprovalRequested: (callback) => {
    const handler = (_: unknown, req: ApprovalRequest) => callback(req)
    ipcRenderer.on('approvalRequested', handler)
    return () => ipcRenderer.removeListener('approvalRequested', handler)
  },
  onToolActivity: (callback) => {
    const handler = (_: unknown, data: { name: string; status: 'running' | 'success' | 'error'; info?: string }) =>
      callback(data)
    ipcRenderer.on('toolActivity', handler)
    return () => ipcRenderer.removeListener('toolActivity', handler)
  }
}

contextBridge.exposeInMainWorld('api', api)
