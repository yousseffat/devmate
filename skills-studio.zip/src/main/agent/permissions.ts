import { PermissionMode } from '../../shared/types'

export class PermissionManager {
  constructor(private mode: PermissionMode) {}

  setMode(mode: PermissionMode): void {
    this.mode = mode
  }

  getMode(): PermissionMode {
    return this.mode
  }

  requiresCommandApproval(): boolean {
    // In plan mode, commands cannot run at all
    if (this.mode === 'plan') {
      throw new Error('Action blocked: Commands cannot be executed in Plan (read-only) mode.')
    }
    // In Ask mode and Auto-edit mode, shell commands ALWAYS require explicit user approval
    return true
  }

  requiresFileEditApproval(): boolean {
    if (this.mode === 'plan') {
      throw new Error('Action blocked: File modifications are disabled in Plan (read-only) mode.')
    }
    if (this.mode === 'auto-edit') {
      return false
    }
    return true
  }
}
