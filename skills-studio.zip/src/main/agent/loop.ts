import { ChatMessage, ToolResult } from '../../shared/types'
import { AIProviderAdapter } from '../providers/types'
import { ToolRegistry } from '../tools/registry'

export class AgentLoop {
  static readonly MAX_ITERATIONS = 40

  static async run(
    adapter: AIProviderAdapter,
    toolRegistry: ToolRegistry,
    messages: ChatMessage[],
    onToken: (token: string) => void,
    onToolStatus: (name: string, status: 'running' | 'success' | 'error', info?: string) => void,
    abortSignal?: AbortSignal,
    maxIterations: number = 40
  ): Promise<ChatMessage[]> {
    const history = [...messages]
    const tools = toolRegistry.getToolDefinitions()
    const limit = Math.min(Math.max(maxIterations, 1), 60)

    for (let iteration = 0; iteration < limit; iteration++) {
      if (abortSignal?.aborted) break

      const streamResult = await adapter.streamChat(
        history,
        tools,
        {
          onToken,
          onToolCallDelta: () => {}
        },
        abortSignal
      )

      if (abortSignal?.aborted) break

      const assistantMsg: ChatMessage = {
        id: `msg_${Date.now()}_${iteration}`,
        role: 'assistant',
        content: streamResult.text,
        timestamp: Date.now(),
        toolCalls: streamResult.toolCalls.length > 0 ? streamResult.toolCalls : undefined
      }
      history.push(assistantMsg)

      if (streamResult.toolCalls.length === 0) {
        break
      }

      // Execute tool calls (independent tools in parallel)
      const toolPromises = streamResult.toolCalls.map(async (tc) => {
        // If arguments failed to parse as valid JSON
        if (tc.arguments && '_raw_error_arguments' in tc.arguments) {
          const raw = String(tc.arguments._raw_error_arguments)
          onToolStatus(tc.name, 'error', 'Malformed JSON arguments')
          return {
            toolCallId: tc.id,
            name: tc.name,
            output: `Error: Malformed JSON arguments provided for tool "${tc.name}": "${raw}". Please retry with valid JSON parameters.`,
            isError: true
          } as ToolResult
        }

        onToolStatus(tc.name, 'running')
        try {
          const output = await toolRegistry.executeTool(tc.name, tc.arguments, abortSignal)
          onToolStatus(tc.name, 'success')
          return {
            toolCallId: tc.id,
            name: tc.name,
            output,
            isError: false
          } as ToolResult
        } catch (err) {
          const errMsg = (err as Error).message
          onToolStatus(tc.name, 'error', errMsg)
          return {
            toolCallId: tc.id,
            name: tc.name,
            output: `Error executing ${tc.name}: ${errMsg}`,
            isError: true
          } as ToolResult
        }
      })

      const results = await Promise.all(toolPromises)
      for (const res of results) {
        history.push({
          id: `tool_${Date.now()}_${res.toolCallId}`,
          role: 'tool',
          content: res.output,
          timestamp: Date.now(),
          toolResult: res
        })
      }
    }

    return history
  }
}
