import { safeStorage } from 'electron'
import path from 'path'
import fs from 'fs'

export class SecurityManager {
  // Encrypt sensitive secrets like API keys
  static encryptSecret(secret: string): string {
    if (!secret) return ''
    if (safeStorage && safeStorage.isEncryptionAvailable()) {
      const buffer = safeStorage.encryptString(secret)
      return buffer.toString('base64')
    }
    // Fallback if safeStorage is unavailable in headless/container test
    return Buffer.from(secret, 'utf-8').toString('base64')
  }

  // Decrypt sensitive secrets
  static decryptSecret(encryptedBase64: string): string {
    if (!encryptedBase64) return ''
    try {
      const buffer = Buffer.from(encryptedBase64, 'base64')
      if (safeStorage && safeStorage.isEncryptionAvailable()) {
        return safeStorage.decryptString(buffer)
      }
      return buffer.toString('utf-8')
    } catch {
      return ''
    }
  }

  // Validate that a file path strictly resolves inside the workspace
  static validateWorkspacePath(workspaceRoot: string, targetPath: string): string {
    const resolvedRoot = path.resolve(workspaceRoot)
    const resolvedTarget = path.isAbsolute(targetPath)
      ? path.resolve(targetPath)
      : path.resolve(resolvedRoot, targetPath)

    if (resolvedTarget !== resolvedRoot && !resolvedTarget.startsWith(resolvedRoot + path.sep)) {
      throw new Error(`Security Violation: Path "${targetPath}" escapes the designated workspace directory.`)
    }

    // Guard against symlink escape if target already exists
    if (fs.existsSync(resolvedTarget)) {
      const realTarget = fs.realpathSync(resolvedTarget)
      const realRoot = fs.realpathSync(resolvedRoot)
      if (realTarget !== realRoot && !realTarget.startsWith(realRoot + path.sep)) {
        throw new Error(`Security Violation: Symlink escape detected for "${targetPath}".`)
      }
    }

    return resolvedTarget
  }

  // Sanitize commands to prevent accidental system destruction
  static isCommandDestructive(command: string): boolean {
    const dangerousPatterns = [
      /\brm\s+-rf\s+[\/\\]/i,
      /\bformat\s+[a-z]:/i,
      /\bdel\s+\/s\s+\/q\s+[c-z]:\\/i,
      /\brmdir\s+\/s\s+\/q\s+[c-z]:\\/i,
      /\bdrop\s+database\b/i
    ]
    return dangerousPatterns.some((pattern) => pattern.test(command))
  }
}
