import Anthropic from '@anthropic-ai/sdk'
import { ChatMessage, ToolCall } from '../../shared/types'
import { AIProviderAdapter, StreamCallbacks, ToolDefinition } from './types'

export class AnthropicAdapter implements AIProviderAdapter {
  id = 'anthropic'
  name = 'Anthropic Claude'
  private client: Anthropic
  private modelId: string

  constructor(apiKey: string, modelId: string = 'claude-3-5-sonnet-20241022') {
    this.modelId = modelId
    this.client = new Anthropic({ apiKey: apiKey || '' })
  }

  async listModels(): Promise<string[]> {
    return [
      'claude-3-5-sonnet-20241022',
      'claude-3-5-haiku-20241022',
      'claude-3-opus-20240229'
    ]
  }

  async streamChat(
    messages: ChatMessage[],
    tools: ToolDefinition[],
    callbacks: StreamCallbacks,
    abortSignal?: AbortSignal
  ): Promise<{ text: string; toolCalls: ToolCall[] }> {
    let systemPrompt = ''
    const formattedMessages: Anthropic.MessageParam[] = []

    for (const msg of messages) {
      if (msg.role === 'system') {
        systemPrompt += (systemPrompt ? '\n\n' : '') + msg.content
      } else if (msg.role === 'tool' && msg.toolResult) {
        formattedMessages.push({
          role: 'user',
          content: [
            {
              type: 'tool_result',
              tool_use_id: msg.toolResult.toolCallId,
              content: msg.toolResult.output,
              is_error: msg.toolResult.isError
            }
          ]
        })
      } else if (msg.toolCalls && msg.toolCalls.length > 0) {
        formattedMessages.push({
          role: 'assistant',
          content: [
            ...(msg.content ? [{ type: 'text' as const, text: msg.content }] : []),
            ...msg.toolCalls.map((tc) => ({
              type: 'tool_use' as const,
              id: tc.id,
              name: tc.name,
              input: tc.arguments
            }))
          ]
        })
      } else {
        formattedMessages.push({
          role: msg.role === 'assistant' ? 'assistant' : 'user',
          content: msg.content
        })
      }
    }

    const anthropicTools: Anthropic.Tool[] = tools.map((t) => ({
      name: t.name,
      description: t.description,
      input_schema: {
        type: 'object',
        properties: (t.parameters.properties as Record<string, unknown>) || {},
        required: (t.parameters.required as string[]) || []
      }
    }))

    const stream = this.client.messages.stream(
      {
        model: this.modelId,
        max_tokens: 4096,
        system: systemPrompt || undefined,
        messages: formattedMessages,
        tools: anthropicTools.length > 0 ? anthropicTools : undefined
      },
      { signal: abortSignal }
    )

    let accumulatedText = ''
    const toolCalls: ToolCall[] = []

    for await (const event of stream) {
      if (abortSignal?.aborted) break
      if (event.type === 'content_block_delta') {
        if (event.delta.type === 'text_delta') {
          accumulatedText += event.delta.text
          callbacks.onToken(event.delta.text)
        }
      }
    }

    const finalMessage = await stream.finalMessage()
    for (const block of finalMessage.content) {
      if (block.type === 'tool_use') {
        toolCalls.push({
          id: block.id,
          name: block.name,
          arguments: (block.input as Record<string, unknown>) || {}
        })
      }
    }

    return { text: accumulatedText, toolCalls }
  }
}
