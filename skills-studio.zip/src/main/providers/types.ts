import { ChatMessage, ToolCall } from '../../shared/types'

export interface ToolDefinition {
  name: string
  description: string
  parameters: Record<string, unknown>
}

export interface StreamCallbacks {
  onToken: (token: string) => void
  onToolCallDelta: (delta: { index: number; id?: string; name?: string; argsTextDelta?: string }) => void
}

export interface AIProviderAdapter {
  id: string
  name: string
  listModels(apiKey?: string, baseUrl?: string): Promise<string[]>
  streamChat(
    messages: ChatMessage[],
    tools: ToolDefinition[],
    callbacks: StreamCallbacks,
    abortSignal?: AbortSignal
  ): Promise<{ text: string; toolCalls: ToolCall[] }>
}
