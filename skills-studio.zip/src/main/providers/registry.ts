import { ModelConfig } from '../../shared/types'
import { AIProviderAdapter } from './types'
import { OpenAICompatAdapter } from './openaiCompat'
import { AnthropicAdapter } from './anthropic'

export class ProviderRegistry {
  static createAdapter(config: ModelConfig): AIProviderAdapter {
    switch (config.provider) {
      case 'anthropic':
        return new AnthropicAdapter(config.apiKey || '', config.modelId)
      case 'gemini':
        return new OpenAICompatAdapter(
          'gemini',
          'Google Gemini (AI Studio)',
          config.apiKey || '',
          config.baseUrl || 'https://generativelanguage.googleapis.com/v1beta/openai/',
          config.modelId || 'gemini-1.5-flash'
        )
      case 'ollama':
        return new OpenAICompatAdapter(
          'ollama',
          'Ollama (Local)',
          'ollama',
          config.baseUrl || 'http://localhost:11434/v1',
          config.modelId || 'llama3.2'
        )
      case 'kimi':
        return new OpenAICompatAdapter(
          'kimi',
          'Moonshot Kimi',
          config.apiKey || '',
          config.baseUrl || 'https://api.moonshot.ai/v1',
          config.modelId || 'moonshot-v1-8k'
        )
      case 'openai':
      case 'custom':
      default:
        return new OpenAICompatAdapter(
          config.provider,
          config.provider.toUpperCase(),
          config.apiKey || '',
          config.baseUrl,
          config.modelId || 'gpt-4o'
        )
    }
  }

  static async detectOllama(): Promise<{ isRunning: boolean; models: string[] }> {
    try {
      const response = await fetch('http://localhost:11434/api/tags', { signal: AbortSignal.timeout(2000) })
      if (!response.ok) return { isRunning: false, models: [] }
      const data = (await response.json()) as { models?: Array<{ name: string }> }
      const models = data.models?.map((m) => m.name) || []
      return { isRunning: true, models }
    } catch {
      return { isRunning: false, models: [] }
    }
  }
}
