import OpenAI from 'openai'
import { ChatMessage, ToolCall } from '../../shared/types'
import { AIProviderAdapter, StreamCallbacks, ToolDefinition } from './types'

export class OpenAICompatAdapter implements AIProviderAdapter {
  id: string
  name: string
  private client: OpenAI
  private modelId: string

  constructor(id: string, name: string, apiKey: string, baseUrl?: string, modelId: string = 'gpt-4o') {
    this.id = id
    this.name = name
    this.modelId = modelId
    this.client = new OpenAI({
      apiKey: apiKey || 'dummy-key',
      baseURL: baseUrl,
      maxRetries: 0 // We manage explicit backoff
    })
  }

  async listModels(): Promise<string[]> {
    try {
      const response = await this.client.models.list()
      return response.data.map((m) => m.id)
    } catch {
      if (this.id === 'ollama') {
        return ['llama3.2', 'qwen2.5-coder', 'mistral', 'deepseek-r1']
      }
      if (this.id === 'gemini') {
        return ['gemini-1.5-flash', 'gemini-1.5-pro', 'gemini-2.0-flash']
      }
      return ['gpt-4o', 'gpt-4o-mini', 'o1-preview']
    }
  }

  async streamChat(
    messages: ChatMessage[],
    tools: ToolDefinition[],
    callbacks: StreamCallbacks,
    abortSignal?: AbortSignal
  ): Promise<{ text: string; toolCalls: ToolCall[] }> {
    const formattedMessages = messages.map((m) => {
      if (m.role === 'tool' && m.toolResult) {
        return {
          role: 'tool' as const,
          tool_call_id: m.toolResult.toolCallId,
          content: m.toolResult.output
        }
      }
      if (m.toolCalls && m.toolCalls.length > 0) {
        return {
          role: 'assistant' as const,
          content: m.content || null,
          tool_calls: m.toolCalls.map((tc) => ({
            id: tc.id,
            type: 'function' as const,
            function: {
              name: tc.name,
              arguments: JSON.stringify(tc.arguments)
            }
          }))
        }
      }
      return {
        role: m.role as 'user' | 'assistant' | 'system',
        content: m.content
      }
    })

    const formattedTools = tools.map((t) => ({
      type: 'function' as const,
      function: {
        name: t.name,
        description: t.description,
        parameters: t.parameters
      }
    }))

    // Retry loop with exponential backoff for 429
    let stream: any
    let lastError: any
    for (let attempt = 0; attempt < 3; attempt++) {
      if (abortSignal?.aborted) throw new Error('Request aborted by user.')
      try {
        stream = await this.client.chat.completions.create(
          {
            model: this.modelId,
            messages: formattedMessages,
            tools: formattedTools.length > 0 ? formattedTools : undefined,
            stream: true
            // temperature NOT sent by default
          },
          { signal: abortSignal }
        )
        break
      } catch (err: any) {
        lastError = err
        if (err.status === 401) {
          throw new Error('Authentication failed (HTTP 401): Please verify your API key in Settings.')
        }
        if (err.status === 429 && attempt < 2) {
          const delayMs = Math.pow(2, attempt) * 1500
          await new Promise((r) => setTimeout(r, delayMs))
          continue
        }
        throw err
      }
    }

    if (!stream) {
      throw lastError || new Error('Failed to initiate AI stream.')
    }

    let accumulatedText = ''
    const accumulatedToolCalls: Map<number, { id: string; name: string; argsText: string }> = new Map()

    for await (const chunk of stream) {
      if (abortSignal?.aborted) break
      const delta = chunk.choices[0]?.delta

      if (delta?.content) {
        accumulatedText += delta.content
        callbacks.onToken(delta.content)
      }

      if (delta?.tool_calls) {
        for (const tcDelta of delta.tool_calls) {
          const idx = tcDelta.index
          const current = accumulatedToolCalls.get(idx) || { id: tcDelta.id || `call_${idx}`, name: '', argsText: '' }
          if (tcDelta.id) current.id = tcDelta.id
          if (tcDelta.function?.name) current.name += tcDelta.function.name
          if (tcDelta.function?.arguments) current.argsText += tcDelta.function.arguments

          accumulatedToolCalls.set(idx, current)
          callbacks.onToolCallDelta({
            index: idx,
            id: current.id,
            name: current.name,
            argsTextDelta: tcDelta.function?.arguments
          })
        }
      }
    }

    const toolCalls: ToolCall[] = []
    for (const [, callData] of accumulatedToolCalls) {
      let parsedArgs: Record<string, unknown> = {}
      try {
        parsedArgs = JSON.parse(callData.argsText || '{}')
      } catch {
        parsedArgs = { _raw_error_arguments: callData.argsText }
      }
      toolCalls.push({
        id: callData.id,
        name: callData.name,
        arguments: parsedArgs
      })
    }

    return { text: accumulatedText, toolCalls }
  }
}
