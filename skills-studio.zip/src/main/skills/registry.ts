import fs from 'fs'
import path from 'path'
import { Skill, SkillCandidate, InvalidSkillInfo } from '../../shared/types'
import { SkillParser } from './parser'

export class SkillRegistry {
  private skills: Map<string, Skill> = new Map()
  private invalidSkills: InvalidSkillInfo[] = []

  scanFolders(folderPaths: string[]): Skill[] {
    this.skills.clear()
    this.invalidSkills = []

    for (const folder of folderPaths) {
      if (!fs.existsSync(folder)) continue
      try {
        const entries = fs.readdirSync(folder, { withFileTypes: true })
        for (const entry of entries) {
          if (!entry.isDirectory()) continue
          const skillDir = path.join(folder, entry.name)
          const skillMdPath = path.join(skillDir, 'SKILL.md')
          if (fs.existsSync(skillMdPath)) {
            const content = fs.readFileSync(skillMdPath, 'utf-8')
            const parsed = SkillParser.parseSkillMd(content, entry.name)
            if (parsed.isValid && parsed.name) {
              const files = this.listSkillFiles(skillDir)
              this.skills.set(parsed.name, {
                name: parsed.name,
                description: parsed.description || '',
                sourceUrl: `local://${skillDir}`,
                folderPath: skillDir,
                isEnabled: true,
                hasScripts: files.some((f) => f.isScript),
                files,
                skillMdContent: content
              })
            } else {
              this.invalidSkills.push({
                folder: skillDir,
                name: entry.name,
                error: parsed.errorMessage || 'Invalid SKILL.md format'
              })
            }
          }
        }
      } catch {}
    }

    return Array.from(this.skills.values())
  }

  getInvalidSkills(): InvalidSkillInfo[] {
    return this.invalidSkills
  }

  private listSkillFiles(dir: string): Skill['files'] {
    const results: Skill['files'] = []
    const walk = (current: string) => {
      const items = fs.readdirSync(current, { withFileTypes: true })
      for (const item of items) {
        const full = path.join(current, item.name)
        const rel = path.relative(dir, full).replace(/\\/g, '/')
        if (item.isDirectory()) {
          walk(full)
        } else {
          results.push({
            relativePath: rel,
            sizeBytes: fs.statSync(full).size,
            isScript: rel.endsWith('.py') || rel.endsWith('.sh') || rel.endsWith('.js')
          })
        }
      }
    }
    walk(dir)
    return results
  }

  getAll(): Skill[] {
    return Array.from(this.skills.values())
  }

  getSkill(name: string): Skill | undefined {
    return this.skills.get(name)
  }

  toggleSkill(name: string, isEnabled: boolean): void {
    const skill = this.skills.get(name)
    if (skill) {
      skill.isEnabled = isEnabled
    }
  }

  uninstallSkill(name: string): boolean {
    const skill = this.skills.get(name)
    if (!skill) return false
    if (fs.existsSync(skill.folderPath)) {
      fs.rmSync(skill.folderPath, { recursive: true, force: true })
    }
    this.skills.delete(name)
    return true
  }

  searchOnline(query: string): SkillCandidate[] {
    const catalog: SkillCandidate[] = [
      {
        name: 'android-compose-expert',
        description: 'Deep knowledge of Jetpack Compose, Material Design 3, ViewModel, and Coroutines.',
        sourceUrl: 'https://github.com/agent-skills/android/tree/main/skills/android-compose-expert',
        stepsSummary: '1. Scaffolds Compose screen\n2. Sets up StateFlow in ViewModel\n3. Applies M3 dynamic theming',
        hasScripts: false,
        rawSkillMd: `---\nname: android-compose-expert\ndescription: Deep knowledge of Jetpack Compose, Material Design 3, ViewModel, and Coroutines.\n---\n# Android Compose Expert\nPatterns for high-performance Android UIs.`
      },
      {
        name: 'electron-builder-helper',
        description: 'Automates Windows NSIS installer creation, packaging, and native dependency compilation.',
        sourceUrl: 'https://github.com/agent-skills/desktop/tree/main/skills/electron-builder-helper',
        stepsSummary: '1. Configures electron-builder.yml\n2. Optimizes asar packaging\n3. Generates signed Windows installer',
        hasScripts: true,
        rawSkillMd: `---\nname: electron-builder-helper\ndescription: Automates Windows NSIS installer creation, packaging, and native dependency compilation.\n---\n# Electron Builder Helper\nBuilds production-ready desktop executables.`
      },
      {
        name: 'bio-dna-analyzer',
        description: 'Genomic and DNA sequence transcription, translation, GC-content, and ORF detection.',
        sourceUrl: 'https://github.com/agent-skills/science/tree/main/skills/bio-dna-analyzer',
        stepsSummary: '1. Analyzes nucleotide sequences\n2. Transcribes DNA to mRNA\n3. Translates amino acid sequences',
        hasScripts: false,
        rawSkillMd: `---\nname: bio-dna-analyzer\ndescription: Genomic and DNA sequence transcription, translation, GC-content, and ORF detection.\n---\n# Bio DNA Analyzer\nBioinformatics calculations.`
      }
    ]

    const q = query.toLowerCase()
    return catalog.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        c.description.toLowerCase().includes(q) ||
        c.stepsSummary.toLowerCase().includes(q)
    )
  }
}
