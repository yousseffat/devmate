import fs from 'fs'
import path from 'path'
import crypto from 'crypto'
import { PendingSkillInstall, Skill, SkillFile } from '../../shared/types'
import { SkillParser } from './parser'
import { GitHubSkillFetcher } from './github'

export class SkillInstaller {
  static readonly MAX_SIZE_BYTES = 5 * 1024 * 1024 // 5 MB
  static readonly MAX_FILES = 100
  static readonly BANNED_EXTENSIONS = ['.exe', '.dll', '.msi', '.bin', '.so', '.dylib']

  static async prepareFromUrl(sourceUrl: string): Promise<PendingSkillInstall> {
    const trimmed = sourceUrl.trim()
    if (!trimmed.startsWith('https://')) {
      throw new Error('Only secure https:// URLs are permitted for skill installation.')
    }

    let files: Array<{ path: string; content: string; size: number }> = []

    // If GitHub tree/folder URL
    const gh = GitHubSkillFetcher.parseUrl(trimmed)
    if (gh) {
      files = await GitHubSkillFetcher.fetchFolderFiles(gh)
    } else if (trimmed.endsWith('SKILL.md')) {
      // Direct raw SKILL.md
      const res = await fetch(trimmed)
      if (!res.ok) throw new Error(`Failed to download SKILL.md (HTTP ${res.status})`)
      const content = await res.text()
      files = [{ path: 'SKILL.md', content, size: Buffer.byteLength(content) }]
    } else {
      throw new Error('Unsupported skill URL format. Provide a GitHub tree folder or direct SKILL.md URL.')
    }

    if (files.length > this.MAX_FILES) {
      throw new Error(`Skill exceeds file limit: found ${files.length} files (maximum ${this.MAX_FILES}).`)
    }

    let totalSize = 0
    let hasScripts = false

    for (const f of files) {
      totalSize += f.size
      const lower = f.path.toLowerCase()
      for (const ext of this.BANNED_EXTENSIONS) {
        if (lower.endsWith(ext)) {
          throw new Error(`Security Exception: Prohibited binary file detected: ${f.path}`)
        }
      }
      if (lower.endsWith('.py') || lower.endsWith('.sh') || lower.endsWith('.js') || lower.endsWith('.ps1')) {
        hasScripts = true
      }
    }

    if (totalSize > this.MAX_SIZE_BYTES) {
      throw new Error(`Skill exceeds 5MB size limit (total: ${(totalSize / (1024 * 1024)).toFixed(2)} MB).`)
    }

    const skillMdFile = files.find((f) => f.path.toLowerCase() === 'skill.md')
    if (!skillMdFile) {
      throw new Error('Skill package does not contain a required SKILL.md specification file.')
    }

    const validation = SkillParser.parseSkillMd(skillMdFile.content)
    if (!validation.isValid) {
      throw new Error(validation.errorMessage || 'Invalid SKILL.md format.')
    }

    const skillFiles: SkillFile[] = files.map((f) => ({
      relativePath: f.path,
      sizeBytes: f.size,
      isScript: f.path.endsWith('.py') || f.path.endsWith('.sh') || f.path.endsWith('.js'),
      content: f.content
    }))

    return {
      name: validation.name!,
      description: validation.description!,
      sourceUrl: trimmed,
      files: skillFiles,
      skillMdContent: skillMdFile.content,
      hasScripts
    }
  }

  static installApprovedSkill(
    pending: PendingSkillInstall,
    targetBaseFolder: string,
    userDataDir: string
  ): Skill {
    const skillDir = path.join(targetBaseFolder, pending.name)
    fs.mkdirSync(skillDir, { recursive: true })

    const sha256 = crypto.createHash('sha256')

    for (const file of pending.files) {
      if (!SkillParser.isSafeZipEntry(skillDir, file.relativePath)) {
        throw new Error(`Path traversal / zip-slip attempt blocked: ${file.relativePath}`)
      }
      const fullPath = path.join(skillDir, file.relativePath)
      fs.mkdirSync(path.dirname(fullPath), { recursive: true })
      const content = file.content || pending.skillMdContent
      fs.writeFileSync(fullPath, content, 'utf-8')
      sha256.update(content)
    }

    const checksum = sha256.digest('hex')

    // Append to skills-log.json
    const logPath = path.join(userDataDir, 'skills-log.json')
    let logEntries: unknown[] = []
    try {
      if (fs.existsSync(logPath)) {
        logEntries = JSON.parse(fs.readFileSync(logPath, 'utf-8'))
      }
    } catch {}

    logEntries.unshift({
      name: pending.name,
      url: pending.sourceUrl,
      time: new Date().toISOString(),
      fileCount: pending.files.length,
      sha256: checksum
    })

    fs.writeFileSync(logPath, JSON.stringify(logEntries, null, 2), 'utf-8')

    return {
      name: pending.name,
      description: pending.description,
      sourceUrl: pending.sourceUrl,
      folderPath: skillDir,
      isEnabled: true,
      hasScripts: pending.hasScripts,
      files: pending.files,
      skillMdContent: pending.skillMdContent
    }
  }
}
