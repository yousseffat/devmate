export interface GitHubParsedUrl {
  owner: string
  repo: string
  branch: string
  path: string
}

export class GitHubSkillFetcher {
  static parseUrl(url: string): GitHubParsedUrl | null {
    const trimmed = url.trim()
    const match = trimmed.match(
      /^https:\/\/github\.com\/([a-zA-Z0-9_.-]+)\/([a-zA-Z0-9_.-]+)(?:\/tree\/([a-zA-Z0-9_.-]+)\/(.*))?$/
    )
    if (!match) return null

    return {
      owner: match[1],
      repo: match[2].replace(/\.git$/, ''),
      branch: match[3] || 'main',
      path: (match[4] || '').replace(/\/+$/, '')
    }
  }

  static async fetchFolderFiles(
    parsed: GitHubParsedUrl
  ): Promise<Array<{ path: string; content: string; size: number }>> {
    const apiEndpoint = `https://api.github.com/repos/${parsed.owner}/${parsed.repo}/contents/${parsed.path}?ref=${parsed.branch}`
    const res = await fetch(apiEndpoint, {
      headers: {
        Accept: 'application/vnd.github.v3+json',
        'User-Agent': 'DevMate-Skills-Installer/1.0'
      },
      signal: AbortSignal.timeout(15000)
    })

    if (!res.ok) {
      if (res.status === 403) {
        throw new Error('GitHub API rate limit exceeded. Please wait or try direct raw URL.')
      }
      throw new Error(`Failed to fetch from GitHub (HTTP ${res.status}): ${res.statusText}`)
    }

    const items = (await res.json()) as Array<{ name: string; path: string; type: string; download_url?: string; size: number }>
    if (!Array.isArray(items)) {
      throw new Error('Specified GitHub path does not point to a directory.')
    }

    const files: Array<{ path: string; content: string; size: number }> = []
    for (const item of items) {
      if (item.type === 'file' && item.download_url) {
        const fileRes = await fetch(item.download_url)
        if (fileRes.ok) {
          const content = await fileRes.text()
          files.push({
            path: item.name,
            content,
            size: item.size
          })
        }
      }
    }

    return files
  }
}
