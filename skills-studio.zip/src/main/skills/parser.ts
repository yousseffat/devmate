import yaml from 'yaml'
import path from 'path'

export interface ParsedSkillMd {
  isValid: boolean
  name?: string
  description?: string
  rawFrontmatter?: Record<string, unknown>
  markdownBody?: string
  errorMessage?: string
  suggestRename?: boolean
}

export class SkillParser {
  static parseSkillMd(content: string, folderName?: string): ParsedSkillMd {
    if (!content || !content.trim()) {
      return { isValid: false, errorMessage: 'SKILL.md is empty' }
    }

    const frontmatterRegex = /^---\r?\n([\s\S]*?)\r?\n---/
    const match = content.match(frontmatterRegex)
    if (!match) {
      return { isValid: false, errorMessage: 'Missing YAML frontmatter (---) in SKILL.md' }
    }

    const rawYaml = match[1]
    const markdownBody = content.slice(match[0].length).trim()

    let parsed: Record<string, unknown>
    try {
      parsed = yaml.parse(rawYaml) || {}
    } catch (e) {
      return { isValid: false, errorMessage: `Malformed YAML frontmatter: ${(e as Error).message}` }
    }

    const name = typeof parsed.name === 'string' ? parsed.name.trim() : ''
    const description = typeof parsed.description === 'string' ? parsed.description.trim() : ''

    if (!name) {
      return { isValid: false, errorMessage: 'Missing "name" field in frontmatter.' }
    }

    if (name.length > 64) {
      return { isValid: false, errorMessage: 'Skill name exceeds maximum length of 64 characters.' }
    }

    if (!/^[a-z0-9-]+$/.test(name)) {
      return {
        isValid: false,
        errorMessage: 'Skill name must only contain lowercase letters, numbers, and hyphens (a-z, 0-9, -).'
      }
    }

    if (!description) {
      return { isValid: false, errorMessage: 'Missing "description" field in frontmatter.' }
    }

    if (description.length > 1024) {
      return { isValid: false, errorMessage: 'Skill description exceeds maximum length of 1024 characters.' }
    }

    const suggestRename = Boolean(folderName && folderName !== name)

    return {
      isValid: true,
      name,
      description,
      rawFrontmatter: parsed,
      markdownBody,
      suggestRename
    }
  }

  static isSafeZipEntry(targetDir: string, entryName: string): boolean {
    if (entryName.includes('..') || entryName.startsWith('/') || entryName.startsWith('\\')) {
      return false
    }
    const resolvedTarget = path.resolve(targetDir)
    const resolvedEntry = path.resolve(resolvedTarget, entryName)
    return resolvedEntry.startsWith(resolvedTarget + path.sep) || resolvedEntry === resolvedTarget
  }
}
