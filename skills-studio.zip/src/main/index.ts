import { app, BrowserWindow, ipcMain, dialog, shell } from 'electron'
import path from 'path'
import { StoreManager } from './store'
import { ProviderRegistry } from './providers/registry'
import { SkillRegistry } from './skills/registry'
import { SkillsTools } from './tools/skillsTools'
import { ToolRegistry } from './tools/registry'
import { PermissionManager } from './agent/permissions'
import { SystemPromptBuilder } from './agent/systemPrompt'
import { AgentLoop } from './agent/loop'
import { ToolchainDetector } from './toolchain/detect'
import { ToolchainInstaller } from './toolchain/install'
import { AndroidBuilder } from './build/android'
import { BuildExporter } from './build/export'
import { SeenTracker } from './radar/seen'
import { RadarResearcher } from './radar/research'
import { ApprovalRequest, ChatSession } from '../shared/types'

let mainWindow: BrowserWindow | null = null
const storeManager = new StoreManager()
const skillRegistry = new SkillRegistry()
const seenTracker = new SeenTracker(storeManager.getUserDataDir())
let currentWorkspace = process.cwd()

const pendingApprovals: Map<string, (allowed: boolean) => void> = new Map()
const activeAbortControllers: Map<string, AbortController> = new Map()

function createWindow(): void {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 840,
    minWidth: 1000,
    minHeight: 700,
    frame: false,
    titleBarStyle: 'hidden',
    backgroundColor: '#14161a',
    webPreferences: {
      preload: path.join(__dirname, '../preload/index.js'),
      sandbox: true,
      contextIsolation: true,
      nodeIntegration: false
    }
  })

  if (process.env.ELECTRON_RENDERER_URL) {
    mainWindow.loadURL(process.env.ELECTRON_RENDERER_URL)
  } else {
    mainWindow.loadFile(path.join(__dirname, '../renderer/index.html'))
  }
}

app.whenReady().then(() => {
  createWindow()

  // Setup IPC Handlers
  ipcMain.handle('getSettings', () => storeManager.getSettingsForRenderer())
  ipcMain.handle('saveSettings', (_, s) => storeManager.saveSettings(s))

  ipcMain.handle('selectWorkspaceFolder', async () => {
    if (!mainWindow) return null
    const res = await dialog.showOpenDialog(mainWindow, { properties: ['openDirectory'] })
    if (!res.canceled && res.filePaths[0]) {
      currentWorkspace = res.filePaths[0]
      return currentWorkspace
    }
    return null
  })

  ipcMain.handle('selectFile', async () => {
    if (!mainWindow) return null
    const res = await dialog.showOpenDialog(mainWindow, { properties: ['openFile'] })
    return !res.canceled ? res.filePaths[0] : null
  })

  ipcMain.handle('openInExplorer', (_, p) => {
    shell.openPath(p)
  })

  ipcMain.handle('listChats', () => storeManager.getChats())
  ipcMain.handle('saveChat', (_, chat: ChatSession) => {
    const chats = storeManager.getChats()
    const idx = chats.findIndex((c) => c.id === chat.id)
    if (idx >= 0) chats[idx] = chat
    else chats.unshift(chat)
    storeManager.saveChats(chats)
  })
  ipcMain.handle('deleteChat', (_, id: string) => {
    const chats = storeManager.getChats().filter((c) => c.id !== id)
    storeManager.saveChats(chats)
  })

  // Skills IPC
  ipcMain.handle('listSkills', () => {
    const settings = storeManager.getSettings()
    return skillRegistry.scanFolders(settings.skillFolders)
  })
  ipcMain.handle('toggleSkill', (_, name: string, enabled: boolean) => {
    skillRegistry.toggleSkill(name, enabled)
  })
  ipcMain.handle('searchSkillsOnline', (_, q: string) => {
    return skillRegistry.searchOnline(q)
  })
  ipcMain.handle('refreshSkills', () => {
    const settings = storeManager.getSettings()
    return skillRegistry.scanFolders(settings.skillFolders)
  })
  ipcMain.handle('uninstallSkill', (_, name: string) => {
    return skillRegistry.uninstallSkill(name)
  })

  // Toolchain & Build IPC
  ipcMain.handle('checkToolchain', () => ToolchainDetector.checkAll())
  ipcMain.handle('installToolchainItem', async (_, id: string) => {
    const items = ToolchainDetector.checkAll()
    const target = items.find((i) => i.id === id)
    if (target?.wingetPackageId) {
      await ToolchainInstaller.installItem(currentWorkspace, target.wingetPackageId)
    }
  })
  ipcMain.handle('acceptAndroidLicenses', () => ToolchainInstaller.acceptAndroidLicenses(currentWorkspace))
  ipcMain.handle('installArtifact', async (_, p: string) => {
    if (p.endsWith('.apk')) {
      await BuildExporter.installOnDevice(p)
    } else {
      await BuildExporter.runWindowsInstaller(p)
    }
  })

  // Radar IPC
  ipcMain.handle('checkUpdatesNow', () => RadarResearcher.checkUpdates(seenTracker))
  ipcMain.handle('getUpdates', () => RadarResearcher.checkUpdates(seenTracker))

  // Approval IPC
  ipcMain.handle('respondApproval', (_, reqId: string, allowed: boolean) => {
    const resolver = pendingApprovals.get(reqId)
    if (resolver) {
      resolver(allowed)
      pendingApprovals.delete(reqId)
    }
  })

  // Agent Message Execution
  ipcMain.handle('sendMessage', async (_, sessionId: string, text: string) => {
    const settings = storeManager.getInternalSettings()
    const permissionMgr = new PermissionManager(settings.permissionMode)

    const requestApproval = (request: ApprovalRequest): Promise<boolean> => {
      return new Promise((resolve) => {
        pendingApprovals.set(request.id, resolve)
        mainWindow?.webContents.send('approvalRequested', request)
      })
    }

    const skillsTools = new SkillsTools(skillRegistry, storeManager.getUserDataDir(), async (pending) => {
      return requestApproval({
        id: `skill_${Date.now()}`,
        kind: 'skill',
        name: pending.name,
        description: pending.description,
        details: { skillInstall: pending }
      })
    })

    const toolRegistry = new ToolRegistry(
      currentWorkspace,
      skillsTools,
      settings.braveApiKey,
      async (command) => {
        if (!permissionMgr.requiresCommandApproval()) return true
        return requestApproval({
          id: `cmd_${Date.now()}`,
          kind: 'tool',
          name: 'run_command',
          description: 'Terminal Command Execution',
          details: { command }
        })
      },
      async (file, before, after) => {
        if (!permissionMgr.requiresFileEditApproval()) return true
        return requestApproval({
          id: `edit_${Date.now()}`,
          kind: 'tool',
          name: 'edit_file',
          description: 'Workspace File Modification',
          details: { diff: { file, before, after } }
        })
      }
    )

    const adapter = ProviderRegistry.createAdapter(settings.modelConfig)
    const skills = skillRegistry.scanFolders(settings.skillFolders)
    const systemPrompt = SystemPromptBuilder.buildPrompt(skills, settings.language)

    const chats = storeManager.getChats()
    let chat = chats.find((c) => c.id === sessionId)
    if (!chat) {
      chat = {
        id: sessionId,
        title: text.slice(0, 30),
        createdAt: Date.now(),
        updatedAt: Date.now(),
        workspacePath: currentWorkspace,
        messages: []
      }
      chats.unshift(chat)
    }

    chat.messages.push({
      id: `msg_u_${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: Date.now()
    })

    const abortController = new AbortController()
    activeAbortControllers.set(sessionId, abortController)

    const messagesWithSystem = [
      { id: 'sys', role: 'system' as const, content: systemPrompt, timestamp: 0 },
      ...chat.messages
    ]

    try {
      const updatedMessages = await AgentLoop.run(
        adapter,
        toolRegistry,
        messagesWithSystem,
        (token) => {
          mainWindow?.webContents.send('agentStream', { sessionId, token })
        },
        (name, status, info) => {
          mainWindow?.webContents.send('toolActivity', { name, status, info })
        },
        abortController.signal
      )

      chat.messages = updatedMessages.filter((m) => m.role !== 'system')
      chat.updatedAt = Date.now()
      storeManager.saveChats(chats)
      mainWindow?.webContents.send('agentStream', { sessionId, done: true })
    } finally {
      activeAbortControllers.delete(sessionId)
    }
  })

  ipcMain.handle('stopAgent', (_, sessionId: string) => {
    const controller = activeAbortControllers.get(sessionId)
    if (controller) {
      controller.abort()
      activeAbortControllers.delete(sessionId)
    }
  })
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit()
})
