import { execSync } from 'child_process'
import fs from 'fs'
import path from 'path'
import { ToolchainItem } from '../../shared/types'

export class ToolchainDetector {
  static checkAll(): ToolchainItem[] {
    return [
      this.checkJdk(),
      this.checkAndroidSdk(),
      this.checkAdb(),
      this.checkNode(),
      this.checkGradle()
    ]
  }

  private static checkJdk(): ToolchainItem {
    try {
      const output = execSync('java -version 2>&1', { encoding: 'utf-8' })
      const match = output.match(/version "([0-9._]+)"/)
      const version = match ? match[1] : 'Installed'
      const major = parseInt(version.split('.')[0] || '0', 10)
      return {
        id: 'jdk',
        name: 'Java Development Kit (JDK 17+)',
        isInstalled: major >= 17,
        version,
        wingetPackageId: 'Microsoft.OpenJDK.17',
        notes: major < 17 ? 'JDK version must be 17 or higher for modern Android Gradle builds.' : undefined
      }
    } catch {
      return {
        id: 'jdk',
        name: 'Java Development Kit (JDK 17+)',
        isInstalled: false,
        wingetPackageId: 'Microsoft.OpenJDK.17',
        notes: 'Required for building Android applications.'
      }
    }
  }

  private static checkAndroidSdk(): ToolchainItem {
    const sdkRoot = process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT
    if (sdkRoot && fs.existsSync(sdkRoot)) {
      const hasPlatformTools = fs.existsSync(path.join(sdkRoot, 'platform-tools'))
      return {
        id: 'android-sdk',
        name: 'Android SDK (Platform & Build Tools)',
        isInstalled: hasPlatformTools,
        version: sdkRoot,
        wingetPackageId: 'Google.AndroidStudio',
        notes: hasPlatformTools ? undefined : 'Android SDK platform-tools folder not found.'
      }
    }
    return {
      id: 'android-sdk',
      name: 'Android SDK (Platform & Build Tools)',
      isInstalled: false,
      wingetPackageId: 'Google.AndroidStudio',
      notes: 'Requires several GB of disk space. Install via Android Studio or winget.'
    }
  }

  private static checkAdb(): ToolchainItem {
    try {
      const output = execSync('adb version', { encoding: 'utf-8' })
      const match = output.match(/Android Debug Bridge version ([0-9.]+)/)
      return {
        id: 'adb',
        name: 'Android Debug Bridge (adb)',
        isInstalled: true,
        version: match ? match[1] : 'Installed'
      }
    } catch {
      return {
        id: 'adb',
        name: 'Android Debug Bridge (adb)',
        isInstalled: false,
        notes: 'Required for installing and running APKs directly on connected Android phones.'
      }
    }
  }

  private static checkNode(): ToolchainItem {
    try {
      const output = execSync('node -v', { encoding: 'utf-8' }).trim()
      return {
        id: 'node',
        name: 'Node.js (LTS)',
        isInstalled: true,
        version: output
      }
    } catch {
      return {
        id: 'node',
        name: 'Node.js (LTS)',
        isInstalled: false,
        wingetPackageId: 'OpenJS.NodeJS.LTS'
      }
    }
  }

  private static checkGradle(): ToolchainItem {
    try {
      const output = execSync('gradle -v', { encoding: 'utf-8' })
      const match = output.match(/Gradle ([0-9.]+)/)
      return {
        id: 'gradle',
        name: 'Gradle Build Tool',
        isInstalled: true,
        version: match ? match[1] : 'Installed'
      }
    } catch {
      return {
        id: 'gradle',
        name: 'Gradle Build Tool',
        isInstalled: false,
        wingetPackageId: 'Gradle.Gradle',
        notes: 'Projects typically use their own gradlew wrapper.'
      }
    }
  }
}
