import { ShellTools } from '../tools/shell'

export class ToolchainInstaller {
  static async installItem(
    workspaceRoot: string,
    wingetPackageId: string
  ): Promise<{ stdout: string; stderr: string; exitCode: number }> {
    const cmd = `winget install --id ${wingetPackageId} -e --accept-package-agreements --accept-source-agreements`
    return ShellTools.runCommand(workspaceRoot, cmd, 300000)
  }

  static async acceptAndroidLicenses(
    workspaceRoot: string,
    sdkRoot?: string
  ): Promise<{ stdout: string; stderr: string; exitCode: number }> {
    const root = sdkRoot || process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT
    if (!root) {
      throw new Error('ANDROID_HOME or ANDROID_SDK_ROOT environment variable is not defined.')
    }
    const cmd = `echo y | "${root}/cmdline-tools/latest/bin/sdkmanager.bat" --licenses`
    return ShellTools.runCommand(workspaceRoot, cmd, 60000)
  }
}
