import path from 'path'
import { AndroidBuilder } from '../build/android'
import { DesktopBuilder } from '../build/desktop'

export class BuildTools {
  static scaffoldAndroid(workspaceRoot: string, appName: string, packageName: string): string {
    const target = path.join(workspaceRoot, appName)
    AndroidBuilder.scaffoldTemplate(target, appName, packageName)
    return `Scaffolded Android Jetpack Compose project at ${appName} with package ${packageName}`
  }

  static async buildAndroid(workspaceRoot: string, projectSubfolder: string, appName: string): Promise<string> {
    const projectDir = path.join(workspaceRoot, projectSubfolder)
    const result = await AndroidBuilder.buildLoop(projectDir, appName)
    if (result.success) {
      return `Build succeeded!\n${result.log}\nOutput APK: ${result.outputApkPath || 'Completed'}`
    }
    return `Build failed after retry attempts:\n${result.log}`
  }

  static async buildDesktop(workspaceRoot: string, projectSubfolder: string): Promise<string> {
    const projectDir = path.join(workspaceRoot, projectSubfolder)
    const result = await DesktopBuilder.buildElectron(projectDir)
    if (result.success) {
      return `Desktop application build and packaging succeeded!\n${result.log}`
    }
    return `Desktop build failed:\n${result.log}`
  }
}
