import fs from 'fs'
import path from 'path'
import { SandboxEnforcer } from './sandbox'

export class FsTools {
  static readFile(workspaceRoot: string, relPath: string): string {
    const fullPath = SandboxEnforcer.sanitizePath(workspaceRoot, relPath)
    if (!fs.existsSync(fullPath)) {
      throw new Error(`File not found: ${relPath}`)
    }
    const content = fs.readFileSync(fullPath, 'utf-8')
    return SandboxEnforcer.truncateOutput(content)
  }

  static writeFile(workspaceRoot: string, relPath: string, content: string): string {
    const fullPath = SandboxEnforcer.sanitizePath(workspaceRoot, relPath)
    fs.mkdirSync(path.dirname(fullPath), { recursive: true })
    fs.writeFileSync(fullPath, content, 'utf-8')
    return `Successfully wrote ${content.length} characters to ${relPath}`
  }

  static editFile(workspaceRoot: string, relPath: string, targetContent: string, replacementContent: string): string {
    const fullPath = SandboxEnforcer.sanitizePath(workspaceRoot, relPath)
    if (!fs.existsSync(fullPath)) {
      throw new Error(`File not found: ${relPath}`)
    }
    const current = fs.readFileSync(fullPath, 'utf-8')

    const firstIndex = current.indexOf(targetContent)
    if (firstIndex === -1) {
      throw new Error(`Target content not found in ${relPath}. Make sure the target text matches exactly.`)
    }

    const secondIndex = current.indexOf(targetContent, firstIndex + targetContent.length)
    if (secondIndex !== -1) {
      throw new Error(`Target content is not unique in ${relPath}. Found multiple occurrences. Include more surrounding lines.`)
    }

    const updated = current.slice(0, firstIndex) + replacementContent + current.slice(firstIndex + targetContent.length)
    fs.writeFileSync(fullPath, updated, 'utf-8')
    return `Successfully replaced unique block in ${relPath}`
  }

  static listDir(workspaceRoot: string, relPath: string = '.'): Array<{ name: string; isDirectory: boolean; size: number }> {
    const fullPath = SandboxEnforcer.sanitizePath(workspaceRoot, relPath)
    if (!fs.existsSync(fullPath)) {
      throw new Error(`Directory not found: ${relPath}`)
    }
    const entries = fs.readdirSync(fullPath, { withFileTypes: true })
    return entries.map((e) => {
      let size = 0
      try {
        if (!e.isDirectory()) {
          size = fs.statSync(path.join(fullPath, e.name)).size
        }
      } catch {}
      return {
        name: e.name,
        isDirectory: e.isDirectory(),
        size
      }
    })
  }

  static glob(workspaceRoot: string, pattern: string): string[] {
    const results: string[] = []
    const walk = (dir: string) => {
      const items = fs.readdirSync(dir, { withFileTypes: true })
      for (const item of items) {
        const full = path.join(dir, item.name)
        const rel = path.relative(workspaceRoot, full).replace(/\\/g, '/')
        if (item.isDirectory()) {
          if (item.name !== 'node_modules' && item.name !== '.git' && item.name !== 'build') {
            walk(full)
          }
        } else {
          // Simple regex matcher
          const regexPattern = new RegExp('^' + pattern.replace(/\./g, '\\.').replace(/\*/g, '.*') + '$')
          if (regexPattern.test(rel) || regexPattern.test(item.name)) {
            results.push(rel)
          }
        }
      }
    }
    walk(workspaceRoot)
    return results.slice(0, 100)
  }

  static grep(workspaceRoot: string, searchTerm: string): Array<{ file: string; line: number; text: string }> {
    const matches: Array<{ file: string; line: number; text: string }> = []
    const walk = (dir: string) => {
      if (matches.length >= 100) return
      const items = fs.readdirSync(dir, { withFileTypes: true })
      for (const item of items) {
        if (matches.length >= 100) break
        const full = path.join(dir, item.name)
        if (item.isDirectory()) {
          if (item.name !== 'node_modules' && item.name !== '.git' && item.name !== 'build') {
            walk(full)
          }
        } else {
          try {
            const content = fs.readFileSync(full, 'utf-8')
            const lines = content.split('\n')
            lines.forEach((l, idx) => {
              if (matches.length < 100 && l.includes(searchTerm)) {
                matches.push({
                  file: path.relative(workspaceRoot, full).replace(/\\/g, '/'),
                  line: idx + 1,
                  text: l.trim().slice(0, 150)
                })
              }
            })
          } catch {}
        }
      }
    }
    walk(workspaceRoot)
    return matches
  }
}
