import { SandboxEnforcer } from './sandbox'

export class WebTools {
  // Block private IPs: 10.x, 172.16-31, 192.168, 127.0.0.1, localhost, 169.254
  static isPrivateHost(hostname: string): boolean {
    const lower = hostname.toLowerCase()
    if (lower === 'localhost' || lower === '127.0.0.1' || lower === '::1') return true
    if (/^10\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(lower)) return true
    if (/^192\.168\.\d{1,3}\.\d{1,3}$/.test(lower)) return true
    if (/^169\.254\.\d{1,3}\.\d{1,3}$/.test(lower)) return true
    if (/^172\.(1[6-9]|2\d|3[0-1])\.\d{1,3}\.\d{1,3}$/.test(lower)) return true
    return false
  }

  static async fetchUrl(targetUrl: string): Promise<string> {
    const parsed = new URL(targetUrl)
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      throw new Error(`Invalid protocol: ${parsed.protocol}. Only http and https allowed.`)
    }

    if (this.isPrivateHost(parsed.hostname)) {
      throw new Error(`Access to private/local network address (${parsed.hostname}) is prohibited.`)
    }

    const res = await fetch(targetUrl, {
      headers: {
        'User-Agent': 'DevMate-Assistant/1.0'
      },
      signal: AbortSignal.timeout(15000)
    })

    if (!res.ok) {
      throw new Error(`HTTP fetch failed with status ${res.status}: ${res.statusText}`)
    }

    const raw = await res.text()
    // Basic readability/HTML strip
    const clean = raw
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
      .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '')
      .replace(/<[^>]+>/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()

    return SandboxEnforcer.truncateOutput(clean)
  }
}
