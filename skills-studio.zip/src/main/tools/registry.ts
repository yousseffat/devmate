import { ToolDefinition } from '../providers/types'
import { FsTools } from './fs'
import { ShellTools } from './shell'
import { WebTools } from './web'
import { SearchTools } from './search'
import { SkillsTools } from './skillsTools'
import { BuildTools } from './buildTools'

export class ToolRegistry {
  constructor(
    private workspaceRoot: string,
    private skillsTools: SkillsTools,
    private braveApiKey?: string,
    private onCommandApproval?: (command: string) => Promise<boolean>,
    private onEditApproval?: (file: string, before: string, after: string) => Promise<boolean>
  ) {}

  getToolDefinitions(): ToolDefinition[] {
    return [
      {
        name: 'read_file',
        description: 'Read the contents of a file inside the workspace.',
        parameters: {
          type: 'object',
          properties: {
            path: { type: 'string', description: 'Relative path to the file' }
          },
          required: ['path']
        }
      },
      {
        name: 'write_file',
        description: 'Create or overwrite a file with full content inside the workspace.',
        parameters: {
          type: 'object',
          properties: {
            path: { type: 'string', description: 'Relative path to the file' },
            content: { type: 'string', description: 'The complete file contents' }
          },
          required: ['path', 'content']
        }
      },
      {
        name: 'edit_file',
        description: 'Perform a single exact-match replacement in an existing file.',
        parameters: {
          type: 'object',
          properties: {
            path: { type: 'string', description: 'Relative path to the file' },
            target_content: { type: 'string', description: 'The exact string to replace' },
            replacement_content: { type: 'string', description: 'The replacement string' }
          },
          required: ['path', 'target_content', 'replacement_content']
        }
      },
      {
        name: 'list_dir',
        description: 'List files and directories in a given folder.',
        parameters: {
          type: 'object',
          properties: {
            path: { type: 'string', description: 'Relative path to list (default ".")' }
          }
        }
      },
      {
        name: 'glob',
        description: 'Find files matching a glob pattern inside the workspace.',
        parameters: {
          type: 'object',
          properties: {
            pattern: { type: 'string', description: 'Glob pattern like "*.kt" or "src/**/*.tsx"' }
          },
          required: ['pattern']
        }
      },
      {
        name: 'grep',
        description: 'Search for text across workspace files.',
        parameters: {
          type: 'object',
          properties: {
            query: { type: 'string', description: 'String to search for' }
          },
          required: ['query']
        }
      },
      {
        name: 'run_command',
        description: 'Execute a terminal command inside the workspace directory after user approval.',
        parameters: {
          type: 'object',
          properties: {
            command: { type: 'string', description: 'Shell command string to execute' }
          },
          required: ['command']
        }
      },
      {
        name: 'web_search',
        description: 'Search the public internet for documentation, libraries, or changelogs.',
        parameters: {
          type: 'object',
          properties: {
            query: { type: 'string', description: 'Search keywords' }
          },
          required: ['query']
        }
      },
      {
        name: 'web_fetch',
        description: 'Fetch and extract text content from an HTTP or HTTPS webpage.',
        parameters: {
          type: 'object',
          properties: {
            url: { type: 'string', description: 'Full URL to fetch' }
          },
          required: ['url']
        }
      },
      {
        name: 'activate_skill',
        description: 'Activate an installed skill by name to read its complete instructions.',
        parameters: {
          type: 'object',
          properties: {
            name: { type: 'string', description: 'Name of the skill to activate' }
          },
          required: ['name']
        }
      },
      {
        name: 'search_skills',
        description: 'Search the agent skills catalog online for domain-specific skills.',
        parameters: {
          type: 'object',
          properties: {
            query: { type: 'string', description: 'Keywords like "android", "electron"' }
          },
          required: ['query']
        }
      },
      {
        name: 'install_skill',
        description: 'Download and install a skill from GitHub or direct URL with user confirmation.',
        parameters: {
          type: 'object',
          properties: {
            source_url: { type: 'string', description: 'GitHub tree folder or direct SKILL.md URL' }
          },
          required: ['source_url']
        }
      },
      {
        name: 'create_new_skill',
        description: 'Author a new custom skill and install it locally with user approval.',
        parameters: {
          type: 'object',
          properties: {
            name: { type: 'string', description: 'Name of the skill (lowercase, hyphens, numbers)' },
            description: { type: 'string', description: 'Short summary under 1024 chars' },
            instructions: { type: 'string', description: 'Markdown body of instructions' },
            script_name: { type: 'string', description: 'Optional helper script filename' },
            script_content: { type: 'string', description: 'Optional helper script content' }
          },
          required: ['name', 'description', 'instructions']
        }
      },
      {
        name: 'list_skills',
        description: 'List all currently installed skills and their status.',
        parameters: { type: 'object', properties: {} }
      }
    ]
  }

  async executeTool(name: string, args: Record<string, unknown>, abortSignal?: AbortSignal): Promise<string> {
    switch (name) {
      case 'read_file':
        return FsTools.readFile(this.workspaceRoot, String(args.path))

      case 'write_file': {
        const filePath = String(args.path)
        const content = String(args.content)
        if (this.onEditApproval) {
          const approved = await this.onEditApproval(filePath, '', content)
          if (!approved) throw new Error('User declined write_file operation.')
        }
        return FsTools.writeFile(this.workspaceRoot, filePath, content)
      }

      case 'edit_file': {
        const filePath = String(args.path)
        const target = String(args.target_content)
        const replacement = String(args.replacement_content)
        if (this.onEditApproval) {
          const approved = await this.onEditApproval(filePath, target, replacement)
          if (!approved) throw new Error('User declined edit_file operation.')
        }
        return FsTools.editFile(this.workspaceRoot, filePath, target, replacement)
      }

      case 'list_dir':
        return JSON.stringify(FsTools.listDir(this.workspaceRoot, String(args.path || '.')))

      case 'glob':
        return JSON.stringify(FsTools.glob(this.workspaceRoot, String(args.pattern)))

      case 'grep':
        return JSON.stringify(FsTools.grep(this.workspaceRoot, String(args.query)))

      case 'run_command': {
        const cmd = String(args.command)
        if (this.onCommandApproval) {
          const approved = await this.onCommandApproval(cmd)
          if (!approved) throw new Error(`User rejected execution of command: ${cmd}`)
        }
        const res = await ShellTools.runCommand(this.workspaceRoot, cmd, 60000, abortSignal)
        return `Exit code: ${res.exitCode}\nSTDOUT:\n${res.stdout}\nSTDERR:\n${res.stderr}`
      }

      case 'web_search':
        return JSON.stringify(await SearchTools.search(String(args.query), this.braveApiKey))

      case 'web_fetch':
        return WebTools.fetchUrl(String(args.url))

      case 'activate_skill':
        return this.skillsTools.activateSkill(String(args.name))

      case 'search_skills':
        return this.skillsTools.searchSkills(String(args.query))

      case 'install_skill':
        return await this.skillsTools.installSkill(String(args.source_url))

      case 'create_new_skill':
        return await this.skillsTools.createNewSkill(
          String(args.name),
          String(args.description),
          String(args.instructions),
          args.script_name ? String(args.script_name) : undefined,
          args.script_content ? String(args.script_content) : undefined
        )

      case 'list_skills':
        return this.skillsTools.listSkills()

      default:
        throw new Error(`Unknown tool: ${name}`)
    }
  }
}
