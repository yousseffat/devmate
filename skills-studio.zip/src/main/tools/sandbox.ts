import { SecurityManager } from '../security'

export class SandboxEnforcer {
  static sanitizePath(workspaceRoot: string, targetPath: string): string {
    return SecurityManager.validateWorkspacePath(workspaceRoot, targetPath)
  }

  static truncateOutput(text: string, maxChars: number = 30000): string {
    if (text.length <= maxChars) return text
    const half = Math.floor(maxChars / 2)
    const head = text.slice(0, half)
    const tail = text.slice(-half)
    return `${head}\n\n... [TRUNCATED ${text.length - maxChars} CHARACTERS] ...\n\n${tail}`
  }
}
