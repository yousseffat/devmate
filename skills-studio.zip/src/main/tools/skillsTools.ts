import fs from 'fs'
import path from 'path'
import { SkillRegistry } from '../skills/registry'
import { SkillInstaller } from '../skills/installer'
import { PendingSkillInstall } from '../../shared/types'
import { SkillParser } from '../skills/parser'

export class SkillsTools {
  constructor(
    private registry: SkillRegistry,
    private userDataDir: string,
    private onApprovalNeeded: (pending: PendingSkillInstall) => Promise<boolean>
  ) {}

  activateSkill(name: string): string {
    const skill = this.registry.getSkill(name)
    if (!skill) {
      throw new Error(`Skill "${name}" not found. Use search_skills to discover it or list_skills to view available skills.`)
    }
    return `Skill "${name}" activated.\n\n# Full Instructions:\n${skill.skillMdContent}`
  }

  readSkillFile(name: string, relPath: string): string {
    const skill = this.registry.getSkill(name)
    if (!skill) throw new Error(`Skill "${name}" not found.`)

    if (relPath.includes('..') || relPath.startsWith('/') || relPath.startsWith('\\')) {
      throw new Error(`Security Exception: Traversal blocked in skill file access: ${relPath}`)
    }

    const fullPath = path.join(skill.folderPath, relPath)
    if (!fs.existsSync(fullPath)) throw new Error(`File ${relPath} not found in skill ${name}.`)

    return fs.readFileSync(fullPath, 'utf-8')
  }

  searchSkills(query: string): string {
    const candidates = this.registry.searchOnline(query)
    if (candidates.length === 0) {
      return `No skills found matching "${query}". You can install directly via GitHub URL using install_skill.`
    }
    return candidates
      .map(
        (c, idx) =>
          `${idx + 1}. **${c.name}**\n   - Description: ${c.description}\n   - Steps: ${c.stepsSummary.replace(/\n/g, ' ')}\n   - Source: ${c.sourceUrl}\n   - Scripts: ${c.hasScripts ? 'Yes (Requires approval)' : 'No'}`
      )
      .join('\n\n')
  }

  async installSkill(sourceUrl: string): Promise<string> {
    const pending = await SkillInstaller.prepareFromUrl(sourceUrl)
    const approved = await this.onApprovalNeeded(pending)
    if (!approved) {
      throw new Error(`User rejected installation of skill "${pending.name}". No files were copied.`)
    }

    const defaultSkillsFolder = path.join(this.userDataDir, 'skills')
    const installed = SkillInstaller.installApprovedSkill(pending, defaultSkillsFolder, this.userDataDir)
    this.registry.scanFolders([defaultSkillsFolder])

    return `تمت إضافة المهارة ${installed.name} بنجاح!\nالوصف: ${installed.description}\nأصبحت المهارة نشطة الآن ومتاحة فوراً للاستخدام بالدردشة.`
  }

  async createNewSkill(
    name: string,
    description: string,
    instructions: string,
    scriptName?: string,
    scriptContent?: string
  ): Promise<string> {
    const skillMd = `---\nname: ${name}\ndescription: ${description}\n---\n# ${name}\n${instructions}\n`
    const validation = SkillParser.parseSkillMd(skillMd)
    if (!validation.isValid) {
      throw new Error(`Invalid skill format: ${validation.errorMessage}`)
    }

    const files = [
      { relativePath: 'SKILL.md', sizeBytes: Buffer.byteLength(skillMd), isScript: false, content: skillMd }
    ]
    let hasScripts = false
    if (scriptName && scriptContent) {
      hasScripts = true
      files.push({
        relativePath: scriptName,
        sizeBytes: Buffer.byteLength(scriptContent),
        isScript: true,
        content: scriptContent
      })
    }

    const pending: PendingSkillInstall = {
      name: validation.name!,
      description: validation.description!,
      sourceUrl: 'author://devmate-assistant',
      files,
      skillMdContent: skillMd,
      hasScripts
    }

    const approved = await this.onApprovalNeeded(pending)
    if (!approved) {
      throw new Error(`User declined creation of new skill "${name}".`)
    }

    const defaultSkillsFolder = path.join(this.userDataDir, 'skills')
    const installed = SkillInstaller.installApprovedSkill(pending, defaultSkillsFolder, this.userDataDir)
    this.registry.scanFolders([defaultSkillsFolder])

    return `تم إنشاء وتثبيت المهارة الأصلية الجديدة ${installed.name} بنجاح بعد الموافقة!`
  }

  listSkills(): string {
    const skills = this.registry.getAll()
    const invalid = this.registry.getInvalidSkills()

    let text = ''
    if (skills.length === 0) {
      text += 'No valid skills currently installed.\n'
    } else {
      text += 'Installed Skills:\n'
      text += skills
        .map((s, idx) => `${idx + 1}. ${s.name} (${s.isEnabled ? 'Enabled' : 'Disabled'}) - ${s.description}`)
        .join('\n')
    }

    if (invalid.length > 0) {
      text += '\n\nInvalid Skills (Found errors):\n'
      text += invalid.map((inv, idx) => `${idx + 1}. ${inv.name} (${inv.folder}): ${inv.error}`).join('\n')
    }

    return text
  }

  uninstallSkill(name: string): string {
    const success = this.registry.uninstallSkill(name)
    if (!success) throw new Error(`Failed to uninstall skill "${name}". Skill does not exist.`)
    return `Skill "${name}" uninstalled successfully.`
  }
}
