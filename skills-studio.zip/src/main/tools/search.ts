export interface SearchResult {
  title: string
  url: string
  description: string
}

export class SearchTools {
  static async search(query: string, apiKey?: string): Promise<SearchResult[]> {
    if (!apiKey) {
      throw new Error(
        'Brave Search API key is missing. Please open Settings and enter your Brave Search API Key to enable online web searching.'
      )
    }

    const endpoint = `https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(query)}&count=5`
    const res = await fetch(endpoint, {
      headers: {
        Accept: 'application/json',
        'X-Subscription-Token': apiKey
      },
      signal: AbortSignal.timeout(10000)
    })

    if (!res.ok) {
      throw new Error(`Brave Search failed with HTTP ${res.status}: ${res.statusText}`)
    }

    const data = (await res.json()) as {
      web?: { results?: Array<{ title?: string; url?: string; description?: string }> }
    }

    return (
      data.web?.results?.map((r) => ({
        title: r.title || '',
        url: r.url || '',
        description: r.description || ''
      })) || []
    )
  }
}
