import { spawn } from 'child_process'
import { SandboxEnforcer } from './sandbox'
import { SecurityManager } from '../security'

export class ShellTools {
  static runCommand(
    workspaceRoot: string,
    command: string,
    timeoutMs: number = 60000,
    abortSignal?: AbortSignal
  ): Promise<{ stdout: string; stderr: string; exitCode: number }> {
    return new Promise((resolve, reject) => {
      if (SecurityManager.isCommandDestructive(command)) {
        return reject(new Error(`Security policy blocked destructive command: ${command}`))
      }

      const isWindows = process.platform === 'win32'
      const shellExecutable = isWindows ? 'cmd.exe' : '/bin/sh'
      const shellArgs = isWindows ? ['/d', '/s', '/c', command] : ['-c', command]

      const child = spawn(shellExecutable, shellArgs, {
        cwd: workspaceRoot,
        env: { ...process.env, CI: 'true' }
      })

      let stdout = ''
      let stderr = ''
      let timer: NodeJS.Timeout | null = null

      if (timeoutMs > 0) {
        timer = setTimeout(() => {
          child.kill()
          reject(new Error(`Command timed out after ${timeoutMs}ms: ${command}`))
        }, timeoutMs)
      }

      if (abortSignal) {
        abortSignal.addEventListener('abort', () => {
          child.kill()
          if (timer) clearTimeout(timer)
          reject(new Error('Command aborted by user.'))
        })
      }

      child.stdout.on('data', (d) => {
        stdout += d.toString()
      })

      child.stderr.on('data', (d) => {
        stderr += d.toString()
      })

      child.on('close', (code) => {
        if (timer) clearTimeout(timer)
        resolve({
          stdout: SandboxEnforcer.truncateOutput(stdout),
          stderr: SandboxEnforcer.truncateOutput(stderr),
          exitCode: code ?? 0
        })
      })

      child.on('error', (err) => {
        if (timer) clearTimeout(timer)
        reject(err)
      })
    })
  }
}
