import { app } from 'electron'
import path from 'path'
import fs from 'fs'
import { AppSettings, ChatSession } from '../shared/types'
import { SecurityManager } from './security'

export class StoreManager {
  private userDataDir: string
  private settingsFilePath: string
  private chatsFilePath: string

  constructor() {
    this.userDataDir = app ? app.getPath('userData') : path.join(process.cwd(), '.devmate-data')
    if (!fs.existsSync(this.userDataDir)) {
      fs.mkdirSync(this.userDataDir, { recursive: true })
    }
    this.settingsFilePath = path.join(this.userDataDir, 'settings.json')
    this.chatsFilePath = path.join(this.userDataDir, 'chats.json')
  }

  getUserDataDir(): string {
    return this.userDataDir
  }

  // Internal settings containing decrypted secrets for Main process only
  getInternalSettings(): AppSettings {
    const defaults: AppSettings = {
      modelConfig: {
        provider: 'gemini',
        modelId: 'gemini-1.5-flash',
        baseUrl: 'https://generativelanguage.googleapis.com/v1beta/openai/'
      },
      permissionMode: 'ask',
      accentColor: '#ff8a3d',
      skillFolders: [
        path.join(this.userDataDir, 'skills'),
        path.join(app ? app.getPath('home') : process.cwd(), '.claude', 'skills')
      ],
      updateCheckIntervalDays: 10,
      watchList: ['Claude Code', 'Gemini CLI', 'OpenAI Codex', 'Cursor', 'Kimi'],
      launchAtStartup: false,
      maxIterations: 40,
      language: 'ar'
    }

    if (!fs.existsSync(this.settingsFilePath)) {
      return defaults
    }

    try {
      const raw = fs.readFileSync(this.settingsFilePath, 'utf-8')
      const parsed = JSON.parse(raw)
      const res = { ...defaults, ...parsed }
      if (parsed.encryptedApiKey) {
        res.modelConfig = {
          ...res.modelConfig,
          apiKey: SecurityManager.decryptSecret(parsed.encryptedApiKey)
        }
      }
      if (parsed.encryptedBraveKey) {
        res.braveApiKey = SecurityManager.decryptSecret(parsed.encryptedBraveKey)
      }
      return res
    } catch {
      return defaults
    }
  }

  // Sanitized settings for Renderer (API keys NEVER reach renderer)
  getSettingsForRenderer(): AppSettings {
    const internal = this.getInternalSettings()
    return {
      ...internal,
      modelConfig: {
        ...internal.modelConfig,
        apiKey: undefined, // Never send raw key to renderer
        hasApiKey: Boolean(internal.modelConfig.apiKey && internal.modelConfig.apiKey.length > 0)
      },
      braveApiKey: undefined,
      hasBraveApiKey: Boolean(internal.braveApiKey && internal.braveApiKey.length > 0)
    }
  }

  saveSettings(settings: Partial<AppSettings>): AppSettings {
    const current = this.getInternalSettings()
    const merged: AppSettings = {
      ...current,
      ...settings,
      modelConfig: { ...current.modelConfig, ...settings.modelConfig }
    }

    const toStore: Record<string, unknown> = {
      ...merged,
      encryptedApiKey: undefined,
      encryptedBraveKey: undefined
    }

    // Encrypt new key if provided
    if (settings.modelConfig?.apiKey) {
      toStore.encryptedApiKey = SecurityManager.encryptSecret(settings.modelConfig.apiKey)
    } else if (current.modelConfig.apiKey) {
      toStore.encryptedApiKey = SecurityManager.encryptSecret(current.modelConfig.apiKey)
    }

    if (settings.braveApiKey) {
      toStore.encryptedBraveKey = SecurityManager.encryptSecret(settings.braveApiKey)
    } else if (current.braveApiKey) {
      toStore.encryptedBraveKey = SecurityManager.encryptSecret(current.braveApiKey)
    }

    // Do not store plain text keys in json
    toStore.modelConfig = { ...merged.modelConfig, apiKey: undefined }
    toStore.braveApiKey = undefined

    fs.writeFileSync(this.settingsFilePath, JSON.stringify(toStore, null, 2), 'utf-8')
    return this.getSettingsForRenderer()
  }

  getChats(): ChatSession[] {
    if (!fs.existsSync(this.chatsFilePath)) {
      return []
    }
    try {
      return JSON.parse(fs.readFileSync(this.chatsFilePath, 'utf-8'))
    } catch {
      return []
    }
  }

  saveChats(chats: ChatSession[]): void {
    fs.writeFileSync(this.chatsFilePath, JSON.stringify(chats, null, 2), 'utf-8')
  }
}
