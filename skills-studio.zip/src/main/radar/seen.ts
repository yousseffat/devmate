import fs from 'fs'
import path from 'path'
import crypto from 'crypto'

export class SeenTracker {
  private seenFilePath: string
  private seenHashes: Set<string> = new Set()

  constructor(userDataDir: string) {
    this.seenFilePath = path.join(userDataDir, 'radar-seen.json')
    this.load()
  }

  private load(): void {
    if (fs.existsSync(this.seenFilePath)) {
      try {
        const arr = JSON.parse(fs.readFileSync(this.seenFilePath, 'utf-8'))
        this.seenHashes = new Set(arr)
      } catch {}
    }
  }

  hasSeen(itemTitle: string, date: string): boolean {
    const hash = crypto.createHash('sha256').update(`${itemTitle}:${date}`).digest('hex')
    return this.seenHashes.has(hash)
  }

  markSeen(itemTitle: string, date: string): void {
    const hash = crypto.createHash('sha256').update(`${itemTitle}:${date}`).digest('hex')
    this.seenHashes.add(hash)
    this.save()
  }

  private save(): void {
    fs.writeFileSync(this.seenFilePath, JSON.stringify(Array.from(this.seenHashes), null, 2), 'utf-8')
  }
}
