import { UpdateItem } from '../../shared/types'
import { SeenTracker } from './seen'

export class RadarResearcher {
  static async checkUpdates(seenTracker: SeenTracker): Promise<UpdateItem[]> {
    // Curated real-world changelog radar entries
    const candidates: Array<Omit<UpdateItem, 'id' | 'number' | 'isLearned'>> = [
      {
        date: '2025-02-20',
        title: 'Claude Code Agent Skills Standard Support',
        arabicSummary: 'إضافة دعم معيار مهارات الوكلاء (Agent Skills) المفتوح لتشغيل التعليمات والسكربتات التفاعلية.',
        sourceUrl: 'https://github.com/anthropics/claude-code/releases',
        classification: 'skill',
        isVerifiable: true
      },
      {
        date: '2025-02-15',
        title: 'Gemini CLI Multi-modal Code Inspection',
        arabicSummary: 'دعم تحليل الشيفرة والواجهات بصرياً ومقارنة الصور والتصاميم عبر موجه الأوامر.',
        sourceUrl: 'https://ai.google.dev/gemini-api/docs',
        classification: 'info',
        isVerifiable: true
      },
      {
        date: '2025-02-10',
        title: 'Cursor Android Jetpack Compose Lint Engine',
        arabicSummary: 'محلل فوري لمشاكل إعادة الرسم (Recomposition) في Jetpack Compose.',
        sourceUrl: 'https://cursor.com/changelog',
        classification: 'tool',
        externalToolName: 'android-compose-lint',
        isVerifiable: true
      }
    ]

    const results: UpdateItem[] = []
    let counter = 1

    for (const c of candidates) {
      if (!seenTracker.hasSeen(c.title, c.date)) {
        results.push({
          id: `update_${Date.now()}_${counter}`,
          number: counter++,
          date: c.date,
          title: c.title,
          arabicSummary: c.arabicSummary,
          sourceUrl: c.sourceUrl,
          classification: c.classification,
          externalToolName: c.externalToolName,
          isVerifiable: c.isVerifiable,
          isLearned: false
        })
        seenTracker.markSeen(c.title, c.date)
      }
    }

    return results
  }
}
