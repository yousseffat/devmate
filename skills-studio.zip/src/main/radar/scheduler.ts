import fs from 'fs'
import path from 'path'

export interface RadarScheduleState {
  lastCheckTimestamp: number
  intervalDays: number
}

export class RadarScheduler {
  private stateFilePath: string

  constructor(userDataDir: string) {
    this.stateFilePath = path.join(userDataDir, 'radar-schedule.json')
  }

  getState(defaultIntervalDays: number = 10): RadarScheduleState {
    if (fs.existsSync(this.stateFilePath)) {
      try {
        return JSON.parse(fs.readFileSync(this.stateFilePath, 'utf-8'))
      } catch {}
    }
    return {
      lastCheckTimestamp: 0,
      intervalDays: defaultIntervalDays
    }
  }

  isCheckOverdue(defaultIntervalDays: number = 10): boolean {
    const state = this.getState(defaultIntervalDays)
    if (state.lastCheckTimestamp === 0) return true
    const elapsedDays = (Date.now() - state.lastCheckTimestamp) / (1000 * 60 * 60 * 24)
    return elapsedDays >= state.intervalDays
  }

  recordCheckNow(intervalDays: number = 10): void {
    const state: RadarScheduleState = {
      lastCheckTimestamp: Date.now(),
      intervalDays
    }
    fs.writeFileSync(this.stateFilePath, JSON.stringify(state, null, 2), 'utf-8')
  }
}
