import React from 'react'
import { ChatSession } from '../../shared/types'

interface SidebarProps {
  workspace: string
  onSelectWorkspace: () => void
  chats: ChatSession[]
  activeChatId: string | null
  onSelectChat: (id: string) => void
  onNewChat: () => void
  currentPage: string
  onSelectPage: (page: string) => void
  skillsCount: number
  unseenUpdatesCount: number
}

export const Sidebar: React.FC<SidebarProps> = ({
  workspace,
  onSelectWorkspace,
  chats,
  activeChatId,
  onSelectChat,
  onNewChat,
  currentPage,
  onSelectPage,
  skillsCount,
  unseenUpdatesCount
}) => {
  return (
    <aside className="sidebar-left">
      <button
        onClick={onSelectWorkspace}
        style={{
          width: '100%',
          textAlign: 'right',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          whiteSpace: 'nowrap',
          fontSize: '12px'
        }}
        title={workspace}
      >
        📁 {workspace.split(/[/|\\]/).pop() || 'اختر مجلد العمل'}
      </button>

      <button className="btn-accent" onClick={onNewChat} style={{ width: '100%' }}>
        + محادثة جديدة
      </button>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', overflowY: 'auto', maxHeight: '200px' }}>
        {chats.map((c) => (
          <button
            key={c.id}
            onClick={() => onSelectChat(c.id)}
            style={{
              width: '100%',
              justifyContent: 'flex-start',
              background: activeChatId === c.id ? 'var(--bg-card)' : 'transparent',
              border: 'none',
              padding: '6px 10px',
              minHeight: '36px',
              fontSize: '13px'
            }}
          >
            💬 {c.title || 'محادثة جديدة'}
          </button>
        ))}
      </div>

      <div style={{ flex: 1 }} />

      <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
        <button
          onClick={() => onSelectPage('chat')}
          style={{ width: '100%', background: currentPage === 'chat' ? 'var(--bg-card)' : undefined }}
        >
          💬 الدردشة والمساعد
        </button>

        <button
          onClick={() => onSelectPage('skills')}
          style={{ width: '100%', background: currentPage === 'skills' ? 'var(--bg-card)' : undefined }}
        >
          🧩 المهارات ({skillsCount})
        </button>

        <button
          onClick={() => onSelectPage('updates')}
          style={{
            width: '100%',
            background: currentPage === 'updates' ? 'var(--bg-card)' : undefined,
            position: 'relative'
          }}
        >
          📡 التحديثات
          {unseenUpdatesCount > 0 && (
            <span
              style={{
                background: 'var(--accent)',
                color: 'var(--on-accent)',
                fontWeight: 700,
                fontSize: '11px',
                padding: '2px 6px',
                borderRadius: '10px',
                marginRight: '6px'
              }}
            >
              {unseenUpdatesCount} جديد
            </span>
          )}
        </button>

        <button
          onClick={() => onSelectPage('build')}
          style={{ width: '100%', background: currentPage === 'build' ? 'var(--bg-card)' : undefined }}
        >
          🔨 البناء والتثبيت
        </button>

        <button
          onClick={() => onSelectPage('settings')}
          style={{ width: '100%', background: currentPage === 'settings' ? 'var(--bg-card)' : undefined }}
        >
          ⚙️ الإعدادات
        </button>
      </div>
    </aside>
  )
}
