import React, { useState } from 'react'
import { ToolCall, ToolResult } from '../../shared/types'

interface ToolCardProps {
  toolCall: ToolCall
  toolResult?: ToolResult
}

export const ToolCard: React.FC<ToolCardProps> = ({ toolCall, toolResult }) => {
  const [expanded, setExpanded] = useState(false)

  const isSuccess = toolResult && !toolResult.isError
  const isError = toolResult && toolResult.isError
  const isRunning = !toolResult

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', margin: '4px 0' }}>
      <div className="tool-row" onClick={() => setExpanded(!expanded)}>
        <span>⚡ أداة: {toolCall.name}</span>
        <span>
          {isRunning && '⏳ جاري التشغيل...'}
          {isSuccess && <span className="tool-status-ok">✓</span>}
          {isError && <span style={{ color: '#ef4444' }}>✗</span>}
        </span>
      </div>

      {expanded && (
        <div
          style={{
            backgroundColor: 'var(--bg-card)',
            border: '1px solid var(--line-card)',
            borderRadius: '8px',
            padding: '10px',
            fontFamily: "Consolas, 'Cascadia Mono', monospace",
            fontSize: '12px',
            whiteSpace: 'pre-wrap',
            maxHeight: '200px',
            overflowY: 'auto'
          }}
        >
          <div style={{ color: 'var(--muted)', marginBottom: '4px' }}>
            المدخلات: {JSON.stringify(toolCall.arguments, null, 2)}
          </div>
          {toolResult && (
            <div style={{ color: isError ? '#ef4444' : 'var(--text)' }}>النتيجة: {toolResult.output}</div>
          )}
        </div>
      )}
    </div>
  )
}
