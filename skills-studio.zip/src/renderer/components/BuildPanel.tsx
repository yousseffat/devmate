import React from 'react'
import { ToolchainItem, BuildProject } from '../../shared/types'

interface BuildPanelProps {
  toolchain: ToolchainItem[]
  projects: BuildProject[]
  onInstallTool: (id: string) => void
  onAcceptLicenses: () => void
  onBuildProject: (id: string) => void
  onInstallArtifact: (path: string) => void
  onOpenFolder: (path: string) => void
  isBuilding: boolean
}

export const BuildPanel: React.FC<BuildPanelProps> = ({
  toolchain,
  projects,
  onInstallTool,
  onAcceptLicenses,
  onBuildProject,
  onInstallArtifact,
  onOpenFolder,
  isBuilding
}) => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <div>
        <h2 style={{ fontSize: '18px', fontWeight: 700 }}>بيئة البناء والتثبيت (Build & Toolchain)</h2>
        <div style={{ fontSize: '12px', color: 'var(--muted)' }}>
          فحص جاهزية أدوات تطوير أندرويد وتطبيقات الويندوز
        </div>
      </div>

      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h3 style={{ fontSize: '15px', fontWeight: 700 }}>أدوات التطوير (Toolchain Checklist)</h3>
          <button
            onClick={onAcceptLicenses}
            style={{ fontSize: '12px', minHeight: '32px', padding: '4px 8px' }}
          >
            قبول تراخيص Android SDK
          </button>
        </div>

        {toolchain.map((item) => (
          <div
            key={item.id}
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: '6px 0',
              borderBottom: '1px solid var(--line)'
            }}
          >
            <div>
              <div style={{ fontWeight: 600 }}>{item.name}</div>
              {item.version && (
                <div style={{ fontSize: '11px', color: 'var(--muted)' }}>الإصدار: {item.version}</div>
              )}
            </div>

            <div>
              {item.isInstalled ? (
                <span style={{ color: 'var(--ok)', fontWeight: 700 }}>✓ جاهز</span>
              ) : (
                <button
                  className="btn-accent"
                  style={{ minHeight: '32px', padding: '4px 10px', fontSize: '12px' }}
                  onClick={() => onInstallTool(item.id)}
                >
                  تثبيت
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
        <h3 style={{ fontSize: '15px', fontWeight: 700 }}>المشاريع المبنية</h3>
        {projects.length === 0 ? (
          <div className="card" style={{ color: 'var(--muted)', textAlign: 'center', padding: '16px' }}>
            لا توجد مشاريع مبنية حالياً. اطلب من المساعد في الدردشة بناء أو تصدير تطبيقك.
          </div>
        ) : (
          projects.map((proj) => (
            <div key={proj.id} className="card" style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontWeight: 700 }}>{proj.name}</span>
                {proj.lastBuildSuccess && (
                  <span style={{ color: 'var(--ok)', fontSize: '12px' }}>بُني بنجاح ✓</span>
                )}
              </div>

              {proj.outputArtifactPath && (
                <div style={{ fontSize: '12px', color: 'var(--muted)' }}>
                  الملف المولد: {proj.outputArtifactPath}
                </div>
              )}

              <div style={{ display: 'flex', gap: '8px', marginTop: '6px' }}>
                {proj.outputArtifactPath && (
                  <button
                    className="btn-accent"
                    style={{ flex: 1 }}
                    onClick={() => onInstallArtifact(proj.outputArtifactPath!)}
                  >
                    تثبيت التطبيق
                  </button>
                )}
                <button
                  style={{ flex: 1 }}
                  onClick={() => onOpenFolder(proj.outputArtifactPath ? proj.outputArtifactPath : proj.path)}
                >
                  فتح المجلد
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
