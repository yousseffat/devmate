import React, { useState, useEffect } from 'react'
import { AppSettings, AIProviderType } from '../../shared/types'

interface FirstRunWizardProps {
  onComplete: (settings: Partial<AppSettings>) => void
}

export const FirstRunWizard: React.FC<FirstRunWizardProps> = ({ onComplete }) => {
  const [selectedPath, setSelectedPath] = useState<'gemini' | 'ollama' | 'own'>('gemini')
  const [geminiKey, setGeminiKey] = useState('')
  const [ownProvider, setOwnProvider] = useState<AIProviderType>('anthropic')
  const [ownKey, setOwnKey] = useState('')
  const [ownModel, setOwnModel] = useState('claude-3-5-sonnet-20241022')
  const [ollamaDetected, setOllamaDetected] = useState(false)
  const [ollamaModels, setOllamaModels] = useState<string[]>([])

  useEffect(() => {
    // Check if Ollama is running locally
    fetch('http://localhost:11434/api/tags')
      .then((res) => res.json())
      .then((data: { models?: Array<{ name: string }> }) => {
        if (data.models && data.models.length > 0) {
          setOllamaDetected(true)
          setOllamaModels(data.models.map((m) => m.name))
        }
      })
      .catch(() => {
        setOllamaDetected(false)
      })
  }, [])

  const handleFinish = () => {
    if (selectedPath === 'gemini') {
      onComplete({
        modelConfig: {
          provider: 'gemini',
          modelId: 'gemini-1.5-flash',
          apiKey: geminiKey.trim(),
          baseUrl: 'https://generativelanguage.googleapis.com/v1beta/openai/'
        }
      })
    } else if (selectedPath === 'ollama') {
      onComplete({
        modelConfig: {
          provider: 'ollama',
          modelId: ollamaModels[0] || 'llama3.2',
          apiKey: 'dummy',
          baseUrl: 'http://localhost:11434/v1'
        }
      })
    } else {
      onComplete({
        modelConfig: {
          provider: ownProvider,
          modelId: ownModel.trim(),
          apiKey: ownKey.trim()
        }
      })
    }
  }

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        backgroundColor: 'rgba(20, 22, 26, 0.95)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 1000,
        padding: '20px'
      }}
    >
      <div
        className="card"
        style={{
          maxWidth: '680px',
          width: '100%',
          display: 'flex',
          flexDirection: 'column',
          gap: '16px',
          padding: '24px'
        }}
      >
        <div style={{ textAlign: 'center' }}>
          <h1 style={{ fontSize: '22px', fontWeight: 700, color: 'var(--accent)' }}>مرحباً بك في DevMate! 🚀</h1>
          <div style={{ color: 'var(--muted)', fontSize: '13px', marginTop: '4px' }}>
            اختر طريقة تشغيل الذكاء الاصطناعي الأنسب لك للبدء فوراً
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px' }}>
          <div
            className="card"
            style={{
              cursor: 'pointer',
              border: selectedPath === 'gemini' ? '2px solid var(--accent)' : '1px solid var(--line-card)'
            }}
            onClick={() => setSelectedPath('gemini')}
          >
            <div style={{ fontWeight: 700, marginBottom: '4px' }}>1. مفتاح مجاني (Gemini)</div>
            <div style={{ fontSize: '11px', color: 'var(--muted)' }}>
              من Google AI Studio. مجاني وسريع. (ملاحظة: الخدمة المجانية قد تخضع لحدود الاستخدام).
            </div>
          </div>

          <div
            className="card"
            style={{
              cursor: 'pointer',
              border: selectedPath === 'ollama' ? '2px solid var(--accent)' : '1px solid var(--line-card)'
            }}
            onClick={() => setSelectedPath('ollama')}
          >
            <div style={{ fontWeight: 700, marginBottom: '4px' }}>2. محلي مجاني (Ollama)</div>
            <div style={{ fontSize: '11px', color: 'var(--muted)' }}>
              يعمل بدون إنترنت وبخصوصية كاملة. (تنبيه: أبطأ ويتطلب جهازاً قوياً لتشغيل الأدوات).
            </div>
          </div>

          <div
            className="card"
            style={{
              cursor: 'pointer',
              border: selectedPath === 'own' ? '2px solid var(--accent)' : '1px solid var(--line-card)'
            }}
            onClick={() => setSelectedPath('own')}
          >
            <div style={{ fontWeight: 700, marginBottom: '4px' }}>3. مفتاحي الخاص</div>
            <div style={{ fontSize: '11px', color: 'var(--muted)' }}>
              Claude, OpenAI, Kimi أو أي رابط API متوافق. أعلى دقة واحترافية.
            </div>
          </div>
        </div>

        {selectedPath === 'gemini' && (
          <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <label style={{ fontSize: '13px' }}>أدخل مفتاح Gemini API Key:</label>
            <input
              className="input-field"
              type="password"
              placeholder="AIzaSy..."
              value={geminiKey}
              onChange={(e) => setGeminiKey(e.target.value)}
              style={{ background: 'var(--bg-tool)', padding: '10px', borderRadius: '8px' }}
            />
            <div style={{ fontSize: '11px', color: 'var(--muted)' }}>
              يمكنك الحصول على مفتاح مجاني من موقع: https://aistudio.google.com
            </div>
          </div>
        )}

        {selectedPath === 'ollama' && (
          <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <div style={{ fontSize: '13px' }}>حالة خادم Ollama المحلي:</div>
            {ollamaDetected ? (
              <div style={{ color: 'var(--ok)', fontWeight: 700 }}>
                ✓ تم اكتشاف Ollama بنجاح! النماذج المتوفرة: {ollamaModels.join(', ')}
              </div>
            ) : (
              <div style={{ color: 'var(--accent)', fontSize: '12px' }}>
                ⚠️ لم يتم العثور على خادم Ollama على المنفذ 11434. تأكد من تشغيل Ollama على جهازك.
              </div>
            )}
          </div>
        )}

        {selectedPath === 'own' && (
          <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <div style={{ display: 'flex', gap: '6px' }}>
              {(['anthropic', 'openai', 'kimi'] as AIProviderType[]).map((p) => (
                <button
                  key={p}
                  onClick={() => setOwnProvider(p)}
                  style={{
                    background: ownProvider === p ? 'var(--accent)' : 'var(--bg-btn)',
                    color: ownProvider === p ? 'var(--on-accent)' : 'var(--text)'
                  }}
                >
                  {p.toUpperCase()}
                </button>
              ))}
            </div>
            <input
              className="input-field"
              type="password"
              placeholder="أدخل مفتاح API الخاص بك..."
              value={ownKey}
              onChange={(e) => setOwnKey(e.target.value)}
              style={{ background: 'var(--bg-tool)', padding: '10px', borderRadius: '8px' }}
            />
          </div>
        )}

        <button className="btn-accent" style={{ width: '100%' }} onClick={handleFinish}>
          ابدأ استخدام DevMate الآن 🚀
        </button>
      </div>
    </div>
  )
}
