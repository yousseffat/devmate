import React, { useState } from 'react'
import { Skill, SkillCandidate } from '../../shared/types'

interface SkillsPanelProps {
  skills: Skill[]
  onToggleSkill: (name: string, enabled: boolean) => void
  onRemoveSkill: (name: string) => void
  onRefresh: () => void
  onInstallFromUrl: (url: string) => void
  onSearchOnline: (query: string) => Promise<SkillCandidate[]>
}

export const SkillsPanel: React.FC<SkillsPanelProps> = ({
  skills,
  onToggleSkill,
  onRemoveSkill,
  onRefresh,
  onInstallFromUrl,
  onSearchOnline
}) => {
  const [urlInput, setUrlInput] = useState('')
  const [searchQuery, setSearchQuery] = useState('')
  const [searchResults, setSearchResults] = useState<SkillCandidate[]>([])
  const [isSearching, setIsSearching] = useState(false)

  const handleSearch = async () => {
    if (!searchQuery.trim()) return
    setIsSearching(true)
    try {
      const results = await onSearchOnline(searchQuery)
      setSearchResults(results)
    } finally {
      setIsSearching(false)
    }
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h2 style={{ fontSize: '18px', fontWeight: 700 }}>إدارة مهارات الوكلاء (Agent Skills)</h2>
        <button onClick={onRefresh}>🔄 تحديث</button>
      </div>

      <div className="card" style={{ display: 'flex', gap: '8px' }}>
        <input
          className="input-field"
          style={{ background: 'var(--bg-tool)', padding: '8px 12px', borderRadius: '8px' }}
          type="text"
          placeholder="أدخل رابط GitHub أو ملف SKILL.md المباشر..."
          value={urlInput}
          onChange={(e) => setUrlInput(e.target.value)}
        />
        <button
          className="btn-accent"
          onClick={() => {
            if (urlInput.trim()) {
              onInstallFromUrl(urlInput.trim())
              setUrlInput('')
            }
          }}
        >
          تثبيت من رابط URL
        </button>
      </div>

      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <div style={{ display: 'flex', gap: '8px' }}>
          <input
            className="input-field"
            style={{ background: 'var(--bg-tool)', padding: '8px 12px', borderRadius: '8px' }}
            type="text"
            placeholder="ابحث عن مهارة أونلاين (مثل: android, electron)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
          />
          <button onClick={handleSearch} disabled={isSearching}>
            {isSearching ? 'جاري البحث...' : 'بحث أونلاين'}
          </button>
        </div>

        {searchResults.length > 0 && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginTop: '8px' }}>
            <div style={{ fontSize: '12px', color: 'var(--muted)' }}>نتائج البحث في المهارات المفتوحة:</div>
            {searchResults.map((cand) => (
              <div
                key={cand.name}
                style={{
                  background: 'var(--bg-tool)',
                  padding: '10px',
                  borderRadius: '8px',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}
              >
                <div>
                  <div style={{ fontWeight: 700 }}>{cand.name}</div>
                  <div style={{ fontSize: '12px', color: 'var(--muted)' }}>{cand.description}</div>
                </div>
                <button className="btn-accent" onClick={() => onInstallFromUrl(cand.sourceUrl)}>
                  تثبيت
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
        <h3 style={{ fontSize: '15px', fontWeight: 700 }}>المهارات المثبتة حالياً ({skills.length})</h3>
        {skills.map((skill) => (
          <div
            key={skill.name}
            className="card"
            style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}
          >
            <div>
              <div style={{ fontWeight: 700 }}>{skill.name}</div>
              <div style={{ fontSize: '12px', color: 'var(--muted)' }}>{skill.description}</div>
              <div style={{ fontSize: '11px', color: 'var(--muted)', marginTop: '4px' }}>
                📁 {skill.files.length} ملفات {skill.hasScripts && '• ⚠️ تحتوي سكربتات'}
              </div>
            </div>

            <div style={{ display: 'flex', gap: '8px' }}>
              <button
                onClick={() => onToggleSkill(skill.name, !skill.isEnabled)}
                style={{
                  background: skill.isEnabled ? 'rgba(74, 222, 128, 0.15)' : 'var(--bg-btn)',
                  color: skill.isEnabled ? 'var(--ok)' : 'var(--muted)'
                }}
              >
                {skill.isEnabled ? 'مفعّلة' : 'معطّلة'}
              </button>
              <button onClick={() => onRemoveSkill(skill.name)} style={{ color: '#ef4444' }}>
                حذف
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
