import React from 'react'

interface DiffViewProps {
  file: string
  before: string
  after: string
}

export const DiffView: React.FC<DiffViewProps> = ({ file, before, after }) => {
  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        gap: '6px',
        backgroundColor: 'var(--bg-tool)',
        padding: '10px',
        borderRadius: '8px',
        fontFamily: "Consolas, 'Cascadia Mono', monospace",
        fontSize: '12px'
      }}
    >
      <div style={{ color: 'var(--muted)', fontWeight: 700 }}>الملف: {file}</div>
      {before && (
        <div style={{ color: '#ef4444', backgroundColor: 'rgba(239, 68, 68, 0.1)', padding: '6px', borderRadius: '4px' }}>
          - {before}
        </div>
      )}
      <div style={{ color: 'var(--ok)', backgroundColor: 'rgba(74, 222, 128, 0.1)', padding: '6px', borderRadius: '4px' }}>
        + {after}
      </div>
    </div>
  )
}
