import React, { useState } from 'react'
import { UpdateItem } from '../../shared/types'

interface UpdatesPanelProps {
  updates: UpdateItem[]
  onCheckNow: () => void
  onLearnUpdate: (id: string) => void
  isChecking: boolean
}

export const UpdatesPanel: React.FC<UpdatesPanelProps> = ({
  updates,
  onCheckNow,
  onLearnUpdate,
  isChecking
}) => {
  const [selectedIds, setSelectedIds] = useState<string[]>([])

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    )
  }

  const handleLearnSelected = () => {
    selectedIds.forEach((id) => onLearnUpdate(id))
    setSelectedIds([])
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ fontSize: '18px', fontWeight: 700 }}>رادار التحديثات والتطورات (Updates Radar)</h2>
          <div style={{ fontSize: '12px', color: 'var(--muted)' }}>
            متابعة مستمرة لجديد Claude Code, Gemini CLI, Cursor, Kimi
          </div>
        </div>
        <div style={{ display: 'flex', gap: '8px' }}>
          {selectedIds.length > 0 && (
            <button className="btn-accent" onClick={handleLearnSelected}>
              علّمني المحدد ({selectedIds.length})
            </button>
          )}
          <button onClick={onCheckNow} disabled={isChecking}>
            {isChecking ? 'جاري الفحص...' : 'فحص الآن 📡'}
          </button>
        </div>
      </div>

      <div className="card" style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: 'var(--muted)' }}>
        <span>آخر فحص: اليوم (أحدث البيانات متوفرة)</span>
        <span>الفحص التلقائي القادم: خلال 10 أيام (أو عند بدء التشغيل إذا فات الموعد)</span>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
        {updates.length === 0 ? (
          <div className="card" style={{ textAlign: 'center', color: 'var(--muted)', padding: '24px' }}>
            لا توجد تحديثات جديدة غير مقروءة حالياً. اضغط "فحص الآن" لاستطلاع الجديد.
          </div>
        ) : (
          updates.map((item) => (
            <div key={item.id} className="card" style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <input
                    type="checkbox"
                    checked={selectedIds.includes(item.id)}
                    onChange={() => toggleSelect(item.id)}
                  />
                  <span style={{ fontWeight: 700, fontSize: '15px' }}>
                    #{item.number} {item.title}
                  </span>
                </div>
                <span style={{ fontSize: '12px', color: 'var(--muted)' }}>{item.date}</span>
              </div>

              <div style={{ fontSize: '13px' }}>{item.arabicSummary}</div>

              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '4px' }}>
                <span style={{ fontSize: '11px', color: 'var(--muted)' }}>المصدر: {item.sourceUrl}</span>
                {item.classification === 'skill' && (
                  <button
                    className="btn-accent"
                    style={{ minHeight: '34px', padding: '4px 10px', fontSize: '12px' }}
                    onClick={() => onLearnUpdate(item.id)}
                  >
                    تعلم هذه المهارة (Learn this)
                  </button>
                )}
                {item.classification === 'tool' && (
                  <span style={{ fontSize: '12px', color: 'var(--accent)' }}>
                    يحتاج أداة خارجية: {item.externalToolName}
                  </span>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
