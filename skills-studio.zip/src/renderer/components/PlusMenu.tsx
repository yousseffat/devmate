import React from 'react'

interface PlusMenuProps {
  onSelectFiles: () => void
  onSelectSkills: () => void
  onSelectFolder: () => void
  onClose: () => void
}

export const PlusMenu: React.FC<PlusMenuProps> = ({
  onSelectFiles,
  onSelectSkills,
  onSelectFolder,
  onClose
}) => {
  return (
    <div
      style={{
        position: 'absolute',
        bottom: '65px',
        right: '24px',
        width: '210px',
        backgroundColor: 'var(--bg-card)',
        border: '1px solid var(--line-card)',
        borderRadius: '10px',
        padding: '6px',
        display: 'flex',
        flexDirection: 'column',
        gap: '4px',
        boxShadow: '0 8px 24px rgba(0,0,0,0.5)',
        zIndex: 100
      }}
    >
      <button
        style={{ width: '100%', border: 'none', background: 'transparent', justifyContent: 'flex-start' }}
        onClick={() => {
          onSelectFiles()
          onClose()
        }}
      >
        📄 الملفات
      </button>

      <button
        style={{ width: '100%', border: 'none', background: 'transparent', justifyContent: 'flex-start' }}
        onClick={() => {
          onSelectSkills()
          onClose()
        }}
      >
        🧩 المهارات
      </button>

      <button
        style={{ width: '100%', border: 'none', background: 'transparent', justifyContent: 'flex-start' }}
        onClick={() => {
          onSelectFolder()
          onClose()
        }}
      >
        📁 مجلد
      </button>
    </div>
  )
}
