import React, { useState } from 'react'
import { AppSettings, AIProviderType, PermissionMode } from '../../shared/types'

interface SettingsProps {
  settings: AppSettings
  onSave: (updated: Partial<AppSettings>) => void
}

export const Settings: React.FC<SettingsProps> = ({ settings, onSave }) => {
  const [provider, setProvider] = useState<AIProviderType>(settings.modelConfig.provider)
  const [modelId, setModelId] = useState(settings.modelConfig.modelId)
  const [apiKey, setApiKey] = useState('')
  const [baseUrl, setBaseUrl] = useState(settings.modelConfig.baseUrl || '')
  const [permissionMode, setPermissionMode] = useState<PermissionMode>(settings.permissionMode)
  const [accentColor, setAccentColor] = useState(settings.accentColor)
  const [braveApiKey, setBraveApiKey] = useState('')
  const [updateInterval, setUpdateInterval] = useState(settings.updateCheckIntervalDays || 10)
  const [watchList, setWatchList] = useState<string[]>(
    settings.watchList || ['Claude Code', 'Gemini CLI', 'OpenAI Codex', 'Cursor', 'Kimi']
  )
  const [newWatchItem, setNewWatchItem] = useState('')
  const [skillFolders, setSkillFolders] = useState<string[]>(settings.skillFolders || [])
  const [newFolderInput, setNewFolderInput] = useState('')
  const [launchAtStartup, setLaunchAtStartup] = useState(settings.launchAtStartup || false)
  const [maxIterations, setMaxIterations] = useState(settings.maxIterations || 40)
  const [language, setLanguage] = useState<'ar' | 'en'>(settings.language || 'ar')
  const [savedSuccess, setSavedSuccess] = useState(false)

  const handleSave = () => {
    onSave({
      modelConfig: {
        provider,
        modelId,
        apiKey: apiKey.trim() || undefined,
        baseUrl: baseUrl.trim() || undefined
      },
      permissionMode,
      accentColor,
      braveApiKey: braveApiKey.trim() || undefined,
      updateCheckIntervalDays: Number(updateInterval),
      watchList,
      skillFolders,
      launchAtStartup,
      maxIterations: Number(maxIterations),
      language
    })
    document.documentElement.style.setProperty('--accent', accentColor)
    setSavedSuccess(true)
    setTimeout(() => setSavedSuccess(false), 3000)
  }

  const addWatchItem = () => {
    if (newWatchItem.trim() && !watchList.includes(newWatchItem.trim())) {
      setWatchList([...watchList, newWatchItem.trim()])
      setNewWatchItem('')
    }
  }

  const removeWatchItem = (item: string) => {
    setWatchList(watchList.filter((w) => w !== item))
  }

  const addSkillFolder = () => {
    if (newFolderInput.trim() && !skillFolders.includes(newFolderInput.trim())) {
      setSkillFolders([...skillFolders, newFolderInput.trim()])
      setNewFolderInput('')
    }
  }

  const removeSkillFolder = (folder: string) => {
    setSkillFolders(skillFolders.filter((f) => f !== folder))
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', maxWidth: '680px', paddingBottom: '40px' }}>
      <div>
        <h2 style={{ fontSize: '18px', fontWeight: 700 }}>إعدادات المساعد والأمان (Settings)</h2>
        <div style={{ fontSize: '12px', color: 'var(--muted)' }}>
          تخصيص نماذج الذكاء، مجلدات المهارات، الصلاحيات، ورادار التحديثات
        </div>
      </div>

      {/* Model & Provider */}
      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        <h3 style={{ fontSize: '15px', fontWeight: 700 }}>مزود ونموذج الذكاء الاصطناعي (AI Provider)</h3>

        <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
          {(['gemini', 'ollama', 'anthropic', 'openai', 'kimi'] as AIProviderType[]).map((p) => (
            <button
              key={p}
              onClick={() => setProvider(p)}
              style={{
                background: provider === p ? 'var(--accent)' : 'var(--bg-btn)',
                color: provider === p ? 'var(--on-accent)' : 'var(--text)',
                fontWeight: provider === p ? 700 : 400
              }}
            >
              {p.toUpperCase()}
            </button>
          ))}
        </div>

        <div>
          <label style={{ fontSize: '12px', color: 'var(--muted)' }}>اسم النموذج (Model ID):</label>
          <input
            className="input-field"
            style={{ width: '100%', background: 'var(--bg-tool)', padding: '8px 12px', borderRadius: '8px' }}
            value={modelId}
            onChange={(e) => setModelId(e.target.value)}
            placeholder="gemini-1.5-flash / claude-3-5-sonnet / llama3.2"
          />
        </div>

        <div>
          <label style={{ fontSize: '12px', color: 'var(--muted)' }}>
            مفتاح API الجديد (اتركه فارغاً للاحتفاظ بالمفتاح المشفر المحفوظ):
          </label>
          <input
            className="input-field"
            type="password"
            style={{ width: '100%', background: 'var(--bg-tool)', padding: '8px 12px', borderRadius: '8px' }}
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            placeholder={settings.modelConfig.hasApiKey ? 'المفتاح محفوظ ومحمي بـ safeStorage' : 'أدخل مفتاح API...'}
          />
        </div>

        <div>
          <label style={{ fontSize: '12px', color: 'var(--muted)' }}>الرابط المخصص (Base URL - اختياري):</label>
          <input
            className="input-field"
            style={{ width: '100%', background: 'var(--bg-tool)', padding: '8px 12px', borderRadius: '8px' }}
            value={baseUrl}
            onChange={(e) => setBaseUrl(e.target.value)}
            placeholder="http://localhost:11434/v1 أو رابط مخصص"
          />
        </div>
      </div>

      {/* Permission Mode & Max Iterations */}
      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
        <h3 style={{ fontSize: '15px', fontWeight: 700 }}>وضع الصلاحيات والتحكم (Permissions & Limits)</h3>
        <div style={{ display: 'flex', gap: '8px' }}>
          {(['ask', 'auto-edit', 'plan'] as PermissionMode[]).map((mode) => (
            <button
              key={mode}
              onClick={() => setPermissionMode(mode)}
              style={{
                flex: 1,
                background: permissionMode === mode ? 'var(--accent)' : 'var(--bg-btn)',
                color: permissionMode === mode ? 'var(--on-accent)' : 'var(--text)',
                fontWeight: permissionMode === mode ? 700 : 400
              }}
            >
              {mode === 'ask' && 'سؤال دائماً (Ask)'}
              {mode === 'auto-edit' && 'تعديل تلقائي (Auto-edit)'}
              {mode === 'plan' && 'خطة قراءة فقط (Plan)'}
            </button>
          ))}
        </div>

        <div style={{ marginTop: '8px' }}>
          <label style={{ fontSize: '12px', color: 'var(--muted)' }}>
            الحد الأقصى لخطوات تنفيذ الأدوات في الجولة (Max Iterations):
          </label>
          <input
            className="input-field"
            type="number"
            min={5}
            max={60}
            style={{ width: '100%', background: 'var(--bg-tool)', padding: '8px 12px', borderRadius: '8px' }}
            value={maxIterations}
            onChange={(e) => setMaxIterations(Number(e.target.value))}
          />
        </div>
      </div>

      {/* Skill Discovery Folders */}
      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
        <h3 style={{ fontSize: '15px', fontWeight: 700 }}>مجلدات استكشاف المهارات (Skill Folders)</h3>
        <div style={{ fontSize: '12px', color: 'var(--muted)' }}>
          يبحث التطبيق تلقائياً في مجلدات العمل ومجلدات الوكلاء الأخرى:
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
          {skillFolders.map((f) => (
            <div
              key={f}
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                background: 'var(--bg-tool)',
                padding: '6px 10px',
                borderRadius: '6px',
                fontSize: '12px'
              }}
            >
              <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>📁 {f}</span>
              <button
                style={{ minHeight: '28px', padding: '2px 8px', fontSize: '11px', color: '#ef4444' }}
                onClick={() => removeSkillFolder(f)}
              >
                إزالة
              </button>
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', gap: '8px', marginTop: '4px' }}>
          <input
            className="input-field"
            style={{ background: 'var(--bg-tool)', padding: '8px 12px', borderRadius: '8px', flex: 1 }}
            placeholder="أضف مسار مجلد مهارات إضافي..."
            value={newFolderInput}
            onChange={(e) => setNewFolderInput(e.target.value)}
          />
          <button onClick={addSkillFolder}>+ إضافة مجلد</button>
        </div>
      </div>

      {/* Radar Watch List & Interval */}
      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
        <h3 style={{ fontSize: '15px', fontWeight: 700 }}>رادار التحديثات وقائمة المراقبة (Updates Radar)</h3>
        <div>
          <label style={{ fontSize: '12px', color: 'var(--muted)' }}>
            فحص التحديثات تلقائياً كل (بالأيام - افتراضياً 10):
          </label>
          <input
            className="input-field"
            type="number"
            min={1}
            max={60}
            style={{ width: '100%', background: 'var(--bg-tool)', padding: '8px 12px', borderRadius: '8px' }}
            value={updateInterval}
            onChange={(e) => setUpdateInterval(Number(e.target.value))}
          />
        </div>

        <div>
          <label style={{ fontSize: '12px', color: 'var(--muted)' }}>قائمة الأدوات المراقبة (Watch List):</label>
          <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', margin: '6px 0' }}>
            {watchList.map((item) => (
              <span
                key={item}
                style={{
                  background: 'var(--bg-tool)',
                  border: '1px solid var(--line)',
                  padding: '4px 8px',
                  borderRadius: '6px',
                  fontSize: '12px',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '6px'
                }}
              >
                {item}
                <span
                  style={{ cursor: 'pointer', color: '#ef4444', fontWeight: 700 }}
                  onClick={() => removeWatchItem(item)}
                >
                  ×
                </span>
              </span>
            ))}
          </div>
          <div style={{ display: 'flex', gap: '8px' }}>
            <input
              className="input-field"
              style={{ background: 'var(--bg-tool)', padding: '8px 12px', borderRadius: '8px', flex: 1 }}
              placeholder="أداة جديدة للمراقبة..."
              value={newWatchItem}
              onChange={(e) => setNewWatchItem(e.target.value)}
            />
            <button onClick={addWatchItem}>+ إضافة</button>
          </div>
        </div>
      </div>

      {/* Search, Appearance & System Options */}
      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        <h3 style={{ fontSize: '15px', fontWeight: 700 }}>محرك البحث والمظهر والنظام</h3>

        <div>
          <label style={{ fontSize: '12px', color: 'var(--muted)' }}>مفتاح محرك البحث Brave Search API:</label>
          <input
            className="input-field"
            type="password"
            style={{ width: '100%', background: 'var(--bg-tool)', padding: '8px 12px', borderRadius: '8px' }}
            value={braveApiKey}
            onChange={(e) => setBraveApiKey(e.target.value)}
            placeholder={settings.hasBraveApiKey ? 'مفتاح Brave Search محفوظ' : 'أدخل مفتاح Brave Search API'}
          />
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <input
            type="color"
            value={accentColor}
            onChange={(e) => {
              setAccentColor(e.target.value)
              document.documentElement.style.setProperty('--accent', e.target.value)
            }}
            style={{ width: '44px', height: '44px', border: 'none', borderRadius: '8px', cursor: 'pointer' }}
          />
          <span style={{ fontSize: '13px' }}>لون التمييز المباشر (Accent): {accentColor}</span>
        </div>

        <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
          <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', fontSize: '13px' }}>
            <input
              type="checkbox"
              checked={launchAtStartup}
              onChange={(e) => setLaunchAtStartup(e.target.checked)}
            />
            التشغيل في شريط المهام (Tray) وبدء العمل مع إقلاع ويندوز
          </label>
        </div>

        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          <span style={{ fontSize: '13px' }}>لغة الواجهة:</span>
          <button
            onClick={() => setLanguage('ar')}
            style={{
              background: language === 'ar' ? 'var(--accent)' : 'var(--bg-btn)',
              color: language === 'ar' ? 'var(--on-accent)' : 'var(--text)'
            }}
          >
            العربية
          </button>
          <button
            onClick={() => setLanguage('en')}
            style={{
              background: language === 'en' ? 'var(--accent)' : 'var(--bg-btn)',
              color: language === 'en' ? 'var(--on-accent)' : 'var(--text)'
            }}
          >
            English
          </button>
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        <button className="btn-accent" onClick={handleSave} style={{ flex: 1 }}>
          حفظ جميع الإعدادات
        </button>
        {savedSuccess && <span style={{ color: 'var(--ok)', fontWeight: 700 }}>تم الحفظ بنجاح! ✓</span>}
      </div>
    </div>
  )
}
