import React from 'react'
import { ApprovalRequest } from '../../shared/types'
import { DiffView } from './DiffView'

interface ApprovalDialogProps {
  request: ApprovalRequest
  onAllow: () => void
  onReject: () => void
}

export const ApprovalDialog: React.FC<ApprovalDialogProps> = ({ request, onAllow, onReject }) => {
  const isSkill = request.kind === 'skill'
  const skill = request.details.skillInstall

  return (
    <div className="approval-card">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span className="tag-kind">
          {request.kind === 'tool' && `أداة: ${request.name}`}
          {request.kind === 'skill' && `مهارة: ${request.name}`}
          {request.kind === 'build' && `بناء: ${request.name}`}
        </span>
        <span style={{ fontSize: '12px', color: 'var(--muted)' }}>موافقة أمنية مطلوبة</span>
      </div>

      <div style={{ fontWeight: 700 }}>يطلب موافقتك على:</div>

      {request.details.command && (
        <div className="tool-row" style={{ userSelect: 'text' }}>
          <code>$ {request.details.command}</code>
        </div>
      )}

      {request.details.diff && (
        <DiffView
          file={request.details.diff.file}
          before={request.details.diff.before}
          after={request.details.diff.after}
        />
      )}

      {isSkill && skill && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          <div style={{ fontSize: '13px' }}>{skill.description}</div>
          <div style={{ fontSize: '12px', color: 'var(--muted)' }}>المصدر: {skill.sourceUrl}</div>
          {skill.hasScripts && (
            <div
              style={{
                color: 'var(--accent)',
                backgroundColor: 'rgba(255, 138, 61, 0.1)',
                padding: '6px 10px',
                borderRadius: '6px',
                fontSize: '12px'
              }}
            >
              ⚠️ تنبيه: المهارة تحتوي على سكربتات برمجية (.py / .sh) ولن تعمل إلا بموافقة منفصلة.
            </div>
          )}
          <div
            style={{
              maxHeight: '120px',
              overflowY: 'auto',
              background: 'var(--bg-tool)',
              padding: '8px',
              borderRadius: '6px',
              fontSize: '11px',
              fontFamily: 'monospace'
            }}
          >
            {skill.skillMdContent}
          </div>
        </div>
      )}

      <div style={{ display: 'flex', gap: '10px', marginTop: '6px' }}>
        <button className="btn-accent" onClick={onAllow} style={{ flex: 1 }}>
          {isSkill ? 'تثبيت' : 'سماح'}
        </button>
        <button onClick={onReject} style={{ flex: 1 }}>
          رفض
        </button>
      </div>
    </div>
  )
}
