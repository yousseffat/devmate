import React, { useState, useRef, useEffect } from 'react'
import { ChatMessage, ApprovalRequest } from '../../shared/types'
import { ToolCard } from './ToolCard'
import { ApprovalDialog } from './ApprovalDialog'
import { PlusMenu } from './PlusMenu'

interface ChatProps {
  messages: ChatMessage[]
  isRunning: boolean
  onSendMessage: (text: string) => void
  onStop: () => void
  approvalRequest: ApprovalRequest | null
  onRespondApproval: (allowed: boolean) => void
  onOpenFilePicker: () => void
  onOpenFolderPicker: () => void
  onOpenSkills: () => void
}

export const Chat: React.FC<ChatProps> = ({
  messages,
  isRunning,
  onSendMessage,
  onStop,
  approvalRequest,
  onRespondApproval,
  onOpenFilePicker,
  onOpenFolderPicker,
  onOpenSkills
}) => {
  const [inputText, setInputText] = useState('')
  const [showPlusMenu, setShowPlusMenu] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, approvalRequest])

  const handleSend = () => {
    if (inputText.trim() && !isRunning) {
      onSendMessage(inputText)
      setInputText('')
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', position: 'relative' }}>
      <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '12px', paddingBottom: '16px' }}>
        {messages.map((m) => {
          const isUser = m.role === 'user'
          return (
            <div
              key={m.id}
              className={isUser ? 'message-user' : 'message-assistant'}
              dir="auto"
            >
              <div style={{ whiteSpace: 'pre-wrap' }}>{m.content}</div>

              {m.toolCalls?.map((tc) => (
                <ToolCard key={tc.id} toolCall={tc} toolResult={m.toolResult} />
              ))}
            </div>
          )
        })}

        {approvalRequest && (
          <ApprovalDialog
            request={approvalRequest}
            onAllow={() => onRespondApproval(true)}
            onReject={() => onRespondApproval(false)}
          />
        )}

        <div ref={messagesEndRef} />
      </div>

      {showPlusMenu && (
        <PlusMenu
          onSelectFiles={onOpenFilePicker}
          onSelectSkills={onOpenSkills}
          onSelectFolder={onOpenFolderPicker}
          onClose={() => setShowPlusMenu(false)}
        />
      )}

      <div className="input-card">
        <button
          onClick={() => setShowPlusMenu(!showPlusMenu)}
          style={{ width: '32px', minHeight: '32px', padding: 0, borderRadius: '6px' }}
        >
          +
        </button>

        <input
          className="input-field"
          type="text"
          placeholder="اكتب رسالتك... أو / لاستخدام مهارة"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyDown={handleKeyDown}
          dir="auto"
        />

        {isRunning ? (
          <button className="btn-accent" onClick={onStop}>
            إيقاف
          </button>
        ) : (
          <button className="btn-accent" onClick={handleSend} disabled={!inputText.trim()}>
            إرسال
          </button>
        )}
      </div>
    </div>
  )
}
