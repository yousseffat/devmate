import React, { useState, useEffect } from 'react'
import {
  AppSettings,
  ChatSession,
  ApprovalRequest,
  Skill,
  ToolchainItem,
  UpdateItem,
  BuildProject
} from '../shared/types'
import { Sidebar } from './components/Sidebar'
import { Chat } from './components/Chat'
import { SkillsPanel } from './components/SkillsPanel'
import { UpdatesPanel } from './components/UpdatesPanel'
import { BuildPanel } from './components/BuildPanel'
import { Settings } from './components/Settings'
import { FirstRunWizard } from './components/FirstRunWizard'

declare global {
  interface Window {
    api?: import('../shared/ipc').IpcApi
  }
}

export const App: React.FC = () => {
  const [settings, setSettings] = useState<AppSettings | null>(null)
  const [workspace, setWorkspace] = useState<string>('C:\\Projects')
  const [chats, setChats] = useState<ChatSession[]>([])
  const [activeChatId, setActiveChatId] = useState<string | null>(null)
  const [currentPage, setCurrentPage] = useState<'chat' | 'skills' | 'updates' | 'build' | 'settings'>('chat')

  const [skills, setSkills] = useState<Skill[]>([])
  const [toolchain, setToolchain] = useState<ToolchainItem[]>([])
  const [updates, setUpdates] = useState<UpdateItem[]>([])
  const [projects] = useState<BuildProject[]>([])

  const [isRunning, setIsRunning] = useState(false)
  const [approvalRequest, setApprovalRequest] = useState<ApprovalRequest | null>(null)
  const [toolStatusText, setToolStatusText] = useState('جاهز')
  const [isFirstRun, setIsFirstRun] = useState(false)

  useEffect(() => {
    if (window.api) {
      window.api.getSettings().then((s) => {
        setSettings(s)
        if (s.accentColor) {
          document.documentElement.style.setProperty('--accent', s.accentColor)
        }
        if (!s.modelConfig.apiKey && s.modelConfig.provider !== 'ollama') {
          setIsFirstRun(true)
        }
      })

      window.api.listChats().then((c) => {
        setChats(c)
        if (c.length > 0) setActiveChatId(c[0].id)
      })

      window.api.listSkills().then(setSkills)
      window.api.checkToolchain().then(setToolchain)
      window.api.getUpdates().then(setUpdates)

      const unsubStream = window.api.onAgentStream((data) => {
        if (data.done) {
          setIsRunning(false)
          setToolStatusText('جاهز')
          window.api?.listChats().then(setChats)
        }
      })

      const unsubApproval = window.api.onApprovalRequested((req) => {
        setApprovalRequest(req)
      })

      const unsubTool = window.api.onToolActivity((t) => {
        setToolStatusText(`${t.name}: ${t.status}`)
      })

      return () => {
        unsubStream()
        unsubApproval()
        unsubTool()
      }
    }
    return undefined
  }, [])

  const currentChat = chats.find((c) => c.id === activeChatId) || null

  const handleSendMessage = (text: string) => {
    if (!activeChatId) {
      const newId = `chat_${Date.now()}`
      const newSession: ChatSession = {
        id: newId,
        title: text.slice(0, 25),
        createdAt: Date.now(),
        updatedAt: Date.now(),
        workspacePath: workspace,
        messages: [{ id: `u_${Date.now()}`, role: 'user', content: text, timestamp: Date.now() }]
      }
      setChats([newSession, ...chats])
      setActiveChatId(newId)
      setIsRunning(true)
      window.api?.sendMessage(newId, text)
    } else {
      setIsRunning(true)
      window.api?.sendMessage(activeChatId, text)
    }
  }

  const handleStop = () => {
    if (activeChatId) {
      window.api?.stopAgent(activeChatId)
      setIsRunning(false)
    }
  }

  const handleRespondApproval = (allowed: boolean) => {
    if (approvalRequest) {
      window.api?.respondApproval(approvalRequest.id, allowed)
      setApprovalRequest(null)
    }
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
      {/* 40px Frameless Titlebar */}
      <div className="titlebar">
        <span className="titlebar-title">DevMate</span>
        <span className="titlebar-subtitle">مساعد البرمجة الشخصي</span>
        <div className="titlebar-spacer" />
        <div className="titlebar-controls">
          <button className="titlebar-btn" onClick={() => window.close()}>
            ✕
          </button>
        </div>
      </div>

      {/* Main Content Layout */}
      <div className="app-container">
        {/* Left Sidebar 230px */}
        <Sidebar
          workspace={workspace}
          onSelectWorkspace={async () => {
            const picked = await window.api?.selectWorkspaceFolder()
            if (picked) setWorkspace(picked)
          }}
          chats={chats}
          activeChatId={activeChatId}
          onSelectChat={(id) => {
            setActiveChatId(id)
            setCurrentPage('chat')
          }}
          onNewChat={() => {
            const newId = `chat_${Date.now()}`
            setActiveChatId(newId)
            setCurrentPage('chat')
          }}
          currentPage={currentPage}
          onSelectPage={(p) => setCurrentPage(p as typeof currentPage)}
          skillsCount={skills.length}
          unseenUpdatesCount={updates.filter((u) => !u.isLearned).length}
        />

        {/* Center Main Area */}
        <main className="main-center">
          {currentPage === 'chat' && (
            <Chat
              messages={currentChat?.messages || []}
              isRunning={isRunning}
              onSendMessage={handleSendMessage}
              onStop={handleStop}
              approvalRequest={approvalRequest}
              onRespondApproval={handleRespondApproval}
              onOpenFilePicker={async () => {
                const file = await window.api?.selectFile()
                if (file) handleSendMessage(`الملف المرفق: ${file}`)
              }}
              onOpenFolderPicker={async () => {
                const folder = await window.api?.selectWorkspaceFolder()
                if (folder) setWorkspace(folder)
              }}
              onOpenSkills={() => setCurrentPage('skills')}
            />
          )}

          {currentPage === 'skills' && (
            <SkillsPanel
              skills={skills}
              onToggleSkill={async (name, enabled) => {
                await window.api?.toggleSkill(name, enabled)
                window.api?.listSkills().then(setSkills)
              }}
              onRemoveSkill={async (name) => {
                await window.api?.uninstallSkill(name)
                window.api?.listSkills().then(setSkills)
              }}
              onRefresh={() => window.api?.refreshSkills().then(setSkills)}
              onInstallFromUrl={async (url) => {
                await window.api?.prepareSkillFromUrl(url)
              }}
              onSearchOnline={async (q) => {
                return (await window.api?.searchSkillsOnline(q)) || []
              }}
            />
          )}

          {currentPage === 'updates' && (
            <UpdatesPanel
              updates={updates}
              onCheckNow={async () => {
                const res = (await window.api?.checkUpdatesNow()) || []
                setUpdates(res)
              }}
              onLearnUpdate={async (id) => {
                await window.api?.learnUpdate(id)
              }}
              isChecking={false}
            />
          )}

          {currentPage === 'build' && (
            <BuildPanel
              toolchain={toolchain}
              projects={projects}
              onInstallTool={async (id) => {
                await window.api?.installToolchainItem(id)
                window.api?.checkToolchain().then(setToolchain)
              }}
              onAcceptLicenses={() => window.api?.acceptAndroidLicenses()}
              onBuildProject={() => {}}
              onInstallArtifact={(p) => window.api?.installArtifact(p)}
              onOpenFolder={(p) => window.api?.openInExplorer(p)}
              isBuilding={false}
            />
          )}

          {currentPage === 'settings' && settings && (
            <Settings
              settings={settings}
              onSave={async (upd) => {
                const s = await window.api?.saveSettings(upd)
                if (s) setSettings(s)
              }}
            />
          )}
        </main>

        {/* Right Panel 300px: Toolchain & Build Status */}
        <aside className="panel-right">
          <h3 style={{ fontSize: '15px', fontWeight: 700 }}>البناء والتثبيت السريع</h3>
          <div className="card">
            <div style={{ fontWeight: 600, marginBottom: '6px' }}>جاهزية أدوات التطوير:</div>
            {toolchain.slice(0, 4).map((t) => (
              <div
                key={t.id}
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  fontSize: '12px',
                  padding: '4px 0'
                }}
              >
                <span>{t.name.split(' ')[0]}</span>
                {t.isInstalled ? (
                  <span style={{ color: 'var(--ok)' }}>✓</span>
                ) : (
                  <span style={{ color: 'var(--accent)' }}>غير مثبت</span>
                )}
              </div>
            ))}
          </div>

          <h3 style={{ fontSize: '15px', fontWeight: 700 }}>المهارات النشطة</h3>
          <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            {skills
              .filter((s) => s.isEnabled)
              .slice(0, 5)
              .map((s) => (
                <div key={s.name} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px' }}>
                  <span>{s.name}</span>
                  <span style={{ color: 'var(--ok)' }}>مفعّلة</span>
                </div>
              ))}
          </div>
        </aside>
      </div>

      {/* 28px Status Bar */}
      <footer className="statusbar">
        <span>
          {settings?.modelConfig.provider || 'gemini'} · وضع الصلاحيات:{' '}
          {settings?.permissionMode === 'ask'
            ? 'سؤال دائماً (Ask)'
            : settings?.permissionMode === 'auto-edit'
              ? 'تعديل تلقائي'
              : 'خطة قراءة فقط'}{' '}
          · الأدوات: {toolStatusText}
        </span>
      </footer>

      {isFirstRun && (
        <FirstRunWizard
          onComplete={async (cfg) => {
            setIsFirstRun(false)
            const s = await window.api?.saveSettings(cfg)
            if (s) setSettings(s)
          }}
        />
      )}
    </div>
  )
}

export default App
