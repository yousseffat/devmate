import {
  AppSettings,
  ChatSession,
  ChatMessage,
  ApprovalRequest,
  Skill,
  SkillCandidate,
  PendingSkillInstall,
  ToolchainItem,
  UpdateItem,
  BuildProject
} from './types'

export interface IpcApi {
  // Settings
  getSettings: () => Promise<AppSettings>
  saveSettings: (settings: Partial<AppSettings>) => Promise<AppSettings>
  
  // Workspace & Dialogs
  selectWorkspaceFolder: () => Promise<string | null>
  selectFile: () => Promise<string | null>
  openInExplorer: (path: string) => Promise<void>

  // Chats
  listChats: () => Promise<ChatSession[]>
  loadChat: (id: string) => Promise<ChatSession | null>
  saveChat: (chat: ChatSession) => Promise<void>
  deleteChat: (id: string) => Promise<void>
  sendMessage: (sessionId: string, text: string) => Promise<void>
  stopAgent: (sessionId: string) => Promise<void>
  respondApproval: (requestId: string, allowed: boolean) => Promise<void>

  // Skills
  listSkills: () => Promise<Skill[]>
  toggleSkill: (name: string, enabled: boolean) => Promise<void>
  searchSkillsOnline: (query: string) => Promise<SkillCandidate[]>
  prepareSkillFromUrl: (sourceUrl: string) => Promise<PendingSkillInstall>
  uninstallSkill: (name: string) => Promise<void>
  refreshSkills: () => Promise<Skill[]>

  // Toolchain & Build
  checkToolchain: () => Promise<ToolchainItem[]>
  installToolchainItem: (id: string) => Promise<void>
  acceptAndroidLicenses: () => Promise<void>
  listBuildProjects: () => Promise<BuildProject[]>
  buildProject: (projectId: string) => Promise<{ success: boolean; log: string; artifactPath?: string }>
  installArtifact: (artifactPath: string) => Promise<void>

  // Radar / Updates
  checkUpdatesNow: () => Promise<UpdateItem[]>
  getUpdates: () => Promise<UpdateItem[]>
  learnUpdate: (updateId: string) => Promise<void>

  // Events subscriptions
  onAgentStream: (callback: (data: { sessionId: string; token?: string; done?: boolean }) => void) => () => void
  onApprovalRequested: (callback: (request: ApprovalRequest) => void) => () => void
  onToolActivity: (callback: (data: { name: string; status: 'running' | 'success' | 'error'; info?: string }) => void) => () => void
}
