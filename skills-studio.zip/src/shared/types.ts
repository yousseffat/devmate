export type PermissionMode = 'ask' | 'auto-edit' | 'plan'

export type AIProviderType = 'gemini' | 'ollama' | 'openai' | 'anthropic' | 'kimi' | 'custom'

export interface ModelConfig {
  provider: AIProviderType
  modelId: string
  apiKey?: string
  baseUrl?: string
  hasApiKey?: boolean
}

export interface AppSettings {
  modelConfig: ModelConfig
  permissionMode: PermissionMode
  accentColor: string
  skillFolders: string[]
  updateCheckIntervalDays: number
  watchList: string[]
  launchAtStartup: boolean
  maxIterations: number
  braveApiKey?: string
  hasBraveApiKey?: boolean
  language: 'ar' | 'en'
}

export type MessageRole = 'user' | 'assistant' | 'system' | 'tool'

export interface ToolCallDelta {
  index: number
  id?: string
  name?: string
  argumentsDelta?: string
}

export interface ToolCall {
  id: string
  name: string
  arguments: Record<string, unknown>
}

export interface ToolResult {
  toolCallId: string
  name: string
  output: string
  isError?: boolean
}

export interface ChatMessage {
  id: string
  role: MessageRole
  content: string
  timestamp: number
  toolCalls?: ToolCall[]
  toolResult?: ToolResult
}

export interface ChatSession {
  id: string
  title: string
  createdAt: number
  updatedAt: number
  workspacePath: string
  messages: ChatMessage[]
}

export interface SkillFile {
  relativePath: string
  sizeBytes: number
  isScript: boolean
  content?: string
}

export interface Skill {
  name: string
  description: string
  sourceUrl: string
  folderPath: string
  isEnabled: boolean
  hasScripts: boolean
  files: SkillFile[]
  skillMdContent: string
}

export interface InvalidSkillInfo {
  folder: string
  name: string
  error: string
}

export interface SkillCandidate {
  name: string
  description: string
  sourceUrl: string
  stepsSummary: string
  hasScripts: boolean
  rawSkillMd: string
}

export interface PendingSkillInstall {
  name: string
  description: string
  sourceUrl: string
  files: SkillFile[]
  skillMdContent: string
  hasScripts: boolean
}

export interface ApprovalRequest {
  id: string
  kind: 'tool' | 'skill' | 'build'
  name: string
  description: string
  details: {
    command?: string
    diff?: { file: string; before: string; after: string }
    skillInstall?: PendingSkillInstall
    explanation?: string
  }
}

export interface ToolchainItem {
  id: string
  name: string
  isInstalled: boolean
  version?: string
  installCommand?: string
  wingetPackageId?: string
  notes?: string
}

export interface UpdateItem {
  id: string
  number: number
  date: string
  title: string
  arabicSummary: string
  sourceUrl: string
  classification: 'skill' | 'tool' | 'info'
  externalToolName?: string
  isLearned?: boolean
  isVerifiable: boolean
}

export interface BuildProject {
  id: string
  name: string
  type: 'android' | 'desktop'
  path: string
  lastBuildTime?: number
  lastBuildSuccess?: boolean
  outputArtifactPath?: string
}
