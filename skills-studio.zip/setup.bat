@echo off
chcp 65001 >nul
title DevMate - التشغيل السريع للمساعد الذكي
color 0B

echo =========================================================
echo    أهلاً بك في DevMate - مساعد البرمجة والمهارات الذكي
echo    Welcome to DevMate AI Coding Assistant
echo =========================================================
echo.

echo [1/3] فحص برنامج Node.js على جهازك...
where node >nul 2>nul
if %errorlevel% neq 0 (
    color 0C
    echo [خطأ] Node.js غير مثبت على جهازك!
    echo الرجاء تحميل وتثبيت إصدار LTS من الموقع الرسمي: https://nodejs.org
    echo بعد التثبيت، أعد النقر مرتين على هذا الملف.
    echo.
    pause
    exit /b 1
)

echo [تم] تم العثور على Node.js بنجاح.
node -v
echo.

echo [2/3] تثبيت المكتبات والتبعيات المطلوبة (npm install)...
call npm install
if %errorlevel% neq 0 (
    color 0C
    echo [تنبيه] حدث خطأ أثناء تثبيت الحزم، جاري المحاولة بدون تدقيق...
    call npm install --prefer-offline --no-audit
)

echo.
echo [3/3] تشغيل تطبيق DevMate في وضع التطوير...
echo سيتم فتح نافذة التطبيق فوراً. لإيقاف البرنامج اضغط Ctrl+C
echo.
color 0A
call npm run dev

echo.
echo =========================================================
echo تم إغلاق البرنامج. شكراً لاستخدامك DevMate!
echo =========================================================
pause
