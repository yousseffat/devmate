@echo off
chcp 65001 >nul
title DevMate - بناء ملف التثبيت (.exe)
color 0B

echo =========================================================
echo    بناء وتوليد برنامج التثبيت لويندوز (.exe)
echo    Building DevMate Windows Installer (.exe)
echo =========================================================
echo.

echo [1/4] التحقق من Node.js...
where node >nul 2>nul
if %errorlevel% neq 0 (
    color 0C
    echo [خطأ] Node.js غير مثبت. ثبته أولاً من https://nodejs.org
    pause
    exit /b 1
)

echo.
echo [2/4] التأكد من تثبيت المكتبات (npm install)...
if not exist "node_modules\" (
    echo جاري تثبيت الحزم لأول مرة...
    call npm install
)

echo.
echo [3/4] تجميع وتجهيز واجهة التطبيق (npm run build)...
call npm run build

echo.
echo [4/4] إنشاء حزمة التثبيت لويندوز (.exe) في مجلد release...
if not exist "release" mkdir release
call npx electron-builder --win --publish never

echo.
echo =========================================================
color 0A
echo [نجاح!] تم بناء ملف التثبيت بنجاح!
echo مكان الملف المولد:
echo %CD%\release\DevMate-Windows-Installer.exe
echo =========================================================
echo.
echo يمكنك الآن تشغيل هذا الملف على أي كمبيوتر بنظام ويندوز!
echo.
pause
