package com.example

import com.example.model.PendingInstall
import com.example.model.SkillFile
import com.example.service.BioscienceEngine
import com.example.service.SkillManager
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SkillInstallerTest {

    @Test
    fun testGitHubUrlParsing() {
        val manager = SkillManager(createMockContext())
        val parsed = manager.parseGitHubUrl("https://github.com/agent-skills/reverse-engineering/tree/main/skills/reverse-engineering-helper")
        assertNotNull(parsed)
        assertEquals("agent-skills", parsed?.owner)
        assertEquals("reverse-engineering", parsed?.repo)
        assertEquals("main", parsed?.branch)
        assertEquals("skills/reverse-engineering-helper", parsed?.path)

        val rootParsed = manager.parseGitHubUrl("https://github.com/bioscience/dna-tools.git")
        assertNotNull(rootParsed)
        assertEquals("bioscience", rootParsed?.owner)
        assertEquals("dna-tools", rootParsed?.repo)
        assertEquals("main", rootParsed?.branch)
        assertEquals("", rootParsed?.path)

        val invalid = manager.parseGitHubUrl("not-a-github-url")
        assertNull(invalid)
    }

    @Test
    fun testSkillMdValidation() {
        val manager = SkillManager(createMockContext())

        // Valid frontmatter
        val validMd = """---
name: dna-analyzer
description: High-speed nucleotide analyzer with GC content and ORF detection.
---
# DNA Analyzer
Full guide.
"""
        val validResult = manager.validateSkillMd(validMd, "dna-analyzer")
        assertTrue(validResult.isValid)
        assertEquals("dna-analyzer", validResult.name)
        assertFalse(validResult.renameSuggested)

        // Name mismatch with folder triggers rename suggestion
        val renameResult = manager.validateSkillMd(validMd, "other-folder-name")
        assertTrue(renameResult.isValid)
        assertTrue(renameResult.renameSuggested)
        assertEquals("dna-analyzer", renameResult.suggestedName)

        // Invalid: missing frontmatter
        val invalidMd = "# No Frontmatter Header"
        val invalidResult = manager.validateSkillMd(invalidMd)
        assertFalse(invalidResult.isValid)

        // Invalid: name with uppercase or symbols
        val badNameMd = """---
name: BAD_NAME!
description: Some desc
---
"""
        val badNameResult = manager.validateSkillMd(badNameMd)
        assertFalse(badNameResult.isValid)
    }

    @Test
    fun testZipSlipProtection() {
        val manager = SkillManager(createMockContext())
        val targetDir = File("/tmp/safe/skills/my-skill")

        // Safe relative paths
        assertTrue(manager.isSafePath(targetDir, "SKILL.md"))
        assertTrue(manager.isSafePath(targetDir, "scripts/run.py"))
        assertTrue(manager.isSafePath(targetDir, "references/data.json"))

        // Malicious paths attempting path traversal
        assertFalse(manager.isSafePath(targetDir, "../../etc/passwd"))
        assertFalse(manager.isSafePath(targetDir, "../parent.txt"))
        assertFalse(manager.isSafePath(targetDir, "/root/.bashrc"))
    }

    @Test
    fun testBioscienceDnaCalculations() {
        // DNA = "ATGC"
        // Reverse complement = "GCAT"
        val rc = BioscienceEngine.reverseComplement("ATGC")
        assertEquals("GCAT", rc)

        // mRNA transcript: T -> U
        val transcript = BioscienceEngine.transcribe("ATGCGATCG")
        assertEquals("AUGCGAUCG", transcript)

        // GC Content of "ATGC" is 50%
        val gc = BioscienceEngine.calculateGcContent("ATGC")
        assertEquals(50.0, gc, 0.001)

        // Translation: ATG = M, TAA = * (Stop)
        val translation = BioscienceEngine.translate("ATGTAA")
        assertEquals("M*", translation)

        // Restriction sites: EcoRI = "GAATTC"
        val sites = BioscienceEngine.findRestrictionSites("NNNGAATTCNNN")
        assertEquals(1, sites.size)
        assertTrue(sites[0].contains("EcoRI"))
    }

    @Test
    fun testProteinCalculations() {
        val result = BioscienceEngine.analyzeProtein("MKWVTFISLL")
        assertEquals(10, result.length)
        assertTrue(result.molecularWeightDa > 1000.0)
        assertTrue(result.gravyScore > 0.0) // Hydrophobic sequence
    }

    @Test
    fun testPcrPrimerTmCalculation() {
        // Wallace rule: 2*(A+T) + 4*(G+C)
        // 2 A + 2 G -> 2*(2) + 4*(2) = 12
        val primer = BioscienceEngine.analyzePrimer("AAGG")
        assertEquals(12.0, primer.tmWallace, 0.01)
    }

    private fun createMockContext(): android.content.Context {
        // Uses Robolectric / mock context in JVM
        return androidx.test.core.app.ApplicationProvider.getApplicationContext()
    }
}
