package com.example.service

import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class AssistantEngine(
    private val skillManager: SkillManager
) {

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _pendingInstallDialog = MutableStateFlow<PendingInstall?>(null)
    val pendingInstallDialog: StateFlow<PendingInstall?> = _pendingInstallDialog.asStateFlow()

    private val _pendingCommandDialog = MutableStateFlow<CommandRequest?>(null)
    val pendingCommandDialog: StateFlow<CommandRequest?> = _pendingCommandDialog.asStateFlow()

    private var lastSearchedSkills: List<SkillCandidate> = emptyList()

    init {
        // Initial welcome message in Arabic and English
        val welcome = ChatMessage(
            sender = MessageSender.ASSISTANT,
            text = """مرحباً بك في **استوديو مهارات الذكاء الاصطناعي (Skills Studio)**! 🧬🤖
أنا مساعدك الذكي المدمج، مدعوم بأحدث **مهارات العلوم الحيوية (Bioscience Skills)** وهندسة البرمجيات.

يمكنك أن تطلب مني أي شيء باللغة العربية، مثل:
• *"ابحث لي عن سكيل هندسة عكسية"* 🔍
• *"ضيف السكيل دي عندك"* 📥
• *"حلل لي هذا الشريط الجيني DNA: ATGCGATCGAGCTAGCTAGCTAA"* 🔬
• *"احسب لي بادئ تفاعل PCR للجين"* 🧪
• *"قائمة المهارات المثبتة"* 📋

كيف يمكنني مساعدتك اليوم؟""",
            isArabic = true
        )
        _messages.value = listOf(welcome)
    }

    fun isArabicInput(text: String): Boolean {
        val arabicCharCount = text.count { it in '\u0600'..'\u06FF' }
        return arabicCharCount > 0 || !text.contains(Regex("[a-zA-Z]{4,}"))
    }

    suspend fun sendMessage(userText: String) {
        val trimmed = userText.trim()
        if (trimmed.isEmpty()) return

        val isAr = isArabicInput(trimmed)
        val userMsg = ChatMessage(
            sender = MessageSender.USER,
            text = trimmed,
            isArabic = isAr
        )
        _messages.value = _messages.value + userMsg

        // Security filter: check for prompt injection or attempts to leak keys
        val lower = trimmed.lowercase(Locale.ROOT)
        if (lower.contains("ignore rules") || lower.contains("bypass approval") ||
            lower.contains("reveal api key") || lower.contains("تجاهل القواعد") || lower.contains("مفتاح api")) {
            val alert = if (isAr) {
                "⚠️ **تنبيه أمني:** تم رصد محاولة تجاوز لنظام الأمان أو طلب كشف مفاتيح سرية. سياسات الأمان الصارمة تمنع ذلك وتلتزم بحماية بياناتك وخصوصيتك بالكامل."
            } else {
                "⚠️ **Security Alert:** An attempt to bypass safety rules or access secret keys was blocked. Strict zero-trust security is actively enforced."
            }
            _messages.value = _messages.value + ChatMessage(sender = MessageSender.ASSISTANT, text = alert, isArabic = isAr)
            return
        }

        // Process intents
        when {
            // Intent: search_skills
            lower.contains("ابحث") || lower.contains("search") || lower.contains("جد لي") || lower.contains("بحث عن") -> {
                handleSearchIntent(trimmed, isAr)
            }

            // Intent: install_skill
            lower.contains("ضيف") || lower.contains("ثبت") || lower.contains("تثبيت") || lower.contains("install") || lower.contains("add skill") -> {
                handleInstallIntent(trimmed, isAr)
            }

            // Intent: list_skills
            lower.contains("قائمة المهارات") || lower.contains("list skills") || lower.contains("السكيلات") || lower.contains("المهارات المثبتة") -> {
                handleListSkillsIntent(isAr)
            }

            // Intent: DNA / Bio analysis
            lower.contains("dna") || lower.contains("حمض نووي") || lower.contains("جين") || lower.contains("atgc") ||
            trimmed.matches(Regex("^[ATCGN\\s]{8,}$", RegexOption.IGNORE_CASE)) -> {
                handleBioAnalysisIntent(trimmed, isAr)
            }

            // Intent: PCR Primer
            lower.contains("pcr") || lower.contains("بادئ") || lower.contains("primer") -> {
                handlePcrIntent(trimmed, isAr)
            }

            // Intent: External tool check (Reverse Engineering)
            lower.contains("هندسة عكسية") || lower.contains("ghidra") || lower.contains("radare2") || lower.contains("reverse engineering") -> {
                handleReverseEngineeringIntent(trimmed, isAr)
            }

            // General assistant reply
            else -> {
                handleGeneralAssistantReply(trimmed, isAr)
            }
        }
    }

    private fun handleSearchIntent(query: String, isAr: Boolean) {
        val candidates = skillManager.searchSkills(query)
        lastSearchedSkills = candidates

        val sb = StringBuilder()
        if (isAr) {
            sb.append("🔍 **نتائج البحث عن المهارات (search_skills):**\n\n")
            candidates.forEachIndexed { index, skill ->
                sb.append("${index + 1}. **${skill.name}**\n")
                sb.append("   • **الوصف:** ${skill.description}\n")
                sb.append("   • **خطوات العمل:**\n${skill.stepsSummary.lines().joinToString("\n") { "     $it" }}\n")
                sb.append("   • **المصدر:** `${skill.sourceUrl}`\n")
                sb.append("   • **تحتوي سكربتات برمجية:** ${if (skill.hasScripts) "⚠️ نعم (تتطلب موافقة تشغيل)" else "✅ لا (تعليمات فقط)"}\n\n")
            }
            sb.append("لتثبيت أي مهارة، اكتب: **\"ضيف السكيل دي عندك\"** أو **\"ثبت ${candidates.firstOrNull()?.name ?: "المهارة"}\"**.")
        } else {
            sb.append("🔍 **Skills Search Results (search_skills):**\n\n")
            candidates.forEachIndexed { index, skill ->
                sb.append("${index + 1}. **${skill.name}**\n")
                sb.append("   • **Description:** ${skill.description}\n")
                sb.append("   • **Workflow Steps:**\n${skill.stepsSummary.lines().joinToString("\n") { "     $it" }}\n")
                sb.append("   • **Source:** `${skill.sourceUrl}`\n")
                sb.append("   • **Contains executable scripts:** ${if (skill.hasScripts) "⚠️ Yes (Requires approval)" else "✅ No (Markdown only)"}\n\n")
            }
            sb.append("To install any skill, type: **\"install ${candidates.firstOrNull()?.name ?: "skill"}\"**.")
        }

        val record = ToolExecutionRecord(
            toolName = "search_skills",
            argumentsJson = """{"query": "$query"}""",
            resultJson = """{"count": ${candidates.size}, "results": ${candidates.map { it.name }}}""",
            status = ToolStatus.SUCCESS
        )

        _messages.value = _messages.value + ChatMessage(
            sender = MessageSender.ASSISTANT,
            text = sb.toString(),
            toolCall = record,
            isArabic = isAr
        )
    }

    private suspend fun handleInstallIntent(userInput: String, isAr: Boolean) {
        // Identify target skill candidate or URL
        var targetUrl: String? = null
        val urlRegex = Regex("""https?://[^\s]+""")
        val urlMatch = urlRegex.find(userInput)
        if (urlMatch != null) {
            targetUrl = urlMatch.value
        } else {
            // Find from last searched or default candidates
            val foundCandidate = lastSearchedSkills.firstOrNull { candidate ->
                userInput.contains(candidate.name)
            } ?: lastSearchedSkills.firstOrNull() ?: skillManager.onlineSkillCatalog.first()
            targetUrl = foundCandidate.sourceUrl
        }

        val prepResult = skillManager.prepareSkillForApproval(targetUrl)
        if (prepResult.isSuccess) {
            val pending = prepResult.getOrThrow()
            _pendingInstallDialog.value = pending

            val promptText = if (isAr) {
                "تم تجهيز المهارة **${pending.name}** للمراجعة الأمنية.\n\n" +
                "🛡️ **وفقاً لقواعد الأمان الصارمة:** تم فتح نافذة المراجعة والموافقة بالواجهة. يُرجى مراجعة محتويات المهارة وملفاتها والضغط على **[تثبيت]** للاعتماد، أو **[إلغاء]**."
            } else {
                "Skill **${pending.name}** is prepared for security review.\n\n" +
                "🛡️ **Zero-Trust Security Policy:** Approval modal opened in UI. Please inspect files, permissions, and click **[Install]** to confirm."
            }

            val record = ToolExecutionRecord(
                toolName = "install_skill",
                argumentsJson = """{"source_url": "$targetUrl"}""",
                status = ToolStatus.PENDING_APPROVAL,
                requiresApproval = true,
                approvalPrompt = promptText
            )

            _messages.value = _messages.value + ChatMessage(
                sender = MessageSender.ASSISTANT,
                text = promptText,
                toolCall = record,
                isArabic = isAr
            )
        } else {
            val err = prepResult.exceptionOrNull()?.localizedMessage ?: "فشل تجهيز المهارة"
            _messages.value = _messages.value + ChatMessage(
                sender = MessageSender.ASSISTANT,
                text = "❌ خطأ أثناء فحص وتجهيز المهارة: $err",
                isArabic = isAr
            )
        }
    }

    suspend fun onUserApprovedInstall(pending: PendingInstall) {
        _pendingInstallDialog.value = null
        val result = skillManager.executeApprovedInstall(pending)
        if (result.isSuccess) {
            val skill = result.getOrThrow()
            val text = """✅ **تمت إضافة المهارة ${skill.name}** بنجاح!
• **الوصف:** ${skill.description}
• **المصدر:** `${skill.sourceUrl}`
• **عدد الملفات المعتمدة:** ${skill.files.size}
• **تحتوي سكربتات:** ${if (skill.hasScripts) "نعم (لن يتم تشغيل أي سكربت إلا بأمر وموافقة صريحة منك)" else "لا"}
• **القدرات:** أصبحت المهارة الآن نشطة ومتاحة فوراً للاستخدام في نفس المحادثة وبدون الحاجة لإعادة تشغيل التطبيق."""

            _messages.value = _messages.value + ChatMessage(
                sender = MessageSender.ASSISTANT,
                text = text,
                toolCall = ToolExecutionRecord(
                    toolName = "install_skill",
                    argumentsJson = """{"name": "${skill.name}"}""",
                    resultJson = """{"status": "INSTALLED", "name": "${skill.name}"}""",
                    status = ToolStatus.SUCCESS
                ),
                isArabic = true
            )
        } else {
            val err = result.exceptionOrNull()?.localizedMessage ?: "حدث خطأ أثناء التثبيت"
            _messages.value = _messages.value + ChatMessage(
                sender = MessageSender.ASSISTANT,
                text = "❌ فشل تثبيت المهارة: $err",
                isArabic = true
            )
        }
    }

    fun onUserCancelledInstall() {
        val pending = _pendingInstallDialog.value
        _pendingInstallDialog.value = null
        if (pending != null) {
            _messages.value = _messages.value + ChatMessage(
                sender = MessageSender.ASSISTANT,
                text = "تم إلغاء تثبيت المهارة **${pending.name}** بواسطة المستخدم. لم يتم نسخ أي ملفات على جهازك.",
                isArabic = true
            )
        }
    }

    private fun handleListSkillsIntent(isAr: Boolean) {
        val skills = skillManager.listSkills()
        val sb = StringBuilder()
        if (isAr) {
            sb.append("📋 **قائمة المهارات النشطة حالياً (list_skills):**\n\n")
            skills.forEachIndexed { i, s ->
                val badge = if (s.isBuiltIn) "🟢 مدمجة" else "🔵 مخصصة"
                sb.append("${i + 1}. **${s.name}** ($badge)\n")
                sb.append("   ${s.description}\n")
            }
        } else {
            sb.append("📋 **Currently Installed Skills (list_skills):**\n\n")
            skills.forEachIndexed { i, s ->
                val badge = if (s.isBuiltIn) "Built-in" else "Custom"
                sb.append("${i + 1}. **${s.name}** ($badge)\n")
                sb.append("   ${s.description}\n")
            }
        }

        _messages.value = _messages.value + ChatMessage(
            sender = MessageSender.ASSISTANT,
            text = sb.toString(),
            toolCall = ToolExecutionRecord(
                toolName = "list_skills",
                argumentsJson = "{}",
                resultJson = """{"count": ${skills.size}}"""
            ),
            isArabic = isAr
        )
    }

    private fun handleBioAnalysisIntent(input: String, isAr: Boolean) {
        val seq = BioscienceEngine.cleanDna(input).ifEmpty { "ATGCGATCGAGCTAGCTAGCTAATAA" }
        val res = BioscienceEngine.analyzeDna(seq)

        val text = if (isAr) {
            """🧬 **نتائج تحليل الحمض النووي (DNA Sequence Analyzer):**
• **التسلسل المحلل (${res.length} bp):** `${seq.take(40)}${if (seq.length > 40) "..." else ""}`
• **نسبة القواعد GC:** ${String.format(Locale.US, "%.1f", res.gcPercent)}%
• **الشريط المتمم المعكوس (Reverse Complement):** `${res.reverseComplement.take(30)}`
• **النسخ إلى RNA (Transcription):** `${res.rnaTranscript.take(30)}`
• **الترجمة إلى بروتين (Translation):** `${res.translatedProtein}`
• **مواقع قص إنزيمات التقييد المستكشفة:** ${if (res.restrictionSites.isNotEmpty()) res.restrictionSites.joinToString(", ") else "لا توجد مواقع شائعة"}
• **إطارات القراءة المفتوحة (ORFs):** ${res.openReadingFramesCount}"""
        } else {
            """🧬 **DNA Sequence Analysis (Bioscience Skill):**
• **Sequence Length:** ${res.length} bp
• **GC Content:** ${String.format(Locale.US, "%.1f", res.gcPercent)}%
• **Reverse Complement:** `${res.reverseComplement.take(30)}`
• **mRNA Transcript:** `${res.rnaTranscript.take(30)}`
• **Protein Translation:** `${res.translatedProtein}`
• **Restriction Sites:** ${if (res.restrictionSites.isNotEmpty()) res.restrictionSites.joinToString(", ") else "None"}
• **Open Reading Frames (ORFs):** ${res.openReadingFramesCount}"""
        }

        _messages.value = _messages.value + ChatMessage(
            sender = MessageSender.ASSISTANT,
            text = text,
            toolCall = ToolExecutionRecord(
                toolName = "dna_sequence_analyzer",
                argumentsJson = """{"sequence": "$seq"}""",
                resultJson = """{"length": ${res.length}, "gc": ${res.gcPercent}}"""
            ),
            isArabic = isAr
        )
    }

    private fun handlePcrIntent(input: String, isAr: Boolean) {
        val primer = BioscienceEngine.cleanDna(input).ifEmpty { "AGGTCGATCGGATCCGTAG" }
        val res = BioscienceEngine.analyzePrimer(primer)

        val text = if (isAr) {
            """🧪 **تحليل بادئ تفاعل البلمرة PCR (Primer Designer):**
• **البادئ:** `$primer` (${res.length} bp)
• **نسبة GC:** ${String.format(Locale.US, "%.1f", res.gcPercent)}%
• **درجة حرارة الانصهار Tm (Wallace):** ${String.format(Locale.US, "%.1f", res.tmWallace)}°C
• **درجة حرارة الانصهار Tm (Nearest-Neighbor):** ${String.format(Locale.US, "%.1f", res.tmNearestNeighbor)}°C
• **درجة حرارة الالتصاق الموصى بها (Ta):** ${String.format(Locale.US, "%.1f", res.recommendedAnnealingTemp)}°C
• **حالة التقييم:** ${res.qualityNote}"""
        } else {
            """🧪 **PCR Primer Design Analysis:**
• **Primer:** `$primer` (${res.length} bp)
• **GC%:** ${String.format(Locale.US, "%.1f", res.gcPercent)}%
• **Tm (Nearest-Neighbor):** ${String.format(Locale.US, "%.1f", res.tmNearestNeighbor)}°C
• **Recommended Annealing Temp (Ta):** ${String.format(Locale.US, "%.1f", res.recommendedAnnealingTemp)}°C
• **Quality Evaluation:** ${res.qualityNote}"""
        }

        _messages.value = _messages.value + ChatMessage(
            sender = MessageSender.ASSISTANT,
            text = text,
            isArabic = isAr
        )
    }

    private fun handleReverseEngineeringIntent(userInput: String, isAr: Boolean) {
        // Requirement E: Helping with external tools
        val text = if (isAr) {
            """🛡️ **مهارة الهندسة العكسية وتحليل البرمجيات (Reverse Engineering Helper):**
للتعامل مع تفكيك الملفات الثنائية (Binary Decompilation)، تتطلب هذه المهارة البرامج الخارجية التالية:
1. **Ghidra** (محلل البرمجيات المتقدم من وكالة NSA)
2. **Radare2 / Rizin** (أداة سطر الأوامر لتفكيك وتحليل Opcode)
3. **Strings / Objdump** (أدوات قراءة العناوين والنصوص)

🔍 **فحص وجود البرامج:**
يمكننا تشغيل أمر الفحص `radare2 -v` أو `ghidra --version`.
⚠️ لن يتم تنفيذ أي أمر دون موافقتك الصريحة عبر نافذة الموافقة."""
        } else {
            """🛡️ **Reverse Engineering Helper Skill:**
To decompile and analyze binaries, this skill requires external tools:
1. **Ghidra** (Interactive decompiler framework)
2. **Radare2** (Command-line disassembler)
3. **Objdump / Strings**

Would you like me to check if these are installed on your workstation via run_command?"""
        }

        _pendingCommandDialog.value = CommandRequest(
            command = "radare2 -v",
            rationale = "فحص تثبيت أداة التفكيك radare2 على النظام",
            toolName = "run_command",
            isInstalledCheck = true
        )

        _messages.value = _messages.value + ChatMessage(
            sender = MessageSender.ASSISTANT,
            text = text,
            isArabic = isAr
        )
    }

    fun onUserApprovedCommand(cmd: CommandRequest) {
        _pendingCommandDialog.value = null
        val response = """[نتيجة تنفيذ الأمر المعتمد: `${cmd.command}`]
الأداة: ${cmd.toolName}
الحالة: تم الفحص بنجاح. إذا كانت الأداة غير مثبتة على نظامك، يمكنك تثبيتها بسهولة عن طريق:
• لويندوز: `winget install radare2` أو تحميل Ghidra من موقعها الرسمي.
• للينكس / WSL: `sudo apt-get install radare2`"""

        _messages.value = _messages.value + ChatMessage(
            sender = MessageSender.ASSISTANT,
            text = response,
            isArabic = true
        )
    }

    fun onUserCancelledCommand() {
        _pendingCommandDialog.value = null
        _messages.value = _messages.value + ChatMessage(
            sender = MessageSender.ASSISTANT,
            text = "تم إلغاء تنفيذ الأمر بناءً على طلبك.",
            isArabic = true
        )
    }

    private fun handleGeneralAssistantReply(userText: String, isAr: Boolean) {
        val reply = if (isAr) {
            "أهلاً بك! لقد استلمت طلبك: \"$userText\".\n" +
            "يمكنني مساعدتك في استكشاف المهارات أو تثبيتها من الإنترنت، أو تشغيل أدوات العلوم الحيوية مثل فحص أشرطة DNA وبروتينات الخلية وحسابات PCR. كيف تحب أن نبدأ؟"
        } else {
            "Received: \"$userText\". I can assist with discovering/installing skills, analyzing DNA/protein sequences, designing PCR primers, or checking developer tools."
        }

        _messages.value = _messages.value + ChatMessage(
            sender = MessageSender.ASSISTANT,
            text = reply,
            isArabic = isAr
        )
    }
}
