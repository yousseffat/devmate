package com.example.service

import java.util.Locale

object BioscienceEngine {

    // Standard Genetic Code codon table
    private val codonTable = mapOf(
        "TTT" to "F", "TTC" to "F", "TTA" to "L", "TTG" to "L",
        "CTT" to "L", "CTC" to "L", "CTA" to "L", "CTG" to "L",
        "ATT" to "I", "ATC" to "I", "ATA" to "I", "ATG" to "M", // Start codon
        "GTT" to "V", "GTC" to "V", "GTA" to "V", "GTG" to "V",
        "TCT" to "S", "TCC" to "S", "TCA" to "S", "TCG" to "S",
        "CCT" to "P", "CCC" to "P", "CCA" to "P", "CCG" to "P",
        "ACT" to "T", "ACC" to "T", "ACA" to "T", "ACG" to "T",
        "GCT" to "A", "GCC" to "A", "GCA" to "A", "GCG" to "A",
        "TAT" to "Y", "TAC" to "Y", "TAA" to "*", "TAG" to "*", // Stop
        "CAT" to "H", "CAC" to "H", "CAA" to "Q", "CAG" to "Q",
        "AAT" to "N", "AAC" to "N", "AAA" to "K", "AAG" to "K",
        "GAT" to "D", "GAC" to "D", "GAA" to "E", "GAG" to "E",
        "TGT" to "C", "TGC" to "C", "TGA" to "*", "TGG" to "W", // Stop
        "CGT" to "R", "CGC" to "R", "CGA" to "R", "CGG" to "R",
        "AGT" to "S", "AGC" to "S", "AGA" to "R", "AGG" to "R",
        "GGT" to "G", "GGC" to "G", "GGA" to "G", "GGG" to "G"
    )

    // Molecular weights of amino acids (g/mol)
    private val aaMolecularWeights = mapOf(
        'A' to 89.09, 'R' to 174.20, 'N' to 132.12, 'D' to 133.10,
        'C' to 121.16, 'E' to 147.13, 'Q' to 146.15, 'G' to 75.07,
        'H' to 155.16, 'I' to 131.18, 'L' to 131.18, 'K' to 146.19,
        'M' to 149.21, 'F' to 165.19, 'P' to 115.13, 'S' to 105.09,
        'T' to 119.12, 'W' to 204.23, 'Y' to 181.19, 'V' to 117.15
    )

    // Kyte-Doolittle hydropathy scale for GRAVY
    private val hydropathyScale = mapOf(
        'I' to 4.5, 'V' to 4.2, 'L' to 3.8, 'F' to 2.8, 'C' to 2.5,
        'M' to 1.9, 'A' to 1.8, 'G' to -0.4, 'T' to -0.7, 'S' to -0.8,
        'W' to -0.9, 'Y' to -1.3, 'P' to -1.6, 'H' to -3.2, 'E' to -3.5,
        'Q' to -3.5, 'D' to -3.5, 'N' to -3.5, 'K' to -3.9, 'R' to -4.5
    )

    // Common restriction enzymes
    private val restrictionEnzymes = mapOf(
        "EcoRI" to "GAATTC",
        "BamHI" to "GGATCC",
        "HindIII" to "AAGCTT",
        "NotI" to "GCGGCCGC",
        "XhoI" to "CTCGAG",
        "PstI" to "CTGCAG",
        "TaqI" to "TCGA",
        "AluI" to "AGCT"
    )

    data class DnaAnalysisResult(
        val length: Int,
        val gcPercent: Double,
        val reverseComplement: String,
        val rnaTranscript: String,
        val translatedProtein: String,
        val restrictionSites: List<String>,
        val openReadingFramesCount: Int
    )

    data class ProteinAnalysisResult(
        val length: Int,
        val molecularWeightDa: Double,
        val isoelectricPointApprox: Double,
        val gravyScore: Double,
        val chargeAtPh7: Double,
        val extinctionCoefficient280nm: Int
    )

    data class PcrPrimerResult(
        val length: Int,
        val gcPercent: Double,
        val tmWallace: Double,
        val tmNearestNeighbor: Double,
        val recommendedAnnealingTemp: Double,
        val hasHairpinRisk: Boolean,
        val qualityNote: String
    )

    data class CellCultureResult(
        val totalCellsCount: Long,
        val cellViabilityPercent: Double,
        val recommendedVolumeMlForSeeding: Double,
        val doublingTimeHours: Double?
    )

    fun cleanDna(sequence: String): String {
        return sequence.uppercase(Locale.ROOT).replace(Regex("[^ATCGN]"), "")
    }

    fun cleanProtein(sequence: String): String {
        return sequence.uppercase(Locale.ROOT).replace(Regex("[^ACDEFGHIKLMNPQRSTVWY*]"), "")
    }

    fun reverseComplement(dna: String): String {
        val cleaned = cleanDna(dna)
        val sb = StringBuilder()
        for (i in cleaned.indices.reversed()) {
            when (cleaned[i]) {
                'A' -> sb.append('T')
                'T' -> sb.append('A')
                'C' -> sb.append('G')
                'G' -> sb.append('C')
                else -> sb.append('N')
            }
        }
        return sb.toString()
    }

    fun transcribe(dna: String): String {
        return cleanDna(dna).replace('T', 'U')
    }

    fun translate(dna: String): String {
        val cleaned = cleanDna(dna)
        val protein = StringBuilder()
        var i = 0
        while (i + 2 < cleaned.length) {
            val codon = cleaned.substring(i, i + 3)
            val aa = codonTable[codon] ?: "X"
            protein.append(aa)
            i += 3
        }
        return protein.toString()
    }

    fun calculateGcContent(dna: String): Double {
        val cleaned = cleanDna(dna)
        if (cleaned.isEmpty()) return 0.0
        val gcCount = cleaned.count { it == 'G' || it == 'C' }
        return (gcCount.toDouble() / cleaned.length) * 100.0
    }

    fun findRestrictionSites(dna: String): List<String> {
        val cleaned = cleanDna(dna)
        val matches = mutableListOf<String>()
        for ((name, site) in restrictionEnzymes) {
            var index = cleaned.indexOf(site)
            while (index >= 0) {
                matches.add("$name at pos ${index + 1} ($site)")
                index = cleaned.indexOf(site, index + 1)
            }
        }
        return matches
    }

    fun findOrfs(dna: String): Int {
        val cleaned = cleanDna(dna)
        var orfCount = 0
        for (frame in 0..2) {
            var inOrf = false
            var i = frame
            while (i + 2 < cleaned.length) {
                val codon = cleaned.substring(i, i + 3)
                if (!inOrf && codon == "ATG") {
                    inOrf = true
                } else if (inOrf && (codon == "TAA" || codon == "TAG" || codon == "TGA")) {
                    orfCount++
                    inOrf = false
                }
                i += 3
            }
        }
        return orfCount
    }

    fun analyzeDna(sequence: String): DnaAnalysisResult {
        val cleaned = cleanDna(sequence)
        return DnaAnalysisResult(
            length = cleaned.length,
            gcPercent = calculateGcContent(cleaned),
            reverseComplement = reverseComplement(cleaned),
            rnaTranscript = transcribe(cleaned),
            translatedProtein = translate(cleaned),
            restrictionSites = findRestrictionSites(cleaned),
            openReadingFramesCount = findOrfs(cleaned)
        )
    }

    fun analyzeProtein(sequence: String): ProteinAnalysisResult {
        val cleaned = cleanProtein(sequence)
        if (cleaned.isEmpty()) {
            return ProteinAnalysisResult(0, 0.0, 7.0, 0.0, 0.0, 0)
        }

        var mw = 0.0
        var hydropathySum = 0.0
        var tyrCount = 0
        var trpCount = 0
        var cysCount = 0

        var posCharge = 0 // Lys, Arg, His
        var negCharge = 0 // Asp, Glu

        for (ch in cleaned) {
            mw += aaMolecularWeights[ch] ?: 110.0
            hydropathySum += hydropathyScale[ch] ?: 0.0
            when (ch) {
                'Y' -> tyrCount++
                'W' -> trpCount++
                'C' -> cysCount++
                'K', 'R' -> posCharge++
                'H' -> posCharge += 1 // partial at neutral pH
                'D', 'E' -> negCharge++
            }
        }
        // Subtract water for peptide bonds
        if (cleaned.length > 1) {
            mw -= (cleaned.length - 1) * 18.015
        }

        val gravy = hydropathySum / cleaned.length
        val extCoeff = (trpCount * 5500) + (tyrCount * 1490) + (cysCount * 125)
        val netCharge = posCharge.toDouble() - negCharge.toDouble()

        // Approximate pI estimation
        val approxPi = if (posCharge > negCharge) {
            7.0 + ((posCharge - negCharge).toDouble() / cleaned.length) * 15.0
        } else {
            7.0 - ((negCharge - posCharge).toDouble() / cleaned.length) * 15.0
        }.coerceIn(3.0, 11.5)

        return ProteinAnalysisResult(
            length = cleaned.length,
            molecularWeightDa = mw,
            isoelectricPointApprox = approxPi,
            gravyScore = gravy,
            chargeAtPh7 = netCharge,
            extinctionCoefficient280nm = extCoeff
        )
    }

    fun analyzePrimer(sequence: String): PcrPrimerResult {
        val cleaned = cleanDna(sequence)
        val len = cleaned.length
        val a = cleaned.count { it == 'A' }
        val t = cleaned.count { it == 'T' }
        val c = cleaned.count { it == 'C' }
        val g = cleaned.count { it == 'G' }
        val gc = if (len > 0) ((g + c).toDouble() / len) * 100.0 else 0.0

        // Wallace rule (suitable for 14-20 bp): Tm = 2*(A+T) + 4*(G+C)
        val tmWallace = (2 * (a + t) + 4 * (g + c)).toDouble()

        // Nearest neighbor approximation formula: 64.9 + 41 * (yG+zC - 16.4) / (wA+xT+yG+zC)
        val tmNN = if (len > 0) {
            64.9 + 41.0 * ((g + c) - 16.4) / len.toDouble()
        } else 0.0

        val ta = tmNN - 5.0

        val endsWithGc = cleaned.takeLast(2).count { it == 'G' || it == 'C' } in 1..2
        val lengthOk = len in 18..25
        val gcOk = gc in 40.0..60.0

        val hasHairpin = cleaned.contains("GCGC") || cleaned.contains("CGCG") || cleaned.contains("GGCC")

        val note = when {
            !lengthOk -> "الطول الموصى به لبوادئ PCR هو 18-25 نيوكليوتيد (المحدد: $len bp)."
            !gcOk -> "نسبة GC المثالية هي بين 40% و 60% (الحالية: ${String.format(Locale.US, "%.1f", gc)}%)."
            !endsWithGc -> "يُفضل وجود GC Clamp (1-2 قواعد G/C في نهاية الطرف 3')."
            hasHairpin -> "تنبيه: تسلسل متكرر قد يسبب Hairpin ثانوي."
            else -> "بادئ ممتاز ومثالي لتفاعل البلمرة المتسلسل (Optimal PCR Primer)."
        }

        return PcrPrimerResult(
            length = len,
            gcPercent = gc,
            tmWallace = tmWallace,
            tmNearestNeighbor = tmNN,
            recommendedAnnealingTemp = ta,
            hasHairpinRisk = hasHairpin,
            qualityNote = note
        )
    }

    fun calculateDilution(c1: Double, v1: Double?, c2: Double, v2: Double?): Map<String, Double> {
        // C1 * V1 = C2 * V2
        return if (v1 == null && v2 != null) {
            val calcV1 = (c2 * v2) / c1
            mapOf("V1" to calcV1, "BufferV" to (v2 - calcV1))
        } else if (v2 == null && v1 != null) {
            val calcV2 = (c1 * v1) / c2
            mapOf("V2" to calcV2, "BufferV" to (calcV2 - v1))
        } else {
            emptyMap()
        }
    }

    fun calculateHemocytometer(
        liveCellsCount: Int,
        deadCellsCount: Int,
        squaresCount: Int = 4,
        dilutionFactor: Double = 1.0
    ): CellCultureResult {
        val totalCounted = liveCellsCount + deadCellsCount
        val viability = if (totalCounted > 0) {
            (liveCellsCount.toDouble() / totalCounted) * 100.0
        } else 100.0

        // Hemocytometer volume per 1 mm2 square is 0.1 mm3 = 10^-4 mL
        // Cells/mL = (Total Live / squares) * dilutionFactor * 10^4
        val cellsPerMl = if (squaresCount > 0) {
            (liveCellsCount.toDouble() / squaresCount) * dilutionFactor * 10000.0
        } else 0.0

        return CellCultureResult(
            totalCellsCount = cellsPerMl.toLong(),
            cellViabilityPercent = viability,
            recommendedVolumeMlForSeeding = if (cellsPerMl > 0) 500000.0 / cellsPerMl else 0.0,
            doublingTimeHours = null
        )
    }
}
