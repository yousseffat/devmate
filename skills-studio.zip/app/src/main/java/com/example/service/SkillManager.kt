package com.example.service

import android.content.Context
import com.example.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SkillManager(private val context: Context) {

    private val _installedSkills = MutableStateFlow<List<Skill>>(emptyList())
    val installedSkills: StateFlow<List<Skill>> = _installedSkills.asStateFlow()

    private val _logs = MutableStateFlow<List<SkillLogEntry>>(emptyList())
    val logs: StateFlow<List<SkillLogEntry>> = _logs.asStateFlow()

    private val skillsDir: File
        get() = File(context.filesDir, "skills").apply { if (!exists()) mkdirs() }

    private val logFile: File
        get() = File(context.filesDir, "skills-log.json")

    init {
        loadLogs()
        initializeDefaultSkills()
        loadInstalledCustomSkills()
    }

    // Curated catalog of discoverable online skills
    val onlineSkillCatalog = listOf(
        SkillCandidate(
            name = "reverse-engineering-helper",
            description = "Decompilation, binary analysis with Ghidra and Radare2, opcode auditing, and ELF/PE inspection.",
            sourceUrl = "https://github.com/agent-skills/reverse-engineering/tree/main/skills/reverse-engineering-helper",
            category = SkillCategory.REVERSE_ENGINEERING,
            stepsSummary = "1. Reads binary headers (ELF/PE)\n2. Checks if radare2 or ghidra is installed\n3. Decompiles functions and maps symbol tables\n4. Generates vulnerability and patch assessment",
            hasScripts = true,
            rawSkillMd = """---
name: reverse-engineering-helper
description: Decompilation, binary analysis with Ghidra and Radare2, opcode auditing, and ELF/PE inspection.
---
# Reverse Engineering Helper Skill
This skill assists engineers in reverse-engineering binaries, extracting strings, inspecting headers, and decompiling with Ghidra/Radare2.

## Requirements
- radare2
- ghidra
- strings / objdump

## Workflow
1. Analyze target file format.
2. Run non-destructive disassembly.
3. Map control flow graph.
"""
        ),
        SkillCandidate(
            name = "android-apk-security-auditor",
            description = "Analyzes Android APK files, DEX bytecodes, exported components, and manifest permissions.",
            sourceUrl = "https://github.com/agent-skills/mobile-sec/tree/main/skills/android-apk-security-auditor",
            category = SkillCategory.REVERSE_ENGINEERING,
            stepsSummary = "1. Unpacks APK package\n2. Audits AndroidManifest permissions\n3. Analyzes DEX classes and smali opcodes\n4. Detects leaked secrets and unencrypted endpoints",
            hasScripts = true,
            rawSkillMd = """---
name: android-apk-security-auditor
description: Analyzes Android APK files, DEX bytecodes, exported components, and manifest permissions.
---
# Android APK Security Auditor
Automated inspection of Android application packages.
"""
        ),
        SkillCandidate(
            name = "crispr-cas9-target-finder",
            description = "Discovers Cas9 guide RNA (gRNA) target sites with PAM sequence (NGG) and calculates off-target scores.",
            sourceUrl = "https://github.com/agent-skills/bioscience/tree/main/skills/crispr-cas9-target-finder",
            category = SkillCategory.BIOSCIENCE,
            stepsSummary = "1. Scans genomic sequence for PAM sites (NGG)\n2. Extracts 20-nt protospacer sequences\n3. Evaluates on-target efficiency and GC content (40-70%)\n4. Flags poly-T termination signals",
            hasScripts = false,
            rawSkillMd = """---
name: crispr-cas9-target-finder
description: Discovers Cas9 guide RNA (gRNA) target sites with PAM sequence (NGG) and calculates off-target scores.
---
# CRISPR-Cas9 Target Finder
Designs synthetic sgRNA candidates for gene editing workflows.
"""
        ),
        SkillCandidate(
            name = "phylogenetic-tree-builder",
            description = "Computes distance matrices for homologous gene sequences and builds UPGMA/Neighbor-Joining trees.",
            sourceUrl = "https://github.com/agent-skills/bioscience/tree/main/skills/phylogenetic-tree-builder",
            category = SkillCategory.BIOSCIENCE,
            stepsSummary = "1. Accepts multi-FASTA alignments\n2. Computes pairwise Jukes-Cantor distance\n3. Constructs Neighbor-Joining tree Newick topology",
            hasScripts = true,
            rawSkillMd = """---
name: phylogenetic-tree-builder
description: Computes distance matrices for homologous gene sequences and builds UPGMA/Neighbor-Joining trees.
---
# Phylogenetic Tree Builder
Sequence alignment and molecular evolution analysis.
"""
        ),
        SkillCandidate(
            name = "code-security-linter",
            description = "Scans source code repositories for CVE patterns, hardcoded credentials, and SQL injection risks.",
            sourceUrl = "https://github.com/agent-skills/devsec/tree/main/skills/code-security-linter",
            category = SkillCategory.DEVELOPER,
            stepsSummary = "1. Tokenizes code files\n2. Runs pattern matching against known vulnerability signatures\n3. Suggests safe parameterized queries and environment variable patterns",
            hasScripts = false,
            rawSkillMd = """---
name: code-security-linter
description: Scans source code repositories for CVE patterns, hardcoded credentials, and SQL injection risks.
---
# Code Security Linter
Finds vulnerabilities before code commits.
"""
        )
    )

    private fun initializeDefaultSkills() {
        val builtInList = listOf(
            Skill(
                name = "dna-sequence-analyzer",
                description = "تحليل متقدم لأشرطة الحمض النووي (DNA/RNA)، النسخ، الترجمة لسلاسل ببتيدية، وحساب نسبة GC وقص الإنزيمات.",
                sourceUrl = "builtin://bioscience/dna-sequence-analyzer",
                category = SkillCategory.BIOSCIENCE,
                isBuiltIn = true,
                files = listOf(
                    SkillFile("SKILL.md", 1450, false),
                    SkillFile("scripts/dna_calc.py", 2200, true)
                ),
                skillMdContent = """---
name: dna-sequence-analyzer
description: Advanced DNA/RNA transcription, translation, GC-content calculation, ORF detection, and restriction site mapping.
---
# DNA Sequence Analyzer (Science Skill)
Provides high-performance nucleotide sequence analysis.
- Transcription (DNA -> mRNA)
- Translation (Standard Genetic Code -> Amino Acid 1-letter code)
- Reverse Complement generation
- EcoRI, BamHI, HindIII, NotI restriction endonuclease cleavage detection
""",
                hasScripts = true
            ),
            Skill(
                name = "protein-property-calculator",
                description = "حساب الوزن الجزيئي للبروتينات، نقطة التعادل الكهربائي (pI)، كراهية الماء (GRAVY)، ومعامل الامتصاص الضوئي.",
                sourceUrl = "builtin://bioscience/protein-property-calculator",
                category = SkillCategory.BIOSCIENCE,
                isBuiltIn = true,
                files = listOf(
                    SkillFile("SKILL.md", 1200, false),
                    SkillFile("scripts/protein_props.py", 1850, true)
                ),
                skillMdContent = """---
name: protein-property-calculator
description: Calculates molecular weight (Da), isoelectric point (pI), GRAVY score, and extinction coefficient for peptides.
---
# Protein Physicochemical Property Calculator
Evaluates primary protein structures using Kyte-Doolittle hydropathy index.
""",
                hasScripts = true
            ),
            Skill(
                name = "pcr-primer-designer",
                description = "تصميم بادئات تفاعل البلمرة المتسلسل PCR وحساب درجة حرارة الانصهار Tm ونسبة GC واحتمالية تشكل Hairpin.",
                sourceUrl = "builtin://bioscience/pcr-primer-designer",
                category = SkillCategory.BIOSCIENCE,
                isBuiltIn = true,
                files = listOf(
                    SkillFile("SKILL.md", 1100, false),
                    SkillFile("scripts/primer_tm.py", 1540, true)
                ),
                skillMdContent = """---
name: pcr-primer-designer
description: Designs forward and reverse PCR primers with Wallace & Nearest Neighbor Tm calculation, GC clamp verification, and secondary structure alerts.
---
# PCR Primer Designer
Ensures high specificity and amplicon yield in molecular cloning.
""",
                hasScripts = true
            ),
            Skill(
                name = "cell-culture-calculator",
                description = "حسابات زراعة الخلايا في المختبر: حساب عدد الخلايا الحية بالميكروسكوب (Hemocytometer)، النسبة المئوية للحيوية، وتخفيف المحاليل (C1V1 = C2V2).",
                sourceUrl = "builtin://bioscience/cell-culture-calculator",
                category = SkillCategory.BIOSCIENCE,
                isBuiltIn = true,
                files = listOf(
                    SkillFile("SKILL.md", 980, false)
                ),
                skillMdContent = """---
name: cell-culture-calculator
description: Cell culture mathematics: viable cell counts, hemocytometer formulas, plating density, and buffer dilution calculations (C1V1=C2V2).
---
# Cell Culture & Dilution Calculator
Aids in mammalian and bacterial cell culture maintenance.
""",
                hasScripts = false
            ),
            Skill(
                name = "microbiology-colony-counter",
                description = "حساب عدد مستعمرات البكتيريا (CFU/mL) من التخافيف المتسلسلة وتقدير كثافة الخلايا البصرية OD600.",
                sourceUrl = "builtin://bioscience/microbiology-colony-counter",
                category = SkillCategory.BIOSCIENCE,
                isBuiltIn = true,
                files = listOf(
                    SkillFile("SKILL.md", 920, false)
                ),
                skillMdContent = """---
name: microbiology-colony-counter
description: Calculates CFU/mL from serial dilution plates, plating volume, and estimates bacterial density from spectrophotometer OD600 readings.
---
# Microbiology Colony Counter
Accurate bacterial quantitation and growth curve tracking.
""",
                hasScripts = false
            ),
            Skill(
                name = "genetics-punnett-square",
                description = "حل مسائل الوراثة المندلية وحساب النسب الوراثية والمظهرية للتزاوج الأحادي والثنائي (Monohybrid & Dihybrid cross).",
                sourceUrl = "builtin://bioscience/genetics-punnett-square",
                category = SkillCategory.BIOSCIENCE,
                isBuiltIn = true,
                files = listOf(
                    SkillFile("SKILL.md", 880, false)
                ),
                skillMdContent = """---
name: genetics-punnett-square
description: Solves Mendelian monohybrid and dihybrid genetic crosses and generates exact phenotypic and genotypic ratios.
---
# Genetics Punnett Square Solver
Predicts trait inheritance probabilities in molecular genetics.
""",
                hasScripts = false
            )
        )
        _installedSkills.value = builtInList
    }

    private fun loadInstalledCustomSkills() {
        val customList = mutableListOf<Skill>()
        if (skillsDir.exists() && skillsDir.isDirectory) {
            skillsDir.listFiles()?.filter { it.isDirectory }?.forEach { dir ->
                val skillMd = File(dir, "SKILL.md")
                if (skillMd.exists()) {
                    val content = skillMd.readText()
                    val validation = validateSkillMd(content, dir.name)
                    if (validation.isValid) {
                        val files = dir.walkTopDown().filter { it.isFile }.map { f ->
                            val rel = f.relativeTo(dir).path
                            val isScript = rel.endsWith(".py") || rel.endsWith(".sh") || rel.endsWith(".js") || rel.endsWith(".ps1")
                            SkillFile(rel, f.length(), isScript)
                        }.toList()
                        val hasScripts = files.any { it.isScript }
                        customList.add(
                            Skill(
                                name = validation.name ?: dir.name,
                                description = validation.description ?: "Custom installed skill",
                                sourceUrl = "local://${dir.name}",
                                category = SkillCategory.CUSTOM,
                                isBuiltIn = false,
                                isEnabled = true,
                                files = files,
                                skillMdContent = content,
                                hasScripts = hasScripts
                            )
                        )
                    }
                }
            }
        }
        _installedSkills.value = _installedSkills.value.filter { it.isBuiltIn } + customList
    }

    // 1. search_skills(query)
    fun searchSkills(query: String): List<SkillCandidate> {
        val q = query.trim().lowercase(Locale.ROOT)
        // Match against online catalog + installed skills
        val candidates = onlineSkillCatalog.filter { candidate ->
            candidate.name.lowercase(Locale.ROOT).contains(q) ||
            candidate.description.lowercase(Locale.ROOT).contains(q) ||
            candidate.stepsSummary.lowercase(Locale.ROOT).contains(q) ||
            (q.contains("عكسي") && candidate.category == SkillCategory.REVERSE_ENGINEERING) ||
            (q.contains("reverse") && candidate.category == SkillCategory.REVERSE_ENGINEERING) ||
            (q.contains("علم") && candidate.category == SkillCategory.BIOSCIENCE) ||
            (q.contains("bio") && candidate.category == SkillCategory.BIOSCIENCE) ||
            (q.contains("امن") && candidate.category == SkillCategory.REVERSE_ENGINEERING) ||
            (q.contains("dna") && candidate.category == SkillCategory.BIOSCIENCE)
        }

        // If query is broad or no direct keyword, return top relevant candidate skills
        return if (candidates.isNotEmpty()) candidates else onlineSkillCatalog.take(3)
    }

    data class ParsedUrl(
        val owner: String,
        val repo: String,
        val branch: String,
        val path: String
    )

    fun parseGitHubUrl(url: String): ParsedUrl? {
        val trimmed = url.trim()
        val regex = Regex("""^https://github\.com/([a-zA-Z0-9_.-]+)/([a-zA-Z0-9_.-]+)(?:/tree/([a-zA-Z0-9_.-]+)/(.*))?""")
        val match = regex.find(trimmed) ?: return null
        val owner = match.groupValues[1]
        val repo = match.groupValues[2].removeSuffix(".git")
        val branch = match.groupValues.getOrNull(3)?.ifEmpty { "main" } ?: "main"
        val path = match.groupValues.getOrNull(4)?.removeSuffix("/") ?: ""
        return ParsedUrl(owner, repo, branch, path)
    }

    data class ValidationResult(
        val isValid: Boolean,
        val name: String? = null,
        val description: String? = null,
        val errorMessage: String? = null,
        val renameSuggested: Boolean = false,
        val suggestedName: String? = null
    )

    fun validateSkillMd(content: String, targetFolderName: String? = null): ValidationResult {
        if (content.isBlank()) {
            return ValidationResult(false, errorMessage = "ملف SKILL.md فارغ (Content is empty)")
        }
        val frontmatterRegex = Regex("""^---\r?\n([\s\S]*?)\r?\n---""")
        val match = frontmatterRegex.find(content)
            ?: return ValidationResult(false, errorMessage = "ملف SKILL.md لا يحتوي على YAML frontmatter محاط بـ '---'")

        val frontmatter = match.groupValues[1]
        val nameMatch = Regex("""name:\s*["']?([a-z0-9-]+)["']?""").find(frontmatter)
            ?: return ValidationResult(false, errorMessage = "حقل 'name' مفقود أو غير مطابق للشروط (يجب أن يكون أحرف إنجليزية صغيرة وأرقام وشرطات وبحد أقصى 64 حرفاً)")

        val skillName = nameMatch.groupValues[1]
        if (skillName.length > 64) {
            return ValidationResult(false, errorMessage = "طول اسم المهارة يتجاوز 64 حرفاً")
        }

        val descMatch = Regex("""description:\s*["']?([\s\S]+?)["']?(?=\n\w+:|$)""").find(frontmatter)
            ?: return ValidationResult(false, errorMessage = "حقل 'description' مفقود في ترويسة المهارة")

        val description = descMatch.groupValues[1].trim()
        if (description.length > 1024) {
            return ValidationResult(false, errorMessage = "طول وصف المهارة يتجاوز الحد الأقصى (1024 حرفاً)")
        }

        val renameNeeded = targetFolderName != null && targetFolderName != skillName

        return ValidationResult(
            isValid = true,
            name = skillName,
            description = description,
            renameSuggested = renameNeeded,
            suggestedName = skillName
        )
    }

    // Zip-slip & Path traversal protection
    fun isSafePath(targetDir: File, path: String): Boolean {
        if (path.contains("..") || path.startsWith("/") || path.startsWith("\\")) {
            return false
        }
        val canonicalDest = targetDir.canonicalPath
        val canonicalFile = File(targetDir, path).canonicalPath
        return canonicalFile.startsWith(canonicalDest)
    }

    // 2. Prepare install_skill(source_url) for APPROVAL DIALOG
    suspend fun prepareSkillForApproval(sourceUrl: String): Result<PendingInstall> = withContext(Dispatchers.IO) {
        try {
            val trimmed = sourceUrl.trim()
            if (!trimmed.startsWith("https://") && !trimmed.startsWith("http://") && !trimmed.startsWith("candidate://")) {
                return@withContext Result.failure(IllegalArgumentException("يُقبل فقط روابط آمنة https://"))
            }

            // Check if user is referencing one of our candidates
            val candidate = onlineSkillCatalog.find { it.sourceUrl == trimmed || it.name == trimmed }
            if (candidate != null) {
                val validation = validateSkillMd(candidate.rawSkillMd, candidate.name)
                if (!validation.isValid) {
                    return@withContext Result.failure(IllegalStateException(validation.errorMessage))
                }
                val mockFiles = listOf(
                    SkillFile("SKILL.md", candidate.rawSkillMd.toByteArray().size.toLong(), false, candidate.rawSkillMd)
                ) + if (candidate.hasScripts) listOf(
                    SkillFile("scripts/run.py", 1024, true, "#!/usr/bin/env python3\n# Script for ${candidate.name}\nprint('Ready.')\n")
                ) else emptyList()

                val required = when (candidate.name) {
                    "reverse-engineering-helper" -> listOf("radare2", "ghidra", "objdump")
                    "android-apk-security-auditor" -> listOf("apktool", "jadx")
                    else -> emptyList()
                }

                return@withContext Result.success(
                    PendingInstall(
                        name = candidate.name,
                        description = candidate.description,
                        sourceUrl = candidate.sourceUrl,
                        files = mockFiles,
                        skillMdContent = candidate.rawSkillMd,
                        hasScripts = candidate.hasScripts,
                        category = candidate.category,
                        requiredTools = required
                    )
                )
            }

            // Parse GitHub URL
            val parsedGh = parseGitHubUrl(trimmed)
            val skillNameFromUrl = if (parsedGh != null && parsedGh.path.isNotEmpty()) {
                parsedGh.path.split("/").last()
            } else if (parsedGh != null) {
                parsedGh.repo
            } else {
                trimmed.split("/").last().removeSuffix(".zip").removeSuffix(".md")
            }

            // Default fallback template when testing external GitHub or raw URLs
            val skillMdText = """---
name: ${skillNameFromUrl.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9-]"), "-")}
description: Imported agent skill from $trimmed
---
# ${skillNameFromUrl}
Imported skill documentation and execution instructions.
"""
            val validation = validateSkillMd(skillMdText, skillNameFromUrl)
            if (!validation.isValid) {
                return@withContext Result.failure(IllegalStateException(validation.errorMessage))
            }

            val files = listOf(
                SkillFile("SKILL.md", skillMdText.toByteArray().size.toLong(), false, skillMdText),
                SkillFile("references/guide.md", 512, false, "# Guide\nImported documentation.\n")
            )

            val pending = PendingInstall(
                name = validation.name ?: skillNameFromUrl,
                description = validation.description ?: "Downloaded skill",
                sourceUrl = trimmed,
                files = files,
                skillMdContent = skillMdText,
                hasScripts = false,
                category = SkillCategory.CUSTOM
            )

            Result.success(pending)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // MANDATORY APPROVAL STEP: Only executed when user clicks [Install] in UI
    suspend fun executeApprovedInstall(pending: PendingInstall): Result<Skill> = withContext(Dispatchers.IO) {
        try {
            // Check size limits: max 5 MB total, max 100 files
            val MAX_SIZE = 5 * 1024 * 1024L
            val MAX_FILES = 100
            val BANNED_EXTENSIONS = listOf(".exe", ".dll", ".msi", ".bin", ".so", ".dylib")

            if (pending.files.size > MAX_FILES) {
                return@withContext Result.failure(IllegalStateException("عدد الملفات (${pending.files.size}) يتجاوز الحد الأقصى المسموح (100 ملف)"))
            }

            var totalSize = 0L
            for (file in pending.files) {
                totalSize += file.sizeBytes
                val lower = file.path.lowercase(Locale.ROOT)
                if (BANNED_EXTENSIONS.any { lower.endsWith(it) }) {
                    return@withContext Result.failure(SecurityException("تم رفض التثبيت: تم العثور على ملف تنفيذي ثنائي محظور: ${file.path}"))
                }
            }

            if (totalSize > MAX_SIZE) {
                return@withContext Result.failure(IllegalStateException("حجم المهارة (${totalSize / 1024} KB) يتجاوز الحد الأقصى المسموح (5 MB)"))
            }

            val targetDir = File(skillsDir, pending.name)
            if (!targetDir.exists()) {
                targetDir.mkdirs()
            }

            // Write files safely (with zip-slip defense)
            val sha256Digest = MessageDigest.getInstance("SHA-256")
            for (file in pending.files) {
                if (!isSafePath(targetDir, file.path)) {
                    throw SecurityException("محاولة خرق مسار محظورة (Zip-slip / Path traversal detected): ${file.path}")
                }
                val destFile = File(targetDir, file.path)
                destFile.parentFile?.mkdirs()
                val contentToWrite = file.content ?: pending.skillMdContent
                destFile.writeText(contentToWrite)
                sha256Digest.update(destFile.readBytes())
            }

            val checksum = sha256Digest.digest().joinToString("") { "%02x".format(it) }

            // Log to skills-log.json
            val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
            val logEntry = SkillLogEntry(
                skillName = pending.name,
                sourceUrl = pending.sourceUrl,
                installedAt = dateStr,
                fileCount = pending.files.size,
                totalSizeBytes = totalSize,
                sha256Checksum = checksum,
                status = "INSTALLED_APPROVED"
            )
            appendLog(logEntry)

            // Refresh registry immediately (no restart required)
            val installedSkill = Skill(
                name = pending.name,
                description = pending.description,
                sourceUrl = pending.sourceUrl,
                category = pending.category,
                isBuiltIn = false,
                isEnabled = true,
                files = pending.files,
                skillMdContent = pending.skillMdContent,
                hasScripts = pending.hasScripts,
                requiredTools = pending.requiredTools
            )

            _installedSkills.value = _installedSkills.value.filter { it.name != pending.name } + installedSkill

            Result.success(installedSkill)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 3. list_skills()
    fun listSkills(): List<Skill> {
        return _installedSkills.value
    }

    // 4. uninstall_skill(name)
    suspend fun uninstallSkill(name: String): Result<Boolean> = withContext(Dispatchers.IO) {
        val skill = _installedSkills.value.find { it.name == name }
        if (skill == null) {
            return@withContext Result.failure(IllegalArgumentException("المهارة $name غير موجودة"))
        }
        if (skill.isBuiltIn) {
            return@withContext Result.failure(IllegalStateException("لا يمكن حذف المهارات الأساسية المدمجة ($name)"))
        }

        val dir = File(skillsDir, name)
        if (dir.exists()) {
            dir.deleteRecursively()
        }

        _installedSkills.value = _installedSkills.value.filter { it.name != name }

        val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        appendLog(
            SkillLogEntry(
                skillName = name,
                sourceUrl = skill.sourceUrl,
                installedAt = dateStr,
                fileCount = 0,
                totalSizeBytes = 0,
                sha256Checksum = "-",
                status = "UNINSTALLED"
            )
        )

        Result.success(true)
    }

    private fun appendLog(entry: SkillLogEntry) {
        val current = _logs.value.toMutableList()
        current.add(0, entry)
        _logs.value = current
        saveLogs(current)
    }

    private fun saveLogs(entries: List<SkillLogEntry>) {
        try {
            val array = JSONArray()
            for (e in entries) {
                val obj = JSONObject()
                obj.put("skillName", e.skillName)
                obj.put("sourceUrl", e.sourceUrl)
                obj.put("installedAt", e.installedAt)
                obj.put("fileCount", e.fileCount)
                obj.put("totalSizeBytes", e.totalSizeBytes)
                obj.put("sha256Checksum", e.sha256Checksum)
                obj.put("status", e.status)
                array.put(obj)
            }
            logFile.writeText(array.toString(2))
        } catch (_: Exception) {}
    }

    private fun loadLogs() {
        if (!logFile.exists()) return
        try {
            val text = logFile.readText()
            val array = JSONArray(text)
            val list = mutableListOf<SkillLogEntry>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    SkillLogEntry(
                        skillName = obj.optString("skillName"),
                        sourceUrl = obj.optString("sourceUrl"),
                        installedAt = obj.optString("installedAt"),
                        fileCount = obj.optInt("fileCount"),
                        totalSizeBytes = obj.optLong("totalSizeBytes"),
                        sha256Checksum = obj.optString("sha256Checksum"),
                        status = obj.optString("status")
                    )
                )
            }
            _logs.value = list
        } catch (_: Exception) {}
    }
}
