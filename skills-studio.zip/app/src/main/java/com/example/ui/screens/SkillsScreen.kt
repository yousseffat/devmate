package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.PendingInstall
import com.example.model.Skill
import com.example.model.SkillCategory
import com.example.service.SkillManager
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SkillsScreen(
    skillManager: SkillManager,
    onNavigateToChatWithQuery: (String) -> Unit,
    onRequestInstallApproval: (PendingInstall) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val installedSkills by skillManager.installedSkills.collectAsState()
    var selectedCategory by remember { mutableStateOf<SkillCategory?>(null) }
    var searchQuery by remember { mutableStateOf("") }

    var showInstallUrlDialog by remember { mutableStateOf(false) }
    var inputUrlText by remember { mutableStateOf("") }
    var installUrlError by remember { mutableStateOf<String?>(null) }
    var isVerifyingUrl by remember { mutableStateOf(false) }

    var skillToUninstall by remember { mutableStateOf<Skill?>(null) }
    var selectedSkillDetail by remember { mutableStateOf<Skill?>(null) }

    val filteredSkills = remember(installedSkills, selectedCategory, searchQuery) {
        installedSkills.filter { skill ->
            val matchCategory = selectedCategory == null || skill.category == selectedCategory
            val matchQuery = searchQuery.isBlank() ||
                    skill.name.contains(searchQuery, ignoreCase = true) ||
                    skill.description.contains(searchQuery, ignoreCase = true)
            matchCategory && matchQuery
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "لوحة المهارات (Skills Registry)",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${installedSkills.size} مهارات مثبتة • منها ${installedSkills.count { it.category == SkillCategory.BIOSCIENCE }} علوم حيوية",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { onNavigateToChatWithQuery("ابحث لي عن سكيل") },
                        modifier = Modifier.testTag("search_skills_online_btn")
                    ) {
                        Icon(Icons.Default.CloudDownload, contentDescription = "Search Online")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Action Buttons: "Search skills online" & "Install from URL"
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        onNavigateToChatWithQuery("ابحث لي عن سكيل هندسة عكسية وعلوم حيوية")
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("action_search_online_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "البحث أونلاين",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }

                Button(
                    onClick = {
                        inputUrlText = ""
                        installUrlError = null
                        showInstallUrlDialog = true
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("action_install_url_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AddLink,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                        tint = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "تثبيت من رابط",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }
            }

            // Search Bar & Filter Chips
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .testTag("search_skills_field"),
                placeholder = { Text("بحث في المهارات المثبتة...") },
                leadingIcon = { Icon(Icons.Default.FilterList, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp)
            )

            // Category Filter Chips
            LazyRow(
                modifier = Modifier.padding(vertical = 8.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = selectedCategory == null,
                        onClick = { selectedCategory = null },
                        label = { Text("الكل (All)") }
                    )
                }
                items(SkillCategory.entries) { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = if (selectedCategory == cat) null else cat },
                        label = { Text(cat.labelAr) }
                    )
                }
            }

            // Skill List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                items(filteredSkills, key = { it.name }) { skill ->
                    SkillItemCard(
                        skill = skill,
                        onClick = { selectedSkillDetail = skill },
                        onUninstall = { skillToUninstall = skill }
                    )
                }
            }
        }
    }

    // Dialog: Install from URL
    if (showInstallUrlDialog) {
        AlertDialog(
            onDismissRequest = { if (!isVerifyingUrl) showInstallUrlDialog = false },
            title = { Text("تثبيت مهارة من رابط URL") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "أدخل رابط مستودع GitHub أو مسار مجلد المهارة أو رابط ملف SKILL.md المباشر:",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    OutlinedTextField(
                        value = inputUrlText,
                        onValueChange = { inputUrlText = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("install_url_input"),
                        placeholder = { Text("https://github.com/owner/repo/tree/main/skills/name") },
                        isError = installUrlError != null,
                        supportingText = installUrlError?.let { { Text(it, color = MaterialTheme.colorScheme.error) } }
                    )
                    // Quick sample URLs
                    Text(
                        text = "روابط مقترحة سريعة:",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        AssistChip(
                            onClick = {
                                inputUrlText = "https://github.com/agent-skills/reverse-engineering/tree/main/skills/reverse-engineering-helper"
                            },
                            label = { Text("Reverse Eng", fontSize = 11.sp) }
                        )
                        AssistChip(
                            onClick = {
                                inputUrlText = "https://github.com/agent-skills/bioscience/tree/main/skills/crispr-cas9-target-finder"
                            },
                            label = { Text("CRISPR Finder", fontSize = 11.sp) }
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (inputUrlText.isBlank()) {
                            installUrlError = "الرجاء إدخال الرابط"
                            return@Button
                        }
                        isVerifyingUrl = true
                        installUrlError = null
                        coroutineScope.launch {
                            val res = skillManager.prepareSkillForApproval(inputUrlText.trim())
                            isVerifyingUrl = false
                            if (res.isSuccess) {
                                showInstallUrlDialog = false
                                onRequestInstallApproval(res.getOrThrow())
                            } else {
                                installUrlError = res.exceptionOrNull()?.localizedMessage ?: "فشل التحقق من الرابط"
                            }
                        }
                    },
                    enabled = !isVerifyingUrl,
                    modifier = Modifier.testTag("submit_install_url_btn")
                ) {
                    if (isVerifyingUrl) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                    } else {
                        Text("فحص ومراجعة (Verify)")
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showInstallUrlDialog = false },
                    enabled = !isVerifyingUrl
                ) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Dialog: Confirm Uninstall
    skillToUninstall?.let { skill ->
        AlertDialog(
            onDismissRequest = { skillToUninstall = null },
            title = { Text("تأكيد إزالة المهارة") },
            text = {
                Text("هل أنت متأكد من رغبتك في حذف المهارة \"${skill.name}\"؟ سيتم حذف جميع ملفاتها المحلية بأمان وتسجيل العملية.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        val name = skill.name
                        skillToUninstall = null
                        coroutineScope.launch {
                            skillManager.uninstallSkill(name)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("confirm_uninstall_btn")
                ) {
                    Text("حذف المهارة (Remove)")
                }
            },
            dismissButton = {
                TextButton(onClick = { skillToUninstall = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Dialog: Skill Details Sheet
    selectedSkillDetail?.let { skill ->
        Dialog(onDismissRequest = { selectedSkillDetail = null }) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .fillMaxHeight(0.85f)
                    .clip(RoundedCornerShape(20.dp)),
                color = MaterialTheme.colorScheme.surface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = skill.name,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = skill.category.labelAr,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.outline
                            )
                        }
                        IconButton(onClick = { selectedSkillDetail = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = skill.description,
                            style = MaterialTheme.typography.bodyMedium
                        )

                        Text(
                            text = "المصدر: ${skill.sourceUrl}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.outline
                        )

                        Text(
                            text = "ملف التعليمات والتشغيل (SKILL.md):",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = skill.skillMdContent.ifEmpty { "لا يوجد محتوى SKILL.md إضافي." },
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SkillItemCard(
    skill: Skill,
    onClick: () -> Unit,
    onUninstall: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .testTag("skill_card_${skill.name}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    val iconVector = when (skill.category) {
                        SkillCategory.BIOSCIENCE -> Icons.Default.Biotech
                        SkillCategory.REVERSE_ENGINEERING -> Icons.Default.BugReport
                        SkillCategory.DEVELOPER -> Icons.Default.Terminal
                        else -> Icons.Default.Extension
                    }
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = iconVector,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Column {
                        Text(
                            text = skill.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = skill.category.labelAr,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Remove button for custom installed skills
                if (!skill.isBuiltIn) {
                    IconButton(
                        onClick = onUninstall,
                        modifier = Modifier.testTag("uninstall_btn_${skill.name}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Uninstall Skill",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                } else {
                    Surface(
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "مدمجة",
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Text(
                text = skill.description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (skill.hasScripts) {
                    Surface(
                        color = MaterialTheme.colorScheme.tertiaryContainer,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Code,
                                contentDescription = null,
                                modifier = Modifier.size(12.dp),
                                tint = MaterialTheme.colorScheme.onTertiaryContainer
                            )
                            Text(
                                text = "تحتوي سكربتات",
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onTertiaryContainer
                            )
                        }
                    }
                }
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "${skill.files.size} ملفات",
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}
