package com.example.ui.screens

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Biotech
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import com.example.model.PendingInstall
import com.example.service.AssistantEngine
import com.example.service.SkillManager
import com.example.ui.components.CommandApprovalDialog
import com.example.ui.components.SkillApprovalDialog
import kotlinx.coroutines.launch

enum class AppTab(val titleAr: String, val titleEn: String, val icon: ImageVector) {
    SKILLS("المهارات", "Skills", Icons.Default.Extension),
    CHAT("المساعد", "Assistant", Icons.Default.Chat),
    LAB("المختبر", "Bio Lab", Icons.Default.Biotech),
    SECURITY("الأمان", "Security", Icons.Default.Shield)
}

@Composable
fun HomeScreen(
    skillManager: SkillManager,
    assistantEngine: AssistantEngine
) {
    val coroutineScope = rememberCoroutineScope()
    var currentTab by remember { mutableStateOf(AppTab.SKILLS) }
    var chatInitialQuery by remember { mutableStateOf<String?>(null) }

    // Active pending approval state from assistant or direct URL install
    var manualPendingInstall by remember { mutableStateOf<PendingInstall?>(null) }
    val assistantPendingInstall by assistantEngine.pendingInstallDialog.collectAsState()
    val activePendingInstall = manualPendingInstall ?: assistantPendingInstall

    val pendingCommand by assistantEngine.pendingCommandDialog.collectAsState()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(modifier = Modifier.testTag("bottom_nav_bar")) {
                AppTab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = currentTab == tab,
                        onClick = { currentTab = tab },
                        icon = { Icon(imageVector = tab.icon, contentDescription = tab.titleAr) },
                        label = { Text(tab.titleAr) },
                        modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                AppTab.SKILLS -> SkillsScreen(
                    skillManager = skillManager,
                    onNavigateToChatWithQuery = { query ->
                        chatInitialQuery = query
                        currentTab = AppTab.CHAT
                    },
                    onRequestInstallApproval = { pending ->
                        manualPendingInstall = pending
                    }
                )
                AppTab.CHAT -> ChatScreen(
                    assistantEngine = assistantEngine,
                    initialQuery = chatInitialQuery
                )
                AppTab.LAB -> BioscienceLabScreen()
                AppTab.SECURITY -> SecuritySettingsScreen(skillManager = skillManager)
            }
        }

        // Global Mandatory Skill Approval Dialog
        activePendingInstall?.let { pending ->
            SkillApprovalDialog(
                pending = pending,
                onInstallConfirmed = {
                    coroutineScope.launch {
                        if (manualPendingInstall != null) {
                            skillManager.executeApprovedInstall(pending)
                            manualPendingInstall = null
                        } else {
                            assistantEngine.onUserApprovedInstall(pending)
                        }
                    }
                },
                onCancelled = {
                    manualPendingInstall = null
                    assistantEngine.onUserCancelledInstall()
                }
            )
        }

        // Global Mandatory Command Approval Dialog
        pendingCommand?.let { cmd ->
            CommandApprovalDialog(
                request = cmd,
                onApproved = {
                    assistantEngine.onUserApprovedCommand(cmd)
                },
                onCancelled = {
                    assistantEngine.onUserCancelledCommand()
                }
            )
        }
    }
}
