package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BioCyanPrimary = Color(0xFF007A87)
val BioCyanContainer = Color(0xFFBCEBF0)
val BioDarkBg = Color(0xFF0B131E)
val BioDarkSurface = Color(0xFF131F2E)
val BioDarkSurfaceVariant = Color(0xFF1D2E42)

val ElectricBlue80 = Color(0xFF82D3E3)
val ElectricBlue40 = Color(0xFF006875)
val VioletAccent80 = Color(0xFFCFBCFF)
val VioletAccent40 = Color(0xFF6550A4)
val EmeraldGreen80 = Color(0xFF76DB97)
val EmeraldGreen40 = Color(0xFF006D37)
