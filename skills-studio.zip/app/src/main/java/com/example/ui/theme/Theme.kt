package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = ElectricBlue80,
    onPrimary = Color(0xFF00363D),
    primaryContainer = Color(0xFF004F59),
    onPrimaryContainer = Color(0xFF9EEFFE),
    secondary = VioletAccent80,
    onSecondary = Color(0xFF362073),
    secondaryContainer = Color(0xFF4D388B),
    onSecondaryContainer = Color(0xFFE8DDFF),
    tertiary = EmeraldGreen80,
    background = BioDarkBg,
    surface = BioDarkSurface,
    surfaceVariant = BioDarkSurfaceVariant
)

private val LightColorScheme = lightColorScheme(
    primary = ElectricBlue40,
    onPrimary = Color.White,
    primaryContainer = BioCyanContainer,
    onPrimaryContainer = Color(0xFF001F24),
    secondary = VioletAccent40,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE8DDFF),
    onSecondaryContainer = Color(0xFF21085E),
    tertiary = EmeraldGreen40
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
