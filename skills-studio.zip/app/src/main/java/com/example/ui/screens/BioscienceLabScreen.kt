package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.BioscienceEngine
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BioscienceLabScreen() {
    var selectedTab by remember { mutableIntStateOf(0) }
    val labTabs = listOf("DNA / RNA", "البروتينات (Protein)", "بادئات PCR", "تخفيف ومزارع خلايا")

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Biotech,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        Column {
                            Text(
                                text = "مختبر العلوم الحيوية (Bioscience Lab)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "تحليلات جزيئية متقدمة وحسابات وراثية فورية",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Scrollable Tab Row
            PrimaryTabRow(selectedTabIndex = selectedTab) {
                labTabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title, fontSize = 13.sp, fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal) }
                    )
                }
            }

            // Tab Content
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                when (selectedTab) {
                    0 -> DnaAnalyzerTab()
                    1 -> ProteinAnalyzerTab()
                    2 -> PcrPrimerTab()
                    3 -> CellCultureTab()
                }
            }
        }
    }
}

@Composable
fun DnaAnalyzerTab() {
    var sequenceInput by remember { mutableStateOf("ATGCGATCGAGCTAGCTAGCTAATAA") }
    val analysis = remember(sequenceInput) {
        BioscienceEngine.analyzeDna(sequenceInput)
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(
            text = "محلل سلاسل الحمض النووي (DNA / RNA Sequence Analyzer)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        // Sample Sequences
        Text(text = "عينات تسلسل جاهزة للاختبار:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                AssistChip(
                    onClick = { sequenceInput = "ATGCGATCGAGCTAGCTAGCTAATAA" },
                    label = { Text("نموذج قياسي (ORF)") }
                )
            }
            item {
                AssistChip(
                    onClick = { sequenceInput = "GAATTCGGATCCAAGCTTGCGGCCGC" },
                    label = { Text("مواقع إنزيمات (Cloning)") }
                )
            }
            item {
                AssistChip(
                    onClick = { sequenceInput = "ATGGCCAGCAAAGGAGAAGAACTTTTCACTGGAGTTGTCCCAATTCTTGTTGAATTAGATGGTGATGTTAATGGGCAC" },
                    label = { Text("بروتين GFP مضيء") }
                )
            }
        }

        OutlinedTextField(
            value = sequenceInput,
            onValueChange = { sequenceInput = it },
            label = { Text("أدخل تسلسل النيوكليوتيدات (A, T, C, G)") },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("dna_input_field"),
            maxLines = 5,
            textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace)
        )

        // Results Card
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "نتائج الفحص والتحليل الوراثي:",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(text = "طول الشريط: ${analysis.length} bp", fontWeight = FontWeight.SemiBold)
                    Text(
                        text = "نسبة GC: ${String.format(Locale.US, "%.1f", analysis.gcPercent)}%",
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }

                HorizontalDivider()

                Text(text = "الشريط المتمم المعكوس (Reverse Complement):", style = MaterialTheme.typography.labelMedium)
                SelectionContainerText(analysis.reverseComplement)

                Text(text = "نسخة الرنا الرسول (mRNA Transcript):", style = MaterialTheme.typography.labelMedium)
                SelectionContainerText(analysis.rnaTranscript)

                Text(text = "الترجمة إلى سلسلة أحماض أمينية (Protein):", style = MaterialTheme.typography.labelMedium)
                SelectionContainerText(analysis.translatedProtein)

                Text(
                    text = "مواقع إنزيمات التقييد (Restriction Sites):",
                    style = MaterialTheme.typography.labelMedium
                )
                if (analysis.restrictionSites.isNotEmpty()) {
                    analysis.restrictionSites.forEach { site ->
                        Text(
                            text = "✂️ $site",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                } else {
                    Text(text = "لا توجد مواقع لإنزيمات EcoRI, BamHI, HindIII, NotI", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                }
            }
        }
    }
}

@Composable
fun ProteinAnalyzerTab() {
    var proteinInput by remember { mutableStateOf("MKWVTFISLLFLFSSAYSRGVFRRDTHKSEIAHRFKDLGE") }
    val analysis = remember(proteinInput) {
        BioscienceEngine.analyzeProtein(proteinInput)
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(
            text = "حاسبة الخصائص الفيزيائية والكيميائية للببتيدات والبروتينات",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        OutlinedTextField(
            value = proteinInput,
            onValueChange = { proteinInput = it },
            label = { Text("أدخل تسلسل الأحماض الأمينية (رموز الحرف الواحد)") },
            modifier = Modifier.fillMaxWidth(),
            maxLines = 4,
            textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace)
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "الخصائص المحسوبة (Kyte-Doolittle / ProtParam):",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                MetricRow("عدد الأحماض الأمينية", "${analysis.length} aa")
                MetricRow("الوزن الجزيئي التقريبي (MW)", "${String.format(Locale.US, "%.2f", analysis.molecularWeightDa)} Da (${String.format(Locale.US, "%.2f", analysis.molecularWeightDa / 1000.0)} kDa)")
                MetricRow("نقطة التعادل الكهربائي (Theoretical pI)", String.format(Locale.US, "%.2f", analysis.isoelectricPointApprox))
                MetricRow("معامل كراهية الماء (GRAVY Score)", String.format(Locale.US, "%.3f", analysis.gravyScore) + if (analysis.gravyScore > 0) " (كاره للماء/Hydrophobic)" else " (محب للماء/Hydrophilic)")
                MetricRow("الشحنة الصافية التقريبية عند pH 7.0", String.format(Locale.US, "%.1f", analysis.chargeAtPh7))
                MetricRow("معامل الامتصاص عند 280nm (Extinction Coeff)", "${analysis.extinctionCoefficient280nm} M⁻¹ cm⁻¹")
            }
        }
    }
}

@Composable
fun PcrPrimerTab() {
    var primerInput by remember { mutableStateOf("AGGTCGATCGGATCCGTAG") }
    val primerResult = remember(primerInput) {
        BioscienceEngine.analyzePrimer(primerInput)
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(
            text = "مصمم ومحلل بادئات تفاعل PCR (Primer Designer)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        OutlinedTextField(
            value = primerInput,
            onValueChange = { primerInput = it },
            label = { Text("تسلسل البادئ (5' -> 3')") },
            modifier = Modifier.fillMaxWidth(),
            textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace)
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "تقييم جودة البادئ وحرارة الالتصاق:",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                MetricRow("طول البادئ", "${primerResult.length} bp")
                MetricRow("نسبة محتوى GC", "${String.format(Locale.US, "%.1f", primerResult.gcPercent)}%")
                MetricRow("درجة حرارة الانصهار (Wallace Tm)", "${String.format(Locale.US, "%.1f", primerResult.tmWallace)} °C")
                MetricRow("درجة حرارة الانصهار (Nearest-Neighbor Tm)", "${String.format(Locale.US, "%.1f", primerResult.tmNearestNeighbor)} °C")
                MetricRow("درجة حرارة الالتصاق الموصى بها (Ta)", "${String.format(Locale.US, "%.1f", primerResult.recommendedAnnealingTemp)} °C")

                HorizontalDivider()

                Text(
                    text = primerResult.qualityNote,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = if (primerResult.hasHairpinRisk) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
fun CellCultureTab() {
    var c1Text by remember { mutableStateOf("10.0") }
    var c2Text by remember { mutableStateOf("1.0") }
    var v2Text by remember { mutableStateOf("50.0") }

    var liveCellsText by remember { mutableStateOf("120") }
    var deadCellsText by remember { mutableStateOf("15") }

    val c1 = c1Text.toDoubleOrNull() ?: 1.0
    val c2 = c2Text.toDoubleOrNull() ?: 1.0
    val v2 = v2Text.toDoubleOrNull() ?: 1.0
    val dilution = remember(c1, c2, v2) {
        BioscienceEngine.calculateDilution(c1, null, c2, v2)
    }

    val liveCount = liveCellsText.toIntOrNull() ?: 0
    val deadCount = deadCellsText.toIntOrNull() ?: 0
    val hemocytometer = remember(liveCount, deadCount) {
        BioscienceEngine.calculateHemocytometer(liveCount, deadCount)
    }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text(
            text = "حسابات تخفيف المحاليل الماصة (C1V1 = C2V2)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = c1Text,
                onValueChange = { c1Text = it },
                label = { Text("التركيز الأولي C1") },
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = c2Text,
                onValueChange = { c2Text = it },
                label = { Text("التركيز النهائي C2") },
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = v2Text,
                onValueChange = { v2Text = it },
                label = { Text("الحجم النهائي V2") },
                modifier = Modifier.weight(1f)
            )
        }

        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                val neededV1 = dilution["V1"] ?: 0.0
                val buffer = dilution["BufferV"] ?: 0.0
                Text(
                    text = "الحجم المطلوب سحبه من المخزون (V1): ${String.format(Locale.US, "%.2f", neededV1)} mL",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "حجم الماء المعقم أو المحلول المنظم للإكمال (Buffer): ${String.format(Locale.US, "%.2f", buffer)} mL",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        HorizontalDivider()

        Text(
            text = "عد الخلايا الحية ونسبة الحيوية (Hemocytometer Viability)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = liveCellsText,
                onValueChange = { liveCellsText = it },
                label = { Text("خلايا حية (Live)") },
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = deadCellsText,
                onValueChange = { deadCellsText = it },
                label = { Text("خلايا ميتة (Dead)") },
                modifier = Modifier.weight(1f)
            )
        }

        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "نسبة حيوية الخلايا (Viability): ${String.format(Locale.US, "%.1f", hemocytometer.cellViabilityPercent)}%",
                    fontWeight = FontWeight.Bold,
                    color = if (hemocytometer.cellViabilityPercent >= 85.0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                )
                Text(
                    text = "تركيز الخلايا المقدر: ${hemocytometer.totalCellsCount} خلايا/مل (cells/mL)",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

@Composable
fun MetricRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SelectionContainerText(text: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall.copy(
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp
            )
        )
    }
}
