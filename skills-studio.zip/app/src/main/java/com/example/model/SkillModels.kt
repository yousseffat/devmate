package com.example.model

data class Skill(
    val name: String,
    val description: String,
    val sourceUrl: String,
    val version: String = "1.0.0",
    val category: SkillCategory = SkillCategory.GENERAL,
    val isBuiltIn: Boolean = false,
    val isEnabled: Boolean = true,
    val files: List<SkillFile> = emptyList(),
    val skillMdContent: String = "",
    val hasScripts: Boolean = false,
    val requiredTools: List<String> = emptyList()
)

enum class SkillCategory(val labelAr: String, val labelEn: String) {
    BIOSCIENCE("العلوم الحيوية", "Bioscience"),
    DEVELOPER("تطوير وبرمجة", "Developer"),
    REVERSE_ENGINEERING("هندسة عكسية وأمن", "Reverse Eng & Security"),
    GENERAL("عام", "General"),
    CUSTOM("مثبتة مخصصة", "Custom Installed")
}

data class SkillFile(
    val path: String,
    val sizeBytes: Long,
    val isScript: Boolean = false,
    val content: String? = null
)

data class SkillLogEntry(
    val skillName: String,
    val sourceUrl: String,
    val installedAt: String,
    val fileCount: Int,
    val totalSizeBytes: Long,
    val sha256Checksum: String,
    val status: String = "INSTALLED"
)

data class SkillCandidate(
    val name: String,
    val description: String,
    val sourceUrl: String,
    val category: SkillCategory,
    val stepsSummary: String,
    val hasScripts: Boolean,
    val rawSkillMd: String
)

data class PendingInstall(
    val name: String,
    val description: String,
    val sourceUrl: String,
    val files: List<SkillFile>,
    val skillMdContent: String,
    val hasScripts: Boolean,
    val category: SkillCategory = SkillCategory.CUSTOM,
    val requiredTools: List<String> = emptyList()
)

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: MessageSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val toolCall: ToolExecutionRecord? = null,
    val isArabic: Boolean = true
)

enum class MessageSender {
    USER, ASSISTANT, SYSTEM
}

data class ToolExecutionRecord(
    val toolName: String,
    val argumentsJson: String,
    val resultJson: String? = null,
    val status: ToolStatus = ToolStatus.SUCCESS,
    val requiresApproval: Boolean = false,
    val approvalPrompt: String? = null
)

enum class ToolStatus {
    PENDING_APPROVAL, RUNNING, SUCCESS, FAILED, CANCELLED
}

data class CommandRequest(
    val command: String,
    val rationale: String,
    val toolName: String,
    val isInstalledCheck: Boolean = false
)
